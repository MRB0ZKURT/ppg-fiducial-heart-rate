"""Explicit revision entrypoint; legacy results alone are not final revised results."""
from pathlib import Path
import argparse,sys,subprocess,json,os
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['full','cached','sensitivities','verify'],default='cached')
    p.add_argument('--dataset-root',type=Path,help='Existing local SensSmartTech root; read only')
    p.add_argument('--skip-sensitivities',action='store_true',help='Run only primary models; this is not a full revision reproduction')
    args=p.parse_args();done=[]
    for stage in ['stage2','stage2_quality_consistent','stage3','stage4']:
        (ROOT/'revision/results'/stage).mkdir(parents=True,exist_ok=True)
    if args.dataset_root:os.environ['SENSSMARTTECH_DATASET_ROOT']=str(args.dataset_root.resolve())
    if args.mode=='full':
        from senssmarttech.config import load_config
        from senssmarttech.audit import run_audit
        from senssmarttech.algorithmic_validation import run_ppg_method_sensitivity
        from senssmarttech.extract import run_extraction
        from senssmarttech.models import run_analysis
        config=load_config(ROOT/'config/analysis_config.yaml')
        if args.dataset_root:
            for key,sub in [('dataset_root',''),('demographics','Demographics.csv'),('wfdb_root','WFDB'),('csv_root','CSV')]:
                config['paths'][key]=str((args.dataset_root/sub).resolve())
        for name,fn in [('inventory',run_audit),('method_sensitivity',run_ppg_method_sensitivity),('historical_extraction',run_extraction),('historical_models',run_analysis)]:
            print(name,flush=True);fn(config);done.append(name)
    scripts=[]
    if args.mode in ['full','cached']:scripts+=['revision_models.py','audit_rr_and_icc.py','quality_consistent_models.py']
    scripts+=['verify_stage2.py']
    if not args.skip_sensitivities:
        if args.mode!='verify':scripts+=['signal_sensitivity.py']
        scripts+=['verify_stage3.py']
        if args.mode!='verify':scripts+=['native_csv_revision.py','prepare_integrated_assets.py']
    for name in scripts:
        print('Revision stage:',name,flush=True)
        subprocess.run([sys.executable,str(ROOT/'revision/scripts'/name)],cwd=ROOT,check=True)
        done.append(name)
    (ROOT/'RUN_STATUS.json').write_text(json.dumps({'mode':args.mode,'completed_stages':done,'sensitivities_included':not args.skip_sensitivities,'raw_data_end_to_end':args.mode=='full' and not args.skip_sensitivities},indent=2))
    print('Requested revision stages completed.')
if __name__=='__main__':main()
