"""Recreate the public SensSmartTech source tree and verify repository checksums."""

from __future__ import annotations

import argparse
import hashlib
import urllib.request
from pathlib import Path

BASE = "https://physionet.org/files/senssmarttech/1.0.0"


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def retrieve(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        urllib.request.urlretrieve(url, destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    checksum_path = args.destination / "SHA256SUMS.txt"
    retrieve(f"{BASE}/SHA256SUMS.txt", checksum_path)
    entries = []
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            expected, relative = line.split(maxsplit=1)
            entries.append((expected, relative.lstrip("*")))
    failures = []
    for expected, relative in entries:
        target = args.destination / relative
        retrieve(f"{BASE}/{relative}", target)
        if digest(target) != expected:
            failures.append(relative)
    if failures:
        raise RuntimeError(f"Checksum verification failed: {failures}")
    print(f"Verified {len(entries)} files in {args.destination}")


if __name__ == "__main__":
    main()
