"""Reproduce the historical pilot using the retained legacy tangent primitive.
The fixed-window wrapper is reconstructed and verified against archived outputs;
this is not a recovered byte-for-byte copy of the old complete source file.
"""
from pathlib import Path
import argparse,hashlib,json,sys,types
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from senssmarttech import external
from senssmarttech.fiducials import intersecting_tangent_foot
from senssmarttech.signals import bandpass
from senssmarttech.config import load_config

def table_hash(frame):
    return hashlib.sha256(frame.to_json(orient='split',index=False,double_precision=15).encode()).hexdigest()

def historical_feet(ppg,r_samples,fs,site):
    filtered=bandpass(ppg,fs,0.5,min(8.0,fs/2-1.0))
    window=(0.08,0.50) if site=='carotid' else (0.10,0.65)
    return np.asarray([intersecting_tangent_foot(filtered,int(r)+int(window[0]*fs),min(filtered.size,int(r)+int(window[1]*fs))) for r in r_samples],dtype=int)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--external-data-root',type=Path,required=True)
    parser.add_argument('--reference-root',type=Path,help='Optional local archived outputs for exact full-table comparison')
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args();captured={}
    def capture(rows,path):captured[Path(path).stem]=pd.DataFrame(list(rows));return path
    old_project_path=external.project_path
    def project_path(config,path):
        return args.external_data_root.resolve() if path=='external_data/pulse-transit-time-ppg-1.1.0' else old_project_path(config,path)
    scope=dict(external.run_external_pilot.__globals__)
    scope.update(detect_ppg_feet=historical_feet,write_records=capture,write_json=lambda payload,path:path,project_path=project_path)
    result=types.FunctionType(external.run_external_pilot.__code__,scope)(load_config(ROOT/'config/analysis_config.yaml'))
    expected=json.loads((ROOT/'reference_aggregates/historical_pilot_reference.json').read_text(encoding='utf8'))
    result=json.loads(json.dumps(result));checks={}
    for key in ['status','subjects','records','gates','subject_hr_spans_bpm','full_dataset_download_authorized_by_gate']:
        assert result[key]==expected['manifest'][key],key
    for stem,frame in captured.items():
        digest=table_hash(frame);assert digest==expected['tables'][stem]['canonical_sha256'],stem
        checks[stem]={'rows':len(frame),'columns':len(frame.columns),'canonical_sha256':digest,'reference_hash_match':True}
        if args.reference_root:
            original=pd.read_parquet(args.reference_root/f'{stem}.parquet')
            pd.testing.assert_frame_equal(original,frame,check_dtype=False,check_exact=True)
            checks[stem]['exact_full_table_match']=True
    source_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),ROOT/'src/senssmarttech/fiducials.py',ROOT/'src/senssmarttech/external.py',ROOT/'src/senssmarttech/signals.py']}
    raw_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(args.external_data_root.iterdir()) if p.suffix in ['.hea','.dat','.atr'] and p.stem in captured['external_pilot_records'].record_id.tolist()}
    report={'status':'passed','tables':checks,'manifest_values':{k:result[k] for k in expected['manifest']},'all_manifest_values_exact_match':True,'source_sha256':source_hashes,'raw_source_sha256':raw_hashes,'provenance':'Retained intersecting_tangent_foot primitive plus reconstructed fixed-window wrapper; not recovery of the complete old source file.','scope':'Computational reproduction of historical results, not physiological accuracy or external validation of revised models.','full_beat_tables_written':False}
    args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps({'status':report['status'],'tables':checks,'raw_source_files':len(raw_hashes),'gates':result['gates']},indent=2))
if __name__=='__main__':main()
