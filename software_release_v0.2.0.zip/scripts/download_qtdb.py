"""Download QT Database 1.0.0 from PhysioNet and verify every published checksum."""

from __future__ import annotations

import argparse
import hashlib
import urllib.request
from pathlib import Path

BASE = "https://physionet.org/files/qtdb/1.0.0"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def retrieve(relative: str, destination_root: Path) -> Path:
    destination = destination_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        urllib.request.urlretrieve(f"{BASE}/{relative}", destination)
    return destination


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "destination",
        nargs="?",
        type=Path,
        default=Path("external_data/qtdb-1.0.0"),
    )
    args = parser.parse_args()
    checksum_path = retrieve("SHA256SUMS.txt", args.destination)
    entries: list[tuple[str, str]] = []
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            expected, relative = line.split(maxsplit=1)
            entries.append((expected, relative.lstrip("*")))
    failures = []
    for expected, relative in entries:
        target = retrieve(relative, args.destination)
        if sha256(target) != expected:
            failures.append(relative)
    if failures:
        raise RuntimeError(f"Checksum verification failed: {failures}")
    print(f"Verified {len(entries)} QT Database files in {args.destination}")


if __name__ == "__main__":
    main()
