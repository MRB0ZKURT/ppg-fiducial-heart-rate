"""Download and verify the fixed-seed six-subject external replication pilot."""

from __future__ import annotations

import hashlib
import urllib.request
from pathlib import Path

BASE = "https://physionet.org/files/pulse-transit-time-ppg/1.1.0"
SUBJECTS = (8, 12, 14, 16, 17, 20)
ACTIVITIES = ("sit", "walk", "run")
ROOT = Path("external_data/pulse-transit-time-ppg-1.1.0")


def download(relative: str) -> Path:
    destination = ROOT / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.exists():
        urllib.request.urlretrieve(f"{BASE}/{relative}", destination)
    return destination


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    checksum_path = download("SHA256SUMS.txt")
    expected = {}
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, name = line.split(maxsplit=1)
        expected[name.lstrip("*")] = digest
    files = []
    for subject in SUBJECTS:
        for activity in ACTIVITIES:
            stem = f"s{subject}_{activity}"
            for suffix in ("hea", "dat", "atr"):
                files.append(download(f"{stem}.{suffix}"))
    failures = []
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        if expected.get(relative) != sha256(path):
            failures.append(relative)
    if failures:
        raise RuntimeError(f"Checksum verification failed: {failures}")
    print(f"Downloaded and verified {len(files)} files for subjects {SUBJECTS}")


if __name__ == "__main__":
    main()
