# Licence scope

The MIT License in `LICENSE` applies to the original software created for this
study, including source code, tests, analysis configurations and the technical
documentation distributed with the Zenodo Software record.

It does **not** grant rights over:

- SensSmartTech, QT Database, Pulse Transit Time PPG Dataset or PhysioNet/CinC
  2016 files;
- any other third-party data, software or documentation;
- the journal's Version of Record;
- manuscript text or figures distributed by a publisher under separate terms.

No third-party signal data are included in the software archive. Users must
obtain those resources from their authoritative repositories and comply with
their licences and citation requirements.
