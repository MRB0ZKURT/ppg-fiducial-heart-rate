# Third-party data notice

This software analyses public third-party datasets but does not redistribute
their files.

- SensSmartTech version 1.0.0: DOI `10.13026/fy9p-n277`, PhysioNet, CC BY 4.0.
- SensSmartTech data descriptor: DOI `10.1038/s41597-025-05781-4`.
- QT Database version 1.0.0: DOI `10.13026/C24K53`, PhysioNet.
- Pulse Transit Time PPG Dataset version 1.1.0: DOI `10.13026/jpan-6n92`, PhysioNet.
- PhysioNet/CinC Challenge 2016 heart-sound data: obtain from its official
  PhysioNet record and follow the licence shown there.

Dataset licences remain independent of the MIT licence applied to the authors'
software. Downloaded signals, annotations and adapter-check samples are excluded
from the Zenodo Software archive.
