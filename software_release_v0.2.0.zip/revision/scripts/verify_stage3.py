from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
REV=Path(__file__).resolve().parents[1];ROOT=REV.parent;OUT=REV/'results/stage3'
NAMES=['r_to_carotid_880nm_foot_ms','r_to_brachial_880nm_foot_ms','carotid_to_brachial_880nm_foot_ms']

def main():
    manifest=json.loads((OUT/'manifest.json').read_text())
    b=pd.read_csv(OUT/'filter_beats.csv')
    assert len(b)==18005*3*4
    assert not b.duplicated(['subject','record_id','beat_index','fiducial_method','cutoff_hz']).any()
    check=pd.read_csv(OUT/'filter8_reproduction_checks.csv')
    assert len(check)==2704 and check.exact_foot_match.all()
    channels=pd.read_csv(OUT/'channel_inventory.csv');assert len(channels)==338 and channels.channels.nunique()==1
    flows=pd.read_csv(OUT/'exclusions_sequential.csv')
    assert (flows.groupby(['cutoff_hz','method','outcome'])['count'].sum()==18005).all()
    p=pd.read_csv(OUT/'filter_predictions.csv')
    assert (p.subject==p.outer_fold_subject).all()
    assert np.isfinite(p[['observed_ms','predicted_ms']]).all().all()
    assert not p.duplicated(['scope','cutoff_hz','outcome','subject','record_id','candidate_model']).any()
    for outcome,g in p[p.scope=='common_all_cutoffs'].groupby('outcome'):
        sets=[set(s.record_id) for _,s in g.groupby('cutoff_hz')]
        assert all(x==sets[0] for x in sets)
    for (scope,cutoff),g in p.groupby(['scope','cutoff_hz']):
        summary=pd.read_csv(OUT/f'filter_{cutoff}_{scope}_summary.csv')
        for _,r in summary.iterrows():
            part=g[(g.outcome==r.outcome)&(g.candidate_model==r.candidate)].copy()
            part['ae']=abs(part.predicted_ms-part.observed_ms)
            assert np.isclose(part.groupby('subject').ae.mean().mean(),r.equal_participant_mae_ms)
    rows=[];seq=[]
    for (cutoff,method),g in b.groupby(['cutoff_hz','fiducial_method']):
        rr=g.rr_valid
        masks=[('invalid_rr',~rr),('missing_carotid_foot',g.carotid_foot<0),('missing_brachial_foot',g.brachial_foot<0),('carotid_pat_outside_50_500',~g.carotid_raw_pat.between(50,500)),('brachial_pat_outside_50_500',~g.brachial_raw_pat.between(50,500)),('regional_delay_outside_10_250',~g.signed_delay_ms.between(10,250))]
        left=pd.Series(True,index=g.index)
        for reason,bad in masks:
            taken=left&bad;left&=~bad
            seq.append(dict(cutoff_hz=cutoff,method=method,reason=reason,beats=int(taken.sum())))
        accepted=g[NAMES].notna().all(axis=1)
        assert left.equals(accepted)
        seq.append(dict(cutoff_hz=cutoff,method=method,reason='retained_all_three',beats=int(left.sum())))
        rows.append(dict(cutoff_hz=cutoff,method=method,total_beats=len(g),complete_three_outcomes=int(accepted.sum()),incomplete_three_outcomes=int((~accepted).sum()),incomplete_pct=100*(~accepted).mean()))
    pd.DataFrame(rows).to_csv(OUT/'complete_outcome_counts.csv',index=False)
    pd.DataFrame(seq).to_csv(OUT/'complete_outcome_sequential_flow.csv',index=False)
    # Summarize signs before imposing a positive-delay restriction.
    g=b[(b.cutoff_hz==8)&(b.fiducial_method=='intersecting_tangent')]
    valid=g[g.rr_valid & g.signed_delay_ms.notna()]
    signs={'rr_valid_with_both_feet':len(valid),'negative':int((valid.signed_delay_ms<0).sum()),'zero':int((valid.signed_delay_ms==0).sum()),'positive_below10':int(valid.signed_delay_ms.between(0,10,inclusive='neither').sum()),'positive10to250':int(valid.signed_delay_ms.between(10,250).sum()),'negative_below_minus250':int((valid.signed_delay_ms< -250).sum()),'above250':int((valid.signed_delay_ms>250).sum())}
    (OUT/'signed_delay_counts.json').write_text(json.dumps(signs,indent=2))
    sources=[] # author manuscript manifest omitted from public software
    assert all(hashlib.sha256(Path(r['source']).read_bytes()).hexdigest()==r['sha256'] for r in sources)
    assert all(hashlib.sha256(Path(s).read_bytes()).hexdigest()==h for s,h in manifest['source_hashes'].items())
    report={'status':'passed','beat_rows':len(b),'exact_8hz_foot_comparisons':len(check),'common_record_sets_identical':True,'all_exclusion_flows_reconcile':True,'source_documents_and_code_unchanged':True,'scope':'PPG-only re-extraction with fixed original R peaks and RR mask; fixed candidate predictions, no cutoff optimization or new inner candidate selection.'}
    (OUT/'verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));print(pd.DataFrame(rows).to_string(index=False))

if __name__=='__main__':main()
