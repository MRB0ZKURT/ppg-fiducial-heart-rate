"""Independent quality audit and profile REML for an unconditional random intercept."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
REV=Path(__file__).resolve().parents[1]; ROOT=REV.parent
sys.path.insert(0,str(ROOT/'src'))
from senssmarttech.models import aggregate_records
SRC=ROOT/'outputs/algorithmic_v2_2026-09-06'; OUT=REV/'results/stage2'
NAMES=['r_to_carotid_880nm_foot_ms','r_to_brachial_880nm_foot_ms','carotid_to_brachial_880nm_foot_ms']

def profile_icc(frame,outcome):
    groups=[g[outcome].to_numpy() for _,g in frame.dropna(subset=[outcome]).groupby('subject')]
    counts=np.array([len(x) for x in groups]); sums=np.array([x.sum() for x in groups]); ss=sum(np.dot(x,x) for x in groups); n=counts.sum()
    def calc(lam):
        weights=1/(1+lam*counts)
        iv1=(counts*weights).sum(); ivy=(sums*weights).sum(); mean=ivy/iv1
        residual=ss-(lam*weights*sums*sums).sum()-ivy*ivy/iv1
        sigma=residual/(n-1)
        objective=.5*((n-1)*np.log(sigma)+np.log1p(lam*counts).sum()+np.log(iv1))
        return objective,sigma,mean
    fit=minimize_scalar(lambda z:calc(np.exp(z))[0],bounds=(-20,14),method='bounded')
    lam=np.exp(fit.x) if fit.fun<calc(0)[0] else 0.
    obj,sigma,mean=calc(lam)
    # Independent dense inverse verification of the fitted GLS residual quadratic.
    ordered=frame.dropna(subset=[outcome]).sort_values('subject')
    y=ordered[outcome].to_numpy(); ids=ordered.subject.to_numpy()
    v=np.eye(n)+lam*(ids[:,None]==ids[None,:])
    r=y-mean; dense_sigma=float(r@np.linalg.solve(v,r)/(n-1))
    assert np.isclose(sigma,dense_sigma,rtol=1e-8)
    assert fit.success
    return dict(records=int(n),participants=len(groups),between_variance_ms2=lam*sigma,within_variance_ms2=sigma,icc=lam/(1+lam),profile_objective=obj,boundary=lam==0,dense_check_error=abs(sigma-dense_sigma))

def main():
    a=pd.read_csv(SRC/'intervals.csv');q=pd.read_csv(SRC/'beat_quality.csv');b=pd.read_csv(SRC/'ppg_method_beats.csv');b=b[b.fiducial_method=='intersecting_tangent']
    keys=['subject','record_id','beat_index'];m=a.merge(q[keys+['rr_valid']],on=keys,validate='one_to_one')
    strict=a.copy(); strict.loc[~m.rr_valid,NAMES]=np.nan
    missing_feet=(a.carotid_880nm_foot_sample<0)|(a.brachial_880nm_foot_sample<0)
    strict.loc[missing_feet,NAMES[2]]=np.nan
    check=strict.merge(b[keys+NAMES],on=keys,suffixes=('_strict','_method'),validate='one_to_one')
    rows=[]
    ar=aggregate_records(a,NAMES,10);br=aggregate_records(strict,NAMES,10)
    for c in NAMES:
        x,y=check[c+'_strict'],check[c+'_method']
        assert (x.isna()==y.isna()).all() and np.allclose(x.fillna(0),y.fillna(0))
        j=ar[['subject','record_id',c]].merge(br[['subject','record_id',c]],on=['subject','record_id'],suffixes=('_old','_rr'),validate='one_to_one')
        d=abs(j[c+'_old']-j[c+'_rr'])
        rows.append(dict(outcome=c,total_beats=len(a),rr_failed_beats=int((~m.rr_valid).sum()),rr_failed_but_interval_present=int((~m.rr_valid & m[c].notna()).sum()),missing_foot_but_regional_interval_present=int((missing_feet & a[c].notna()).sum()) if c==NAMES[2] else 0,original_valid_records=int(ar[c].notna().sum()),quality_consistent_valid_records=int(br[c].notna().sum()),record_medians_changed=int((d>1e-10).sum()),max_median_change_ms=d.max()))
    pd.DataFrame(rows).to_csv(OUT/'rr_mask_audit.csv',index=False)
    br.to_csv(OUT/'rr_consistent_record_outcomes.csv',index=False)
    iccs=[]
    for label,frame in [('original',ar),('rr_consistent',br)]:
        for c in NAMES:iccs.append(dict(dataset=label,outcome=c,**profile_icc(frame,c)))
    pd.DataFrame(iccs).to_csv(OUT/'icc_profile_reml.csv',index=False)
    # Common-record, common-design OLS arithmetic diagnostic (not a substitute for mixed models).
    f=br.dropna(subset=NAMES).copy();x=np.column_stack([np.ones(len(f)),(f.median_hr_bpm-70)/10,(f.activity_state=='B').astype(float),((f.median_hr_bpm-70)/10)*(f.activity_state=='B'),f.elapsed_recording_time_surrogate_s/60])
    coeff=np.linalg.lstsq(x,f[NAMES].to_numpy(),rcond=None)[0]
    diff=np.linalg.lstsq(x,(f[NAMES[1]]-f[NAMES[0]]).to_numpy(),rcond=None)[0]
    assert np.allclose(diff,coeff[:,1]-coeff[:,0])
    pd.DataFrame({'term':['intercept','hr10','before_activity','hr10_by_before','elapsed_min'],'carotid':coeff[:,0],'brachial':coeff[:,1],'median_of_beat_delays':coeff[:,2],'difference_of_record_medians':diff}).to_csv(OUT/'common_design_coefficient_identity.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False));print(pd.DataFrame(iccs).to_string(index=False))

if __name__=='__main__':main()
