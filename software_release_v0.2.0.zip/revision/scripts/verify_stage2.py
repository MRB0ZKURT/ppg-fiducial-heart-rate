from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

REV=Path(__file__).resolve().parents[1]
OUT=REV/'results/stage2_quality_consistent'
def main():
    p=pd.read_csv(OUT/'comparison_predictions.csv')
    records=pd.read_csv(REV/'results/stage2/rr_consistent_record_outcomes.csv')
    assert not p.duplicated(['subject','record_id','outcome','candidate_model']).any()
    assert (p.subject==p.outer_fold_subject).all()
    assert np.isfinite(p[['observed_ms','predicted_ms','corrected_to_70_bpm_ms']]).all().all()
    maxdiff=0.
    for (outcome,subject),g in p[p.candidate_model=='intercept_only'].groupby(['outcome','subject']):
        expected=records.loc[records.subject!=subject,outcome].mean()
        maxdiff=max(maxdiff,float(abs(g.predicted_ms-expected).max()))
    assert maxdiff<1e-9
    summary=pd.read_csv(OUT/'comparison_summary.csv')
    for _,r in summary.iterrows():
        g=p[(p.outcome==r.outcome)&(p.candidate_model==r.candidate)].copy()
        g['error']=abs(g.predicted_ms-g.observed_ms)
        assert np.isclose(g.groupby('subject').error.mean().mean(),r.equal_participant_mae_ms)
    selection=pd.read_csv(REV/'results/stage2/method_training_selections.csv')
    assert len(selection)==32 and not selection.fallback.any()
    details=pd.read_csv(REV/'results/stage2/method_training_details.csv')
    assert (details.training_participants==31).all()
    assert selection.method.eq('intersecting_tangent').all()
    for _,r in selection.iterrows():
        assert details[(details.held_out==r.subject)&(details.method==r.method)].eligible.iloc[0]
    refit=pd.read_csv(OUT/'refit_checks.csv');assert refit.max_refit_difference_ms.max()<1e-6
    warnings=pd.read_csv(OUT/'mixed_diagnostics.csv').fillna('')
    good=warnings[warnings.model!='unconditional']
    assert good.converged.all() and good.warnings.eq('').all()
    # Explicitly mark generic singular random-intercept estimates as invalid for reporting.
    for directory in [REV/'results/stage2',OUT]:
        v=pd.read_csv(directory/'mixed_variances.csv')
        v['accepted_for_reporting']=v.model!='unconditional'
        v.loc[v.model=='unconditional','icc']=np.nan
        v.to_csv(directory/'mixed_variances.csv',index=False)
    manifest=[] # author manuscript manifest omitted from public software
    assert all(hashlib.sha256(Path(x['source']).read_bytes()).hexdigest()==x['sha256'] for x in manifest)
    checks={'status':'passed','prediction_rows':len(p),'independent_intercept_max_difference_ms':maxdiff,'refit_max_difference_ms':float(refit.max_refit_difference_ms.max()),'outer_method_folds':32,'original_source_files_unchanged':len(manifest),'mixed_models_without_warnings_excluding_rejected_unconditional_fits':len(good),'icc_source':'icc_profile_reml.csv; dense covariance solve verified in audit_rr_and_icc.py','limitations':['Outer-only method selection, not every inner split','Conditional bootstrap, 32 participants','Exploratory candidate intervals are not multiplicity adjusted','See stage3 verification for filter and signed-delay sensitivities']}
    (OUT/'verification.json').write_text(json.dumps(checks,indent=2),encoding='utf-8')
    codepaths=list((REV/'scripts').glob('*.py'))+[REV.parent/'src/senssmarttech/models.py']
    (OUT/'code_hashes.json').write_text(json.dumps({str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in codepaths},indent=2),encoding='utf-8')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':main()
