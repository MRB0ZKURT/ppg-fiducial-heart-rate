from pathlib import Path
import sys,json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
REV=Path(__file__).resolve().parents[1];ROOT=REV.parent
sys.path.insert(0,str(ROOT/'src'))
from senssmarttech.models import _inner_scores,_one_se_choice
OUT=REV/'integrated_v1';FIG=OUT/'figures';DATA=OUT/'supplementary_data'
for d in [OUT,FIG,DATA]:d.mkdir(exist_ok=True)
N=['r_to_carotid_880nm_foot_ms','r_to_brachial_880nm_foot_ms','carotid_to_brachial_880nm_foot_ms']
LABEL=dict(zip(N,['Carotid PAT','Brachial PAT','Brachial–carotid difference']))
CAND=['uncorrected','linear','quadratic','restricted_cubic_spline','gam']
S2=REV/'results/stage2_quality_consistent';S3=REV/'results/stage3'

def main():
    # Recompute every inner fold for the corrected records; retain actual score dispersion.
    f=pd.read_csv(REV/'results/stage2/rr_consistent_record_outcomes.csv');folds=[];scores=[]
    for outcome in N:
        usable=f.dropna(subset=[outcome])
        for held in sorted(usable.subject.unique()):
            train=usable[usable.subject!=held].reset_index(drop=True)
            inner=_inner_scores(train,outcome,CAND,5);chosen=_one_se_choice(inner)
            means={k:np.mean(v) for k,v in inner.items()};best=min(means,key=means.get);se=np.std(inner[best],ddof=1)/np.sqrt(5)
            folds.append(dict(outcome=outcome,subject=held,selected_model=chosen,best_mean_candidate=best,best_mean_rmse=means[best],best_rmse_se=se,baseline_rmse=means['uncorrected'],best_hr_minus_baseline=min(v for k,v in means.items() if k!='uncorrected')-means['uncorrected']))
            for c,values in inner.items():
                for j,v in enumerate(values):scores.append(dict(outcome=outcome,subject=held,candidate=c,inner_fold=j,rmse_ms=v))
        print('Inner fold checks',outcome,flush=True)
    pd.DataFrame(folds).to_csv(DATA/'D01_corrected_outer_selection.csv',index=False)
    pd.DataFrame(scores).to_csv(DATA/'D02_inner_fold_rmse.csv',index=False)
    assert all(x['selected_model']=='uncorrected' for x in folds)
    mapping={
      'D03_participant_errors.csv':S2/'comparison_participants.csv',
      'D04_within_participant.csv':S2/'within_participant.csv',
      'D05_conditional_slopes.csv':S2/'conditional_participant_slopes.csv',
      'D06_mixed_coefficients.csv':S2/'mixed_fixed_effects.csv',
      'D07_filter_coverage.csv':S3/'coverage.csv',
      'D08_outcome_exclusions.csv':S3/'exclusions_nonexclusive.csv',
      'D09_record_retention.csv':S3/'record_retention.csv',
      'D10_native_pairs.csv':REV/'results/stage4/native_wfdb_pairs.csv',
      'D11_collinearity.csv':S2/'hr_collinearity.csv',
      'D12_oracle_diagnostic.csv':S2/'in_sample_linear_diagnostic.csv'}
    for name,source in mapping.items():shutil.copy2(source,DATA/name)
    # Drop rejected unconditional coefficient rows from the shareable coefficient table.
    coef=pd.read_csv(DATA/'D06_mixed_coefficients.csv');coef=coef[coef.model!='unconditional'].copy()
    # Include the final supplementary columns formerly added during document building.
    mask=(coef.model=='original')&(coef.term=='hr10');ix=coef[mask].sort_values('p').index
    assert len(ix)==3
    coef.loc[ix,'p_holm_three_post_activity_hr']=np.minimum(1,np.maximum.accumulate(coef.loc[ix,'p'].to_numpy()*np.arange(len(ix),0,-1)))
    coef.to_csv(DATA/'D06_mixed_coefficients.csv',index=False)
    variances=pd.read_csv(S2/'mixed_variances.csv')
    variances[variances.model!='unconditional'].to_csv(DATA/'D15_random_effect_variances.csv',index=False)
    for source,name in [('hr_only_vs_intercept_summary.csv','D16_hr_only_comparison.csv'),('comparison_summary.csv','D17_contextual_comparisons.csv')]:
        pd.read_csv(S2/source).to_csv(DATA/name,index=False)
    people=f.groupby('subject').agg(records=('record_id','size'),hr_min=('median_hr_bpm','min'),hr_max=('median_hr_bpm','max'),age=('age_years','first'),bmi=('bmi','first')).reset_index();people['hr_span']=people.hr_max-people.hr_min;people.to_csv(DATA/'D13_participant_characteristics.csv',index=False)
    slopes=pd.read_csv(S2/'conditional_participant_slopes.csv');slopes['negative']=slopes.conditional_slope_ms_per10bpm<0
    slopes.groupby(['outcome','state']).agg(participants=('subject','size'),negative_slopes=('negative','sum')).reset_index().to_csv(DATA/'D14_slope_sign_summary.csv',index=False)
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':220})
    fig,ax=plt.subplots(figsize=(8.0,4.6));ax.axis('off')
    boxes=[(.03,.72,.43,.19,'338 records · 32 participants\nPPG fiducials and quality checks'),(.54,.72,.43,.19,'Outer-training method selection\n32 held-out participants'),(.03,.39,.43,.20,'Absolute prediction\nIntercept, HR-only, contextual models'),(.54,.39,.43,.20,'Within-participant normalization\nTraining-derived correction to 70 bpm'),(.19,.06,.62,.18,'Sensitivities: 5 / 8 / 12 Hz and signed delays\nEqual-participant error and cluster uncertainty')]
    for x,y,w,h,t in boxes:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.015',facecolor='#eaf0f5',edgecolor='#526b80',transform=ax.transAxes));ax.text(x+w/2,y+h/2,t,ha='center',va='center',transform=ax.transAxes,fontsize=11)
    for a,b in [((.46,.81),(.54,.81)),((.60,.72),(.245,.59)),((.755,.72),(.755,.59)),((.245,.39),(.39,.24)),((.755,.39),(.61,.24))]:ax.annotate('',xy=b,xytext=a,xycoords='axes fraction',arrowprops={'arrowstyle':'->','color':'#526b80'})
    fig.tight_layout();fig.savefig(FIG/'Figure_1.png');plt.close(fig)
    methods=pd.read_csv(ROOT/'outputs/algorithmic_v2_2026-09-06/ppg_method_summary.csv')
    names=['Tangent','First derivative','Second derivative','Local minimum'];fig,axes=plt.subplots(1,2,figsize=(8.4,4.1))
    axes[0].barh(names,100*methods.record_coverage,color='#416e8c');axes[0].axvline(70,color='#aa5544',ls='--');axes[0].set_xlabel('Complete-outcome record coverage (%)');axes[0].set_xlim(0,105);axes[0].invert_yaxis()
    y=np.arange(4);v=methods.composite_within_record_mad_ms.to_numpy();lo=methods.composite_mad_ci_low_ms.to_numpy();hi=methods.composite_mad_ci_high_ms.to_numpy()
    axes[1].errorbar(v,y,xerr=[v-lo,hi-v],fmt='o',color='#416e8c',capsize=3);axes[1].set_yticks(y,[]);axes[1].invert_yaxis();axes[1].set_xlabel('Composite within-record MAD (ms)');fig.tight_layout();fig.savefig(FIG/'Figure_2.png');plt.close(fig)
    a=pd.read_csv(S2/'comparison_summary.csv');simple=pd.read_csv(S2/'hr_only_vs_intercept_summary.csv');fig,axes=plt.subplots(1,3,figsize=(10,4.6),sharey=True)
    order=['HR-only vs intercept','Linear vs context','Quadratic vs context','Spline vs context','Additive vs context']
    for ax,outcome in zip(axes,N):
        rows=[simple[(simple.outcome==outcome)&(simple.candidate=='hr_only_linear')].iloc[0]]+[a[(a.outcome==outcome)&(a.candidate==c)].iloc[0] for c in CAND[1:]]
        for j,r in enumerate(rows):ax.plot([r.improvement_low_pct,r.improvement_high_pct],[j,j],color='#416e8c');ax.plot(r.improvement_pct,j,'o',color='#b65a3b' if j==0 else '#416e8c')
        ax.axvline(0,color='0.6',lw=1);ax.set_title(LABEL[outcome],fontsize=10);ax.set_xlabel('MAE improvement (%)');ax.grid(axis='x',alpha=.2)
    axes[0].set_yticks(range(5),order);axes[0].invert_yaxis();fig.tight_layout();fig.savefig(FIG/'Figure_3.png');plt.close(fig)
    (OUT/'assets_manifest.json').write_text(json.dumps({'corrected_selection_rows':len(folds),'best_hr_lower_mean_rmse_folds':int(sum(x['best_hr_minus_baseline']<0 for x in folds)),'figures':3,'data_files':17,'native_csv_check':'recomputed under consistent masks'},indent=2))
    print('Assets ready')

if __name__=='__main__':main()
