"""Revision-stage analyses. Originals are read-only; outputs stay in revision/results."""
from pathlib import Path
import hashlib
import json
import sys
import warnings
import numpy as np
import pandas as pd

REV = Path(__file__).resolve().parents[1]
ROOT = REV.parent
sys.path.insert(0, str(ROOT / 'src'))
from senssmarttech.models import CandidateModel, aggregate_records
import statsmodels.formula.api as smf

SRC = ROOT / 'outputs/algorithmic_v2_2026-09-06'
OUT = REV / 'results/stage2'
OUT.mkdir(parents=True, exist_ok=True)
SEED, B = 20261107, 5000
OUTCOMES = ['r_to_carotid_880nm_foot_ms', 'r_to_brachial_880nm_foot_ms', 'carotid_to_brachial_880nm_foot_ms']
METHODS = ['intersecting_tangent', 'max_first_derivative', 'max_second_derivative', 'local_minimum']

def save(frame, name):
    pd.DataFrame(frame).to_csv(OUT / (name + '.csv'), index=False)

def ci(values):
    return tuple(np.quantile(values, [.025, .975]))

def draw(n):
    return np.random.default_rng(SEED).integers(0, n, size=(B, n))

def performance(pred, name):
    pred = pred.copy()
    pred['ae'] = abs(pred.predicted_ms - pred.observed_ms)
    assert not pred.duplicated(['outcome','candidate_model','subject','record_id']).any()
    rows, persons = [], []
    for outcome, group in pred.groupby('outcome'):
        base = group[group.candidate_model == 'uncorrected'].set_index(['subject','record_id'])
        for candidate, g in group.groupby('candidate_model'):
            current = g.set_index(['subject','record_id'])
            assert set(current.index) == set(base.index)
            current = current.loc[base.index]
            assert np.allclose(current.observed_ms, base.observed_ms)
            pair = pd.DataFrame({'base':base.ae,'model':current.ae}).groupby(level='subject').mean()
            boot = pair.to_numpy()[draw(len(pair))].mean(axis=1)
            gains = 100*(boot[:,0]-boot[:,1])/boot[:,0]
            low, high = ci(gains)
            delta_low, delta_high = ci(boot[:,0]-boot[:,1])
            rows.append(dict(outcome=outcome,candidate=candidate,participants=len(pair),records=len(g),record_mae_ms=g.ae.mean(),equal_participant_mae_ms=pair.model.mean(),baseline_equal_mae_ms=pair.base.mean(),improvement_pct=100*(pair.base.mean()-pair.model.mean())/pair.base.mean(),improvement_low_pct=low,improvement_high_pct=high,improvement_ms=pair.base.mean()-pair.model.mean(),improvement_low_ms=delta_low,improvement_high_ms=delta_high))
            for subject,r in pair.iterrows():
                persons.append(dict(outcome=outcome,candidate=candidate,subject=subject,mae_ms=r.model,baseline_mae_ms=r.base))
    save(rows,name+'_summary'); save(persons,name+'_participants')

def within(pred, prefix='within'):
    rows = []
    for (outcome,candidate,subject),g in pred.groupby(['outcome','candidate_model','subject']):
        for state in ['all','A','B']:
            s = g if state == 'all' else g[g.activity_state == state]
            if len(s)<2: continue
            raw,cor,hr = s.observed_ms.to_numpy(),s.corrected_to_70_bpm_ms.to_numpy(),s.heart_rate_bpm.to_numpy()
            rawsd,corsd = np.std(raw,ddof=1),np.std(cor,ddof=1)
            valid = len(s)>=3 and np.ptp(hr)>0
            rawsl = np.polyfit(hr,raw,1)[0]*10 if valid else np.nan
            corsl = np.polyfit(hr,cor,1)[0]*10 if valid else np.nan
            rows.append(dict(outcome=outcome,candidate=candidate,subject=subject,state=state,records=len(s),hr_min=hr.min(),hr_max=hr.max(),hr_span=np.ptp(hr),reference70_outside_person_support=not(hr.min()<=70<=hr.max()),raw_sd_ms=rawsd,corrected_sd_ms=corsd,sd_reduction_ms=rawsd-corsd,sd_reduction_pct=100*(rawsd-corsd)/rawsd if rawsd>0 else np.nan,raw_slope_ms_per10bpm=rawsl,corrected_slope_ms_per10bpm=corsl))
    frame=pd.DataFrame(rows); save(frame,prefix+'_participant')
    summaries=[]
    for (outcome,candidate,state),g in frame.groupby(['outcome','candidate','state']):
        arr=g[['raw_sd_ms','corrected_sd_ms']].to_numpy()
        boot=arr[draw(len(arr))].mean(axis=1)
        low,high=ci(boot[:,0]-boot[:,1])
        summaries.append(dict(outcome=outcome,candidate=candidate,state=state,participants=len(g),raw_mean_sd_ms=arr[:,0].mean(),corrected_mean_sd_ms=arr[:,1].mean(),mean_sd_reduction_ms=(arr[:,0]-arr[:,1]).mean(),reduction_low_ms=low,reduction_high_ms=high,participants_sd_reduced=int((g.sd_reduction_ms>1e-10).sum()),reference70_outside_support=int(g.reference70_outside_person_support.sum())))
    save(summaries,prefix+'_summary')

def simple_comparators(records,pred):
    additions=[]; checks=[]; support=[]
    for outcome in OUTCOMES:
        f=records.dropna(subset=[outcome]).copy()
        for subject in sorted(f.subject.unique()):
            train,test=f[f.subject!=subject],f[f.subject==subject]
            assert subject not in train.subject.values
            y=train[outcome].to_numpy()
            for candidate in ['intercept_only','hr_only_linear']:
                cols=lambda z: np.ones((len(z),1)) if candidate=='intercept_only' else np.column_stack([np.ones(len(z)),z.median_hr_bpm.to_numpy()-70])
                coef=np.linalg.lstsq(cols(train),y,rcond=None)[0]
                yh=cols(test)@coef
                corrected=test[outcome].to_numpy() if candidate=='intercept_only' else test[outcome].to_numpy()-coef[1]*(test.median_hr_bpm.to_numpy()-70)
                for j,(_,r) in enumerate(test.iterrows()):
                    additions.append(dict(subject=subject,record_id=r.record_id,activity_state=r.activity_state,heart_rate_bpm=r.median_hr_bpm,outcome=outcome,candidate_model=candidate,observed_ms=r[outcome],predicted_ms=yh[j],prediction_error_ms=yh[j]-r[outcome],corrected_to_70_bpm_ms=corrected[j],outer_fold_subject=subject))
            support.append(dict(outcome=outcome,subject=subject,training_hr_min=train.median_hr_bpm.min(),training_hr_max=train.median_hr_bpm.max(),reference70_outside_training_support=not(train.median_hr_bpm.min()<=70<=train.median_hr_bpm.max())))
            # Independent refit of every original baseline and all original candidates for subject 1.
            for candidate in (['uncorrected','linear','quadratic','restricted_cubic_spline','gam'] if subject==1 else ['uncorrected']):
                fitted=CandidateModel(candidate).fit(train,y)
                ref=pd.DataFrame({'record_id':test.record_id,'refit':fitted.predict(test),'refit_corrected':test[outcome].to_numpy()-(fitted.predict(test)-fitted.predict(test,reference_hr=70))})
                old=pred[(pred.outcome==outcome)&(pred.subject==subject)&(pred.candidate_model==candidate)]
                m=ref.merge(old,on='record_id',validate='one_to_one')
                assert len(m)==len(test)==len(old)
                err=max(abs(m.refit-m.predicted_ms).max(),abs(m.refit_corrected-m.corrected_to_70_bpm_ms).max())
                assert err<1e-6,(outcome,subject,candidate,err)
                checks.append(dict(outcome=outcome,subject=subject,candidate=candidate,max_refit_difference_ms=err))
    save(checks,'refit_checks'); save(support,'training_hr_support')
    full=pd.concat([pred,pd.DataFrame(additions)],ignore_index=True)
    sel=pd.read_csv(SRC/'model_selection.csv')
    chosen=pred.merge(sel[['outcome','outer_fold_subject','selected_model']],on=['outcome','outer_fold_subject'],validate='many_to_one')
    chosen=chosen[chosen.candidate_model==chosen.selected_model].drop(columns='selected_model').copy()
    chosen['candidate_model']='training_selected'
    full=pd.concat([full,chosen],ignore_index=True)
    save(full,'comparison_predictions')
    performance(full,'comparison'); within(full)
    return full

def method_selection(beats,inventory,pred):
    frames={}; mads={}
    for method in METHODS:
        part=beats[beats.fiducial_method==method]
        frames[method]=aggregate_records(part,OUTCOMES,minimum_beats=10)
        components=[]
        for outcome in OUTCOMES:
            g=part.dropna(subset=[outcome]).groupby(['subject','record_id'])[outcome].agg(lambda x: np.median(abs(x-np.median(x)))).rename('mad').reset_index()
            components.append(g)
        mads[method]=pd.concat(components).groupby(['subject','record_id'],as_index=False)['mad'].median()
    selected=[]; details=[]
    for held in sorted(inventory.subject.unique()):
        subjects=sorted(set(inventory.subject)-{held})
        denominator=len(inventory[inventory.subject!=held])
        rows=[]
        for method in METHODS:
            usable=frames[method].query('subject != @held').dropna(subset=OUTCOMES)
            m=mads[method].query('subject != @held')
            assert held not in m.subject.values and held not in usable.subject.values
            # Original cluster bootstrap, 2000 repetitions and original seed for rule reproduction.
            groups={s:g.mad.to_numpy() for s,g in m.groupby('subject')}
            ids=np.array(list(groups)); rng=np.random.default_rng(20260901)
            estimates=[np.median(np.concatenate([groups[s] for s in rng.choice(ids,len(ids),replace=True)])) for _ in range(2000)]
            low,high=ci(estimates)
            rows.append(dict(held_out=held,method=method,coverage=usable.record_id.nunique()/denominator,mad_ms=m.mad.median(),ci_low=low,ci_high=high,training_participants=len(subjects)))
        best=min(rows,key=lambda r:r['mad_ms']); threshold=best['mad_ms']+(best['ci_high']-best['ci_low'])/3.92
        eligible=[r['method'] for r in rows if r['coverage']>=.7 and r['mad_ms']<=threshold]
        chosen=eligible[0] if eligible else best['method']
        for r in rows:r.update(eligible=r['method'] in eligible,threshold_ms=threshold)
        details.extend(rows); selected.append(dict(subject=held,method=chosen,fallback=not bool(eligible)))
        print('Outer-training method selection',held,chosen,flush=True)
    save(details,'method_training_details'); save(selected,'method_training_selections')
    selections=pd.DataFrame(selected)
    # Always refit: original intervals and method-specific beats differ in RR masking.
    # Inner model choice comes from original method-specific training CV.
    preselected=pd.read_csv(SRC/'ppg_method_model_selection.csv')
    results=[]; chosen_rows=[]
    for r in selected:
        held,method=r['subject'],r['method']
        for outcome in OUTCOMES:
            f=frames[method].dropna(subset=[outcome]); train=f[f.subject!=held]; test=f[f.subject==held]
            chosen=preselected[(preselected.fiducial_method==method)&(preselected.outcome==outcome)&(preselected.outer_fold_subject==held)].iloc[0].selected_model
            for candidate in ['uncorrected','linear','quadratic','restricted_cubic_spline','gam']:
                model=CandidateModel(candidate).fit(train,train[outcome].to_numpy())
                yh=model.predict(test); ref=model.predict(test,reference_hr=70)
                g=pd.DataFrame(dict(subject=held,record_id=test.record_id,activity_state=test.activity_state,heart_rate_bpm=test.median_hr_bpm,outcome=outcome,candidate_model=candidate,observed_ms=test[outcome],predicted_ms=yh,prediction_error_ms=yh-test[outcome],corrected_to_70_bpm_ms=test[outcome]-(yh-ref),outer_fold_subject=held))
                g['selected_fiducial']=method; results.append(g)
                if candidate==chosen:
                    h=g.copy();h['candidate_model']='training_selected';chosen_rows.append(h)
    result=pd.concat(results+chosen_rows,ignore_index=True)
    save(result,'outer_training_method_predictions');performance(result,'outer_training_method')
    within(result,'outer_training_method_within')
    return selections

def explanatory(records):
    rows=[]; fixed=[]; variances=[]; oracle=[]; diag=[]; slopes=[]
    for outcome in OUTCOMES:
        f=records.dropna(subset=[outcome]).copy()
        f['hr10']=(f.median_hr_bpm-70)/10
        f['time_min']=f.elapsed_recording_time_surrogate_s/60
        f['person_hr10']=f.groupby('subject').hr10.transform('mean')
        f['within_hr10']=f.hr10-f.person_hr10
        for label,formula,reformula,reml in [('unconditional',f'{outcome} ~ 1','1',True),('original',f'{outcome} ~ hr10 * C(activity_state) + time_min','~hr10',False),('within_between',f'{outcome} ~ within_hr10 + person_hr10 + C(activity_state) + time_min','~within_hr10',False)]:
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter('always')
                try:
                    fit=smf.mixedlm(formula,f,groups=f.subject,re_formula=reformula).fit(reml=reml,method=['lbfgs','powell','cg'],maxiter=2000)
                    diag.append(dict(outcome=outcome,model=label,converged=bool(fit.converged),warnings='; '.join(sorted(set(str(x.message) for x in w))),use_t=bool(fit.use_t),records=len(f),participants=f.subject.nunique()))
                    conf=fit.conf_int()
                    for term in fit.fe_params.index:
                        fixed.append(dict(outcome=outcome,model=label,term=term,estimate=fit.fe_params[term],se=fit.bse[term],ci_low=conf.loc[term,0],ci_high=conf.loc[term,1],p=fit.pvalues[term]))
                    cov=fit.cov_re.to_numpy()
                    variances.append(dict(outcome=outcome,model=label,intercept_variance=cov[0,0],residual_variance=fit.scale,icc=cov[0,0]/(cov[0,0]+fit.scale) if label=='unconditional' else np.nan,random_slope_sd=np.sqrt(max(cov[1,1],0)) if len(cov)>1 else np.nan,intercept_slope_covariance=cov[0,1] if len(cov)>1 else np.nan))
                    if label=='original':
                        for subject,effect in fit.random_effects.items():
                            for state in ['A','B']:
                                slope=fit.fe_params['hr10']+effect['hr10']+(fit.fe_params.get('hr10:C(activity_state)[T.B]',0) if state=='B' else 0)
                                slopes.append(dict(outcome=outcome,subject=subject,state=state,conditional_slope_ms_per10bpm=slope))
                except Exception as exc:
                    diag.append(dict(outcome=outcome,model=label,converged=False,warnings=f'{type(exc).__name__}: {exc}',use_t=False,records=len(f),participants=f.subject.nunique()))
        for subject,g in f.groupby('subject'):
            x=np.column_stack([np.ones(len(g)),g.hr10]);y=g[outcome].to_numpy()
            yh=x@np.linalg.lstsq(x,y,rcond=None)[0]
            oracle.append(dict(outcome=outcome,subject=subject,records=len(g),intercept_in_sample_mae_ms=np.mean(abs(y-y.mean())),linear_in_sample_mae_ms=np.mean(abs(y-yh)),warning='In-sample linear diagnostic, not universal oracle bound or external performance'))
        for state in ['all','A','B']:
            g=f if state=='all' else f[f.activity_state==state]
            x=pd.DataFrame({'activity_A':(g.activity_state=='A').astype(float),'time_min':g.time_min})
            x=x.loc[:,x.nunique()>1]
            design=np.column_stack([np.ones(len(g)),x]);hr=g.median_hr_bpm.to_numpy(); yh=design@np.linalg.lstsq(design,hr,rcond=None)[0]
            r2=1-np.sum((hr-yh)**2)/np.sum((hr-hr.mean())**2)
            rows.append(dict(outcome=outcome,state=state,records=len(g),hr_context_r2=r2,hr_vif=1/(1-r2),hr_time_correlation=np.corrcoef(hr,g.time_min)[0,1],hr_activity_correlation=np.corrcoef(hr,(g.activity_state=='A').astype(float))[0,1] if state=='all' else np.nan))
    save(rows,'hr_collinearity');save(fixed,'mixed_fixed_effects');save(variances,'mixed_variances');save(diag,'mixed_diagnostics');save(oracle,'in_sample_linear_diagnostic');save(slopes,'conditional_participant_slopes')

def main():
    sources=['intervals.csv','candidate_predictions.csv','ppg_method_beats.csv','record_index.csv','model_selection.csv','ppg_method_model_selection.csv']
    manifest={n:hashlib.sha256((SRC/n).read_bytes()).hexdigest() for n in sources}
    pred=pd.read_csv(SRC/'candidate_predictions.csv'); intervals=pd.read_csv(SRC/'intervals.csv')
    records=aggregate_records(intervals,OUTCOMES,minimum_beats=10)
    save(records,'record_outcomes')
    print('Comparators and within-person summaries',flush=True)
    simple_comparators(records,pred)
    print('Explanatory models',flush=True);explanatory(records)
    print('Training-only PPG selection',flush=True)
    selections=method_selection(pd.read_csv(SRC/'ppg_method_beats.csv'),pd.read_csv(SRC/'record_index.csv'),pred)
    assert all(hashlib.sha256((SRC/n).read_bytes()).hexdigest()==v for n,v in manifest.items())
    result={'source_hashes':manifest,'bootstrap_repetitions_new_metrics':B,'bootstrap_seed_new_metrics':SEED,'method_rule_bootstrap_repetitions':2000,'method_rule_bootstrap_seed':20260901,'method_counts':selections.method.value_counts().to_dict(),'scope':'Outer-training method selection only; not method re-selection in each inner fold. Conditional cluster bootstrap on held-out predictions. Original manuscript unchanged.'}
    (OUT/'manifest.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('Completed',flush=True)

if __name__=='__main__':main()
