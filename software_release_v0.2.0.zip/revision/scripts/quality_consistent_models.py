"""Apply the already specified models after correcting verified quality-mask omissions."""
import json, hashlib
import numpy as np
import pandas as pd
import revision_models as m

def main():
    original=m.OUT
    f=pd.read_csv(original/'rr_consistent_record_outcomes.csv')
    p=pd.read_csv(original/'outer_training_method_predictions.csv')
    assert set(p.selected_fiducial)=={'intersecting_tangent'}
    p=p[p.candidate_model!='training_selected'].copy()
    old=pd.read_csv(m.SRC/'model_selection.csv')
    method=pd.read_csv(m.SRC/'ppg_method_model_selection.csv')
    method=method[method.fiducial_method=='intersecting_tangent']
    pair=old.merge(method,on=['outcome','outer_fold_subject'],suffixes=('_original','_quality'))
    assert len(pair)==96 and (pair.selected_model_original==pair.selected_model_quality).all()
    m.OUT=m.REV/'results/stage2_quality_consistent';m.OUT.mkdir(exist_ok=True)
    m.simple_comparators(f,p)
    m.explanatory(f)
    # Add a direct HR-only versus intercept-only comparison; contextual reference alone is insufficient.
    full=pd.read_csv(m.OUT/'comparison_predictions.csv')
    simple=full[full.candidate_model.isin(['hr_only_linear','intercept_only'])].copy()
    simple.loc[simple.candidate_model=='intercept_only','candidate_model']='uncorrected'
    m.performance(simple,'hr_only_vs_intercept')
    profile=pd.read_csv(original/'icc_profile_reml.csv')
    profile[profile.dataset=='rr_consistent'].to_csv(m.OUT/'icc_profile_reml.csv',index=False)
    pd.read_csv(original/'rr_mask_audit.csv').to_csv(m.OUT/'quality_mask_changes.csv',index=False)
    counts=pd.read_csv(original/'method_training_selections.csv').method.value_counts().to_dict()
    manifest={'status':'complete','method_selection_counts':counts,'quality_changes':['Apply rr_valid before record aggregation','Require both detected foot sample indices >= 0 before computing intersite difference'],'inference':'5000 paired participant bootstrap resamples, seed 20261107; conditional on fitted predictions; exploratory multiple-model comparisons, not multiplicity adjusted','icc':'Use profile REML results. Generic unconditional mixed-model fits emitted singular warnings and are not accepted for ICC reporting.','nesting':'Method chosen in outer training subjects, not reselected inside each inner split.','sources':{n:hashlib.sha256((original/n).read_bytes()).hexdigest() for n in ['rr_consistent_record_outcomes.csv','outer_training_method_predictions.csv']}}
    (m.OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print('Quality-consistent analyses complete')

if __name__=='__main__':main()
