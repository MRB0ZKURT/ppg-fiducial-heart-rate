"""PPG cutoff and signed-delay revision sensitivities; immutable source data/code."""
from pathlib import Path
import os,sys,types,json,hashlib
import numpy as np
import pandas as pd
REV=Path(__file__).resolve().parents[1];ROOT=REV.parent
sys.path.insert(0,str(ROOT/'src'))
import senssmarttech.fiducials as fid
from senssmarttech.signals import read_wfdb_record,bandpass
from senssmarttech.models import aggregate_records,CandidateModel
import revision_models as metrics
SRC=ROOT/'outputs/algorithmic_v2_2026-09-06';OUT=REV/'results/stage3';OUT.mkdir(exist_ok=True)
NAMES=metrics.OUTCOMES;METHODS=metrics.METHODS
META=['subject','record_id','activity_state','median_hr_bpm','elapsed_recording_time_surrogate_s','recovery_segment','age_years','biological_sex','bmi']

def extract():
    original=pd.read_csv(SRC/'ppg_method_beats.csv')
    frames=[];checks=[];failures=[];channels=[]
    for i,(record,g) in enumerate(original[original.fiducial_method=='intersecting_tangent'].groupby('record_id',sort=False)):
        g=g.sort_values('beat_index').reset_index(drop=True); r=g.r_sample.to_numpy(dtype=int)
        try:
            sig=read_wfdb_record(Path(os.environ.get('SENSSMARTTECH_DATASET_ROOT',str(ROOT/'Dataset')))/'WFDB'/f'{record}_ppg.hea')
            assert sig.fs==g.fs_hz.iloc[0]
            channels.append({'record_id':record,'fs':sig.fs,'channels':'|'.join(sig.channel_names)})
            for cutoff in [5,8,12]:
                detections={}
                for site in ['carotid','brachial']:
                    raw=sig.values[:,sig.channel_names.index(f'{site}_880nm')]
                    filtered=bandpass(raw,sig.fs,.5,cutoff)
                    # Clone only detector globals to inject the cutoff-specific filtered signal.
                    # Candidate/window code is unchanged and no shared module state is mutated.
                    def supplied_filter(values,fs,low,high,order=4):
                        assert values is raw and fs==sig.fs and low==.5 and high==8
                        return filtered
                    globals_copy=dict(fid.detect_ppg_feet_with_quality.__globals__)
                    globals_copy['bandpass']=supplied_filter
                    detector=types.FunctionType(fid.detect_ppg_feet_with_quality.__code__,globals_copy,argdefs=fid.detect_ppg_feet_with_quality.__defaults__)
                    for method in METHODS:
                        detections[(site,method)]=detector(raw,r,sig.fs,site,method)
                for method in METHODS:
                    f=g[META+['beat_index','r_sample','rr_valid','fs_hz']].copy()
                    f['cutoff_hz']=cutoff;f['fiducial_method']=method
                    for site,outcome in zip(['carotid','brachial'],NAMES[:2]):
                        d=detections[(site,method)];foot=d.samples
                        f[f'{site}_foot']=foot;f[f'{site}_failure']=d.failure_reason
                        rawpat=(foot-r)*1000/sig.fs
                        f[f'{site}_raw_pat']=np.where(foot>=0,rawpat,np.nan)
                        f[outcome]=np.where(g.rr_valid & (foot>=0)&(rawpat>=50)&(rawpat<=500),rawpat,np.nan)
                        if cutoff==8:
                            old=original[(original.record_id==record)&(original.fiducial_method==method)].sort_values('beat_index')
                            same=np.array_equal(foot,old[f'{site}_880nm_foot_sample'].to_numpy())
                            checks.append({'record_id':record,'method':method,'site':site,'exact_foot_match':same})
                            assert same,(record,method,site)
                    signed=(f.brachial_foot-f.carotid_foot)*1000/sig.fs
                    validfeet=(f.carotid_foot>=0)&(f.brachial_foot>=0)
                    f['signed_delay_ms']=signed.where(validfeet)
                    f[NAMES[2]]=signed.where(validfeet & g.rr_valid & signed.between(10,250))
                    f['signed_bounded_delay_ms']=signed.where(validfeet & g.rr_valid & signed.between(-250,250))
                    frames.append(f)
        except Exception as exc:
            failures.append({'record_id':record,'error':repr(exc)})
            # Do not silently discard partially processed records.
            pd.DataFrame(failures).to_csv(OUT/'extraction_failures.csv',index=False)
            raise
        if (i+1)%30==0:print('PPG records reprocessed',i+1,flush=True)
    allbeats=pd.concat(frames,ignore_index=True)
    allbeats.to_csv(OUT/'filter_beats.csv',index=False)
    pd.DataFrame(checks).to_csv(OUT/'filter8_reproduction_checks.csv',index=False)
    pd.DataFrame(channels).to_csv(OUT/'channel_inventory.csv',index=False)
    assert len(checks)==338*4*2
    return allbeats

def quality(beats):
    rows=[];flows=[];recordrows=[];reasons=[]
    for (cutoff,method),g in beats.groupby(['cutoff_hz','fiducial_method']):
        validrr=g.rr_valid
        for site in ['carotid','brachial']:
            for reason,count in g[f'{site}_failure'].fillna('').value_counts().items():
                reasons.append(dict(cutoff_hz=cutoff,method=method,site=site,reason=reason or 'detected',beats=count))
        for outcome in NAMES+['signed_bounded_delay_ms']:
            site='carotid' if outcome==NAMES[0] else 'brachial'
            isdelay=outcome in [NAMES[2],'signed_bounded_delay_ms']
            feet=(g.carotid_foot>=0)&(g.brachial_foot>=0) if isdelay else g[f'{site}_foot']>=0
            value=g.signed_delay_ms if isdelay else g[f'{site}_raw_pat']
            bounds=(-250,250) if outcome=='signed_bounded_delay_ms' else ((10,250) if isdelay else (50,500))
            inrange=value.between(*bounds)
            accepted=validrr & feet & inrange
            assert accepted.equals(g[outcome].notna())
            masks={'rr_failed':~validrr,'foot_missing':~feet,'below_lower_bound':feet & (value<bounds[0]),'above_upper_bound':feet & (value>bounds[1])}
            left=pd.Series(True,index=g.index)
            for reason,mask in masks.items():
                rows.append(dict(cutoff_hz=cutoff,method=method,outcome=outcome,reason=reason,count=int(mask.sum()),count_type='nonexclusive'))
                take=left & mask;left &= ~mask
                flows.append(dict(cutoff_hz=cutoff,method=method,outcome=outcome,reason=reason,count=int(take.sum()),count_type='sequential_rr_then_feet_then_range'))
            assert left.equals(accepted)
            flows.append(dict(cutoff_hz=cutoff,method=method,outcome=outcome,reason='retained',count=int(left.sum()),count_type='sequential_rr_then_feet_then_range'))
            temp=g.groupby(['subject','record_id']).agg(valid_beats=(outcome,'count'),hr=('median_hr_bpm','first'),activity=('activity_state','first')).reset_index()
            temp['cutoff_hz']=cutoff;temp['method']=method;temp['outcome']=outcome;temp['retained']=temp.valid_beats>=10
            recordrows.append(temp)
    pd.DataFrame(rows).to_csv(OUT/'exclusions_nonexclusive.csv',index=False)
    pd.DataFrame(flows).to_csv(OUT/'exclusions_sequential.csv',index=False)
    pd.DataFrame(reasons).to_csv(OUT/'detector_failure_reasons.csv',index=False)
    rec=pd.concat(recordrows,ignore_index=True);rec.to_csv(OUT/'record_retention.csv',index=False)
    rec.groupby(['cutoff_hz','method','outcome','retained','activity']).agg(records=('record_id','size'),participants=('subject','nunique'),mean_hr=('hr','mean'),median_hr=('hr','median'),min_hr=('hr','min'),max_hr=('hr','max')).reset_index().to_csv(OUT/'retention_hr_activity.csv',index=False)
    cover=rec.groupby(['cutoff_hz','method','outcome']).agg(records=('retained','sum'),total_records=('record_id','size')).reset_index();cover['coverage']=cover.records/cover.total_records
    cover.to_csv(OUT/'coverage.csv',index=False)

def predict(frame,outcome):
    rows=[]
    for held in sorted(frame.subject.unique()):
        train,test=frame[frame.subject!=held],frame[frame.subject==held]
        assert held not in train.subject.values
        for candidate in ['uncorrected','linear','quadratic','restricted_cubic_spline','gam']:
            model=CandidateModel(candidate).fit(train,train[outcome].to_numpy())
            yh=model.predict(test);ref=model.predict(test,reference_hr=70)
            for j,(_,r) in enumerate(test.iterrows()):
                rows.append(dict(subject=held,record_id=r.record_id,activity_state=r.activity_state,heart_rate_bpm=r.median_hr_bpm,outcome=outcome,candidate_model=candidate,observed_ms=r[outcome],predicted_ms=yh[j],corrected_to_70_bpm_ms=r[outcome]-(yh[j]-ref[j]),outer_fold_subject=held))
    return pd.DataFrame(rows)

def evaluate(beats):
    tangent=beats[beats.fiducial_method=='intersecting_tangent']
    frames={c:aggregate_records(g,NAMES+['signed_bounded_delay_ms'],10) for c,g in tangent.groupby('cutoff_hz')}
    metrics.OUT=OUT
    shifts=[];predictions=[];counts=[]
    for outcome in NAMES:
        available={c:f.dropna(subset=[outcome]).copy() for c,f in frames.items()}
        common=set.intersection(*[set(f.record_id) for f in available.values()])
        for scope in ['available','common_all_cutoffs']:
            for cutoff,f in available.items():
                f=f if scope=='available' else f[f.record_id.isin(common)]
                p=predict(f,outcome);p['cutoff_hz']=cutoff;p['scope']=scope;predictions.append(p)
                counts.append(dict(cutoff_hz=cutoff,scope=scope,outcome=outcome,records=len(f),participants=f.subject.nunique()))
        for cutoff in [5,12]:
            pair=available[8][['subject','record_id',outcome]].merge(available[cutoff][['record_id',outcome]],on='record_id',suffixes=('_8','_other'),validate='one_to_one')
            d=pair[outcome+'_other']-pair[outcome+'_8']
            shifts.append(dict(cutoff_hz=cutoff,outcome=outcome,paired_records=len(pair),median_signed_shift_ms=d.median(),median_absolute_shift_ms=abs(d).median(),p95_absolute_shift_ms=abs(d).quantile(.95)))
    p=pd.concat(predictions,ignore_index=True);p.to_csv(OUT/'filter_predictions.csv',index=False)
    for (scope,cutoff),g in p.groupby(['scope','cutoff_hz']):
        metrics.performance(g,f'filter_{cutoff}_{scope}')
    pd.DataFrame(shifts).to_csv(OUT/'filter_record_shifts.csv',index=False)
    pd.DataFrame(counts).to_csv(OUT/'filter_prediction_counts.csv',index=False)
    # Signed-delay analysis and original positive delay use identical record sets in common scope.
    f=frames[8];common=set(f.dropna(subset=[NAMES[2],'signed_bounded_delay_ms']).record_id)
    signed=[]
    for scope in ['available','common_positive_signed']:
        for outcome in [NAMES[2],'signed_bounded_delay_ms']:
            part=f.dropna(subset=[outcome]);part=part if scope=='available' else part[part.record_id.isin(common)]
            q=predict(part,outcome);q['scope']=scope;signed.append(q)
    s=pd.concat(signed,ignore_index=True);s.to_csv(OUT/'signed_predictions.csv',index=False)
    for scope,g in s.groupby('scope'):metrics.performance(g,'signed_'+scope)
    frames[8].to_csv(OUT/'filter8_record_outcomes.csv',index=False)
    # Direct reproduction of the previous quality-consistent predictions at 8 Hz.
    old=pd.read_csv(REV/'results/stage2_quality_consistent/comparison_predictions.csv')
    old=old[old.candidate_model.isin(['uncorrected','linear','quadratic','restricted_cubic_spline','gam'])]
    new=p[(p.cutoff_hz==8)&(p.scope=='available')]
    match=old.merge(new,on=['subject','record_id','outcome','candidate_model'],suffixes=('_old','_new'),validate='one_to_one')
    assert len(match)==len(old)==len(new)
    err=max(abs(match.predicted_ms_old-match.predicted_ms_new).max(),abs(match.observed_ms_old-match.observed_ms_new).max())
    assert err<1e-6,err
    return err

def main():
    source_files=[ROOT/'src/senssmarttech'/n for n in ['signals.py','fiducials.py','models.py']]+[SRC/'ppg_method_beats.csv']
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    beats=extract();quality(beats);err=evaluate(beats)
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in before.items())
    manifest={'status':'complete','source_hashes':before,'cutoffs_hz':[5,8,12],'native_vs_interpolated':'PPG natively 100 Hz; supplied WFDB is 1000 Hz','filter':'Hamming-windowed sinc FIR, forward/reverse; 4001 taps at fs1000 and low0.5; order argument unused','reproduction_8hz_foot_checks':2704,'max_prediction_reproduction_difference_ms':err,'performance':'Fixed candidate models; no cutoff optimized and no new inner model selection performed. Equal participant MAE; 5000 paired participant bootstrap replicates.','common_scope':'Both train and test records restricted to the same intersection across cutoffs; available scope uses outcome-specific eligible records.'}
    (OUT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8');print('Stage3 completed',flush=True)

if __name__=='__main__':main()
