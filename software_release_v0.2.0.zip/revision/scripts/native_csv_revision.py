from pathlib import Path
import os,sys,json,hashlib
import numpy as np
import pandas as pd
REV=Path(__file__).resolve().parents[1];ROOT=REV.parent
sys.path.insert(0,str(ROOT/'src'))
from senssmarttech.fiducials import detect_r_multilead,detect_ppg_feet
NAMES=['r_to_carotid_880nm_foot_ms','r_to_brachial_880nm_foot_ms','carotid_to_brachial_880nm_foot_ms']
OUT=REV/'results/stage4';OUT.mkdir(exist_ok=True)

def main():
    index=pd.read_csv(ROOT/'outputs/algorithmic_v2_2026-09-06/record_index.csv')
    rows=[];audits=[]
    for i,rec in index.iterrows():
        e=pd.read_csv(Path(os.environ.get('SENSSMARTTECH_DATASET_ROOT',str(ROOT/'Dataset')))/'CSV'/f'{rec.record_id}_ecg.csv');p=pd.read_csv(Path(os.environ.get('SENSSMARTTECH_DATASET_ROOT',str(ROOT/'Dataset')))/'CSV'/f'{rec.record_id}_ppg.csv')
        et=e.iloc[:,0].to_numpy(float);pt=p.iloc[:,0].to_numpy(float)
        efs=1000/np.median(np.diff(et));pfs=1000/np.median(np.diff(pt))
        rs=detect_r_multilead(e.iloc[:,1:].to_numpy(float),efs).samples;rt=et[rs]
        rr=np.r_[np.diff(rt)[0],np.diff(rt)] if len(rt)>1 else np.full(len(rt),np.nan)
        rrvalid=(rr>=300)&(rr<=1500)
        pr=np.searchsorted(pt,rt);inside=(pr>0)&(pr<len(pt)-1)
        pr,rt,rrvalid=pr[inside],rt[inside],rrvalid[inside]
        cf=detect_ppg_feet(p.carotid_880nm.to_numpy(float),pr,pfs,'carotid')
        bf=detect_ppg_feet(p.brachial_880nm.to_numpy(float),pr,pfs,'brachial')
        ct=np.full(len(cf),np.nan);bt=ct.copy()
        ct[cf>=0]=pt[cf[cf>=0]];bt[bf>=0]=pt[bf[bf>=0]]
        values=[ct-rt,bt-rt,bt-ct]
        row={'subject':rec.subject,'record_id':rec.record_id,'ecg_native_fs_hz':efs,'ppg_native_fs_hz':pfs}
        for name,value,(low,high) in zip(NAMES,values,[(50,500),(50,500),(10,250)]):
            good=rrvalid & np.isfinite(value)&(value>=low)&(value<=high)
            row[name]=np.median(value[good]) if good.sum()>=10 else np.nan
            row[name+'_valid_beats']=int(good.sum())
        rows.append(row);audits.append({'record_id':rec.record_id,'r_beats_in_ppg_range':len(rt),'invalid_rr':int((~rrvalid).sum()),'missing_carotid':int((cf<0).sum()),'missing_brachial':int((bf<0).sum())})
        if (i+1)%50==0:print('Native CSV records',i+1,flush=True)
    frame=pd.DataFrame(rows);frame.to_csv(OUT/'native_csv_records.csv',index=False)
    pd.DataFrame(audits).to_csv(OUT/'native_csv_quality.csv',index=False)
    wfdb=pd.read_csv(REV/'results/stage2/rr_consistent_record_outcomes.csv')
    pair=frame.merge(wfdb[['subject','record_id']+NAMES],on=['subject','record_id'],suffixes=('_csv','_wfdb'),validate='one_to_one')
    summary=[]
    for name in NAMES:
        g=pair.dropna(subset=[name+'_csv',name+'_wfdb']);d=g[name+'_csv']-g[name+'_wfdb']
        summary.append({'outcome':name,'paired_records':len(g),'csv_valid_records':int(frame[name].notna().sum()),'wfdb_valid_records':int(wfdb[name].notna().sum()),'median_signed_difference_ms':d.median(),'median_absolute_difference_ms':abs(d).median(),'p95_absolute_difference_ms':abs(d).quantile(.95),'pearson_r':g[[name+'_csv',name+'_wfdb']].corr().iloc[0,1]})
    pair.to_csv(OUT/'native_wfdb_pairs.csv',index=False);pd.DataFrame(summary).to_csv(OUT/'native_wfdb_summary.csv',index=False)
    (OUT/'native_manifest.json').write_text(json.dumps({'status':'complete','records':len(frame),'quality':'RR 300–1500 ms; foot indices >=0; PAT50–500, delay10–250; >=10 beats both native and WFDB','scope':'Native ECG detection, searchsorted timestamp mapping, native 100 Hz PPG versus interpolated WFDB; not a ground-truth accuracy validation','failures':0},indent=2))
    print(pd.DataFrame(summary).to_string(index=False))

if __name__=='__main__':main()
