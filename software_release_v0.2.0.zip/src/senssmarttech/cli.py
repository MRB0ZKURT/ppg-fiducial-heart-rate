from __future__ import annotations

import argparse
import json

from .algorithmic_validation import (
    run_algorithmic_validation,
    run_ppg_method_sensitivity,
    run_qtdb_qrs_onset_validation,
)
from .audit import run_audit
from .config import load_config
from .csv_sensitivity import run_csv_timing_sensitivity
from .external import restore_frozen_external_pilot
from .extract import run_extraction
from .mixed_effects import run_mixed_effects
from .models import run_analysis
from .reporting import generate_preliminary_reports
from .verify import verify_outputs

LEGACY_ANNOTATION_WARNING = (
    "WARNING: this human-annotation command is deprecated experimental provenance "
    "and is not part of the active protocol."
)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="senssmarttech")
    parser.add_argument("--config", default="config/analysis_config.yaml")
    subparsers = parser.add_subparsers(dest="command", required=True)
    audit = subparsers.add_parser("audit")
    audit.add_argument("--verify-checksums", action="store_true")
    subparsers.add_parser("select-annotations")
    subparsers.add_parser("prepare-annotation-packet")
    score = subparsers.add_parser("score-annotations")
    score.add_argument("--rater-1", required=True)
    score.add_argument("--rater-2", required=True)
    annotate = subparsers.add_parser("annotate")
    annotate.add_argument("--mode", choices=["training", "validation", "adjudication"], required=True)
    annotate.add_argument("--rater", type=int, choices=[1, 2])
    annotate.add_argument("--host", default="127.0.0.1")
    annotate.add_argument("--port", type=int, default=8765)
    annotate.add_argument("--no-browser", action="store_true")
    extract = subparsers.add_parser("extract")
    extract.add_argument("--limit", type=int)
    subparsers.add_parser("analyze")
    subparsers.add_parser("external-pilot")
    subparsers.add_parser("report")
    subparsers.add_parser("csv-sensitivity")
    subparsers.add_parser("mixed-effects")
    subparsers.add_parser("algorithmic-validation")
    subparsers.add_parser("ppg-method-sensitivity")
    subparsers.add_parser("qtdb-validation")
    subparsers.add_parser("verify")
    return parser


def main() -> None:
    args = _parser().parse_args()
    config = load_config(args.config)
    if args.command == "audit":
        result = run_audit(config, verify_checksums=args.verify_checksums)
    elif args.command == "select-annotations":
        from .annotations import select_annotation_records

        print(LEGACY_ANNOTATION_WARNING)
        result = select_annotation_records(config)
    elif args.command == "prepare-annotation-packet":
        from .annotations import prepare_annotation_packet

        print(LEGACY_ANNOTATION_WARNING)
        result = prepare_annotation_packet(config)
    elif args.command == "score-annotations":
        from .annotation_scoring import score_completed_annotations

        print(LEGACY_ANNOTATION_WARNING)
        result = score_completed_annotations(config, args.rater_1, args.rater_2)
    elif args.command == "annotate":
        from .annotation_app import run_annotation_app

        print(LEGACY_ANNOTATION_WARNING)
        run_annotation_app(
            config,
            mode=args.mode,
            rater=args.rater,
            host=args.host,
            port=args.port,
            open_browser=not args.no_browser,
        )
        return
    elif args.command == "extract":
        result = run_extraction(config, limit=args.limit)
    elif args.command == "analyze":
        result = run_analysis(config)
    elif args.command == "external-pilot":
        result = restore_frozen_external_pilot(config)
    elif args.command == "report":
        result = generate_preliminary_reports(config)
    elif args.command == "csv-sensitivity":
        result = run_csv_timing_sensitivity(config)
    elif args.command == "mixed-effects":
        result = run_mixed_effects(config)
    elif args.command == "algorithmic-validation":
        result = run_algorithmic_validation(config)
    elif args.command == "ppg-method-sensitivity":
        result = run_ppg_method_sensitivity(config)
    elif args.command == "qtdb-validation":
        result = run_qtdb_qrs_onset_validation(config)
    else:
        result = verify_outputs(config)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
