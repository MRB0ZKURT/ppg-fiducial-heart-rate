from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .config import project_path
from .extract import PPG_CHANNELS
from .fiducials import (
    PPG_FOOT_METHODS,
    detect_ppg_feet_with_quality,
    detect_q_onsets_wavelet,
    detect_r_multilead,
)
from .metadata import read_demographics
from .models import aggregate_records, nested_loso, summarize_candidate_performance
from .pcg_reference_adapter import read_physionet_2016_hand_corrected_record
from .quality import robust_snr_db, valid_rr_mask
from .signals import read_wfdb_record
from .tables import write_json, write_records

PRIMARY = (
    "r_to_carotid_880nm_foot_ms",
    "r_to_brachial_880nm_foot_ms",
    "carotid_to_brachial_880nm_foot_ms",
)


def _channel_index(names: tuple[str, ...], expected: str) -> int:
    normalized = {name.lower().replace("-", "_"): index for index, name in enumerate(names)}
    key = expected.lower().replace("-", "_")
    if key not in normalized:
        raise KeyError(f"Channel {expected} not found in {names}")
    return normalized[key]


def _signed_ms(samples: int, fs: float) -> float:
    return float(samples * 1000.0 / fs)


def _bootstrap_median_ci(
    frame: pd.DataFrame,
    value_column: str,
    group_column: str,
    repetitions: int,
    seed: int,
) -> tuple[float, float, float]:
    usable = frame[[group_column, value_column]].dropna()
    if usable.empty:
        return float("nan"), float("nan"), float("nan")
    grouped = {
        group: np.asarray(part[value_column], dtype=float)
        for group, part in usable.groupby(group_column)
    }
    groups = np.asarray(list(grouped), dtype=object)
    rng = np.random.default_rng(seed)
    estimates = np.empty(repetitions, dtype=float)
    for iteration in range(repetitions):
        sampled = rng.choice(groups, size=groups.size, replace=True)
        values = np.concatenate([grouped[group] for group in sampled])
        estimates[iteration] = float(np.median(values))
    return (
        float(np.median(np.asarray(usable[value_column], dtype=float))),
        float(np.quantile(estimates, 0.025)),
        float(np.quantile(estimates, 0.975)),
    )


def run_ppg_method_sensitivity(config: dict[str, Any]) -> dict[str, object]:
    """Compare fixed PPG foot definitions without using HR effects for selection."""
    output_root = project_path(config, config["paths"]["output_root"])
    wfdb_root = project_path(config, config["paths"]["wfdb_root"])
    records = read_demographics(project_path(config, config["paths"]["demographics"]))
    methods = tuple(config["algorithmic_validation"]["ppg"]["methods"])
    if methods != PPG_FOOT_METHODS:
        raise ValueError("Configured PPG methods must match the frozen implementation order")
    rows: list[dict[str, object]] = []
    failures: list[dict[str, str]] = []
    for record in records:
        try:
            ecg = read_wfdb_record(wfdb_root / f"{record.record_id}_ecg.hea")
            ppg = read_wfdb_record(wfdb_root / f"{record.record_id}_ppg.hea")
            r_detection = detect_r_multilead(ecg.values, ecg.fs)
            r = r_detection.samples
            rr_valid = valid_rr_mask(
                r,
                ecg.fs,
                config["quality"]["rr_min_ms"],
                config["quality"]["rr_max_ms"],
            )
            detections: dict[tuple[str, str, str], Any] = {}
            for site, wavelength, channel in PPG_CHANNELS:
                signal = ppg.values[:, _channel_index(ppg.channel_names, channel)]
                for method in methods:
                    detections[(method, site, wavelength)] = detect_ppg_feet_with_quality(
                        signal, r, ppg.fs, site, method
                    )
            for method in methods:
                for beat, r_sample in enumerate(r):
                    row: dict[str, object] = {
                        "subject": record.subject,
                        "record_id": record.record_id,
                        "activity_state": record.activity_state,
                        "median_hr_bpm": record.median_hr_bpm,
                        "elapsed_recording_time_surrogate_s": record.elapsed_recording_time_surrogate_s,
                        "recovery_segment": record.recovery_segment,
                        "age_years": record.age_years,
                        "biological_sex": record.sex,
                        "bmi": record.bmi,
                        "fiducial_method": method,
                        "beat_index": beat,
                        "r_sample": int(r_sample),
                        "rr_valid": bool(rr_valid[beat]),
                        "source": "WFDB",
                        "fs_hz": ppg.fs,
                    }
                    for site, wavelength, _ in PPG_CHANNELS:
                        detection = detections[(method, site, wavelength)]
                        foot = int(detection.samples[beat])
                        label = f"{site}_{wavelength}"
                        pat = _signed_ms(foot - int(r_sample), ppg.fs) if foot >= 0 else np.nan
                        row[f"{label}_foot_sample"] = foot
                        row[f"{label}_foot_confidence"] = float(detection.confidence[beat])
                        row[f"{label}_foot_failure_reason"] = detection.failure_reason[beat]
                        row[f"r_to_{label}_foot_ms"] = (
                            pat if rr_valid[beat] and 50 <= pat <= 500 else np.nan
                        )
                    for wavelength in ("880nm", "660nm"):
                        carotid = int(detections[(method, "carotid", wavelength)].samples[beat])
                        brachial = int(detections[(method, "brachial", wavelength)].samples[beat])
                        delta = _signed_ms(brachial - carotid, ppg.fs) if min(carotid, brachial) >= 0 else np.nan
                        row[f"carotid_to_brachial_{wavelength}_signed_ms"] = delta
                        row[f"carotid_to_brachial_{wavelength}_foot_ms"] = (
                            delta if rr_valid[beat] and 10 <= delta <= 250 else np.nan
                        )
                    rows.append(row)
        except Exception as exc:  # noqa: BLE001 - failures are an analysis outcome
            failures.append({"record_id": record.record_id, "error": f"{type(exc).__name__}: {exc}"})

    beats = pd.DataFrame(rows)
    beat_path = write_records(rows, output_root / "ppg_method_beats.parquet")
    failure_path = write_records(failures, output_root / "ppg_method_failures.parquet")
    comparisons: list[dict[str, object]] = []
    reference = beats[beats["fiducial_method"] == "intersecting_tangent"]
    keys = ["subject", "record_id", "beat_index"]
    for method in methods:
        current = beats[beats["fiducial_method"] == method]
        joined = reference.merge(current, on=keys, suffixes=("_reference", "_current"))
        for site, wavelength, _ in PPG_CHANNELS:
            column = f"{site}_{wavelength}_foot_sample"
            valid = (joined[f"{column}_reference"] >= 0) & (joined[f"{column}_current"] >= 0)
            difference = (
                joined.loc[valid, f"{column}_current"] - joined.loc[valid, f"{column}_reference"]
            ) * 1000.0 / joined.loc[valid, "fs_hz_current"]
            comparisons.append(
                {
                    "fiducial_method": method,
                    "quantity": f"{site}_{wavelength}_foot",
                    "matched_beats": int(valid.sum()),
                    "matched_fraction": float(valid.mean()),
                    "median_signed_difference_ms": float(difference.median()) if len(difference) else np.nan,
                    "median_absolute_difference_ms": float(difference.abs().median()) if len(difference) else np.nan,
                    "p95_absolute_difference_ms": float(difference.abs().quantile(0.95)) if len(difference) else np.nan,
                }
            )
        for outcome in PRIMARY:
            valid = joined[f"{outcome}_reference"].notna() & joined[f"{outcome}_current"].notna()
            difference = joined.loc[valid, f"{outcome}_current"] - joined.loc[valid, f"{outcome}_reference"]
            comparisons.append(
                {
                    "fiducial_method": method,
                    "quantity": outcome,
                    "matched_beats": int(valid.sum()),
                    "matched_fraction": float(valid.mean()),
                    "median_signed_difference_ms": float(difference.median()) if len(difference) else np.nan,
                    "median_absolute_difference_ms": float(difference.abs().median()) if len(difference) else np.nan,
                    "p95_absolute_difference_ms": float(difference.abs().quantile(0.95)) if len(difference) else np.nan,
                }
            )
    comparison_path = write_records(comparisons, output_root / "ppg_method_comparison.parquet")

    minimum_beats = int(config["quality"]["minimum_valid_beats_per_record"])
    method_summaries: list[dict[str, object]] = []
    record_frames: dict[str, pd.DataFrame] = {}
    for method in methods:
        part = beats[beats["fiducial_method"] == method]
        records_frame = aggregate_records(part, list(PRIMARY), minimum_beats=minimum_beats)
        record_frames[method] = records_frame
        beat_mads: list[pd.DataFrame] = []
        for outcome in PRIMARY:
            temp = part.dropna(subset=[outcome]).groupby(["subject", "record_id"])[outcome].agg(
                lambda values: float(np.median(np.abs(values - np.median(values))))
            ).rename("mad_ms").reset_index()
            temp["outcome"] = outcome
            beat_mads.append(temp)
        mad_frame = pd.concat(beat_mads, ignore_index=True)
        subject_record_mad = mad_frame.groupby(["subject", "record_id"], as_index=False)["mad_ms"].median()
        median_mad, ci_low, ci_high = _bootstrap_median_ci(
            subject_record_mad,
            "mad_ms",
            "subject",
            int(config["algorithmic_validation"]["ppg"]["bootstrap_repetitions"]),
            int(config["study"]["random_seed"]),
        )
        valid_records = records_frame.dropna(subset=list(PRIMARY), how="any")
        method_summaries.append(
            {
                "fiducial_method": method,
                "beats": len(part),
                "primary_complete_beat_fraction": float(part[list(PRIMARY)].notna().all(axis=1).mean()),
                "records_with_all_primary_outcomes": int(valid_records["record_id"].nunique()),
                "record_coverage": float(valid_records["record_id"].nunique() / len(records)),
                "subjects_with_all_primary_outcomes": int(valid_records["subject"].nunique()),
                "composite_within_record_mad_ms": median_mad,
                "composite_mad_ci_low_ms": ci_low,
                "composite_mad_ci_high_ms": ci_high,
            }
        )
    summaries = pd.DataFrame(method_summaries)
    best_row = summaries.loc[summaries["composite_within_record_mad_ms"].idxmin()]
    best_se = float((best_row["composite_mad_ci_high_ms"] - best_row["composite_mad_ci_low_ms"]) / 3.92)
    minimum_coverage = float(config["algorithmic_validation"]["ppg"]["minimum_record_coverage"])
    eligible = summaries[
        (summaries["record_coverage"] >= minimum_coverage)
        & (summaries["composite_within_record_mad_ms"] <= best_row["composite_within_record_mad_ms"] + best_se)
    ]
    complexity = {name: index for index, name in enumerate(methods)}
    selected = min(eligible["fiducial_method"], key=lambda value: complexity[value]) if len(eligible) else str(best_row["fiducial_method"])
    summary_path = write_records(method_summaries, output_root / "ppg_method_summary.parquet")

    model_selections: list[dict[str, object]] = []
    performances: list[dict[str, object]] = []
    for method, frame in record_frames.items():
        for outcome in PRIMARY:
            usable = frame.dropna(subset=[outcome]).reset_index(drop=True)
            if usable["subject"].nunique() < config["quality"]["minimum_subjects_primary"]:
                continue
            _, selections, candidate_predictions = nested_loso(usable, outcome, config)
            for item in selections:
                item["fiducial_method"] = method
            model_selections.extend(selections)
            candidate_frame = pd.DataFrame(candidate_predictions)
            for item in summarize_candidate_performance(
                candidate_frame,
                int(config["algorithmic_validation"]["ppg"]["bootstrap_repetitions"]),
                int(config["study"]["random_seed"]),
            ):
                item["fiducial_method"] = method
                performances.append(item)
    selection_path = write_records(model_selections, output_root / "ppg_method_model_selection.parquet")
    performance_path = write_records(performances, output_root / "ppg_method_candidate_performance.parquet")
    configured = config["algorithmic_validation"]["ppg"]["selected_method"]
    manifest = {
        "status": "complete",
        "methods": list(methods),
        "wavelet_method": config["algorithmic_validation"]["ppg"]["wavelet_status"],
        "selection_criterion": config["algorithmic_validation"]["ppg"]["selection_rule"],
        "selection_does_not_use_hr_effect": True,
        "best_repeatability_method": str(best_row["fiducial_method"]),
        "selected_method_by_frozen_rule": selected,
        "configured_primary_method": configured,
        "configured_method_matches_rule": bool(selected == configured),
        "records_failed": len(failures),
        "failure_table": str(failure_path),
        "beat_table": str(beat_path),
        "comparison_table": str(comparison_path),
        "summary_table": str(summary_path),
        "model_selection_table": str(selection_path),
        "candidate_performance_table": str(performance_path),
    }
    write_json(manifest, output_root / "ppg_method_sensitivity_manifest.json")
    return manifest


def _qrs_reference_pairs(annotation: Any, fs: float) -> tuple[np.ndarray, np.ndarray]:
    samples = np.asarray(annotation.sample, dtype=int)
    symbols = np.asarray(annotation.symbol, dtype=object)
    nums = np.asarray(annotation.num, dtype=int)
    onsets = np.flatnonzero((symbols == "(") & (nums == 1))
    qrs_onsets: list[int] = []
    r_anchors: list[int] = []
    for index in onsets:
        following = np.arange(index + 1, min(index + 5, samples.size))
        candidates = [
            position
            for position in following
            if symbols[position] not in {"(", ")", "p", "t", "u"}
            and 0 < samples[position] - samples[index] <= int(0.20 * fs)
        ]
        if candidates:
            qrs_onsets.append(int(samples[index]))
            r_anchors.append(int(samples[candidates[0]]))
    return np.asarray(qrs_onsets, dtype=int), np.asarray(r_anchors, dtype=int)


def _run_qtdb_annotator(root: Path, annotator: str) -> tuple[list[dict[str, object]], list[dict[str, str]]]:
    import wfdb

    rows: list[dict[str, object]] = []
    failures: list[dict[str, str]] = []
    for annotation_path in sorted(root.glob(f"*.{annotator}")):
        stem = annotation_path.stem
        try:
            record = wfdb.rdrecord(str(root / stem))
            annotation = wfdb.rdann(str(root / stem), annotator)
            reference, anchors = _qrs_reference_pairs(annotation, float(record.fs))
            if reference.size == 0:
                raise ValueError("no QRS-onset/reference-anchor pairs")
            lead_scores = [robust_snr_db(record.p_signal[:, lead]) for lead in range(record.n_sig)]
            lead = int(np.argmax(lead_scores))
            predicted = detect_q_onsets_wavelet(record.p_signal[:, lead], anchors, float(record.fs))
            for beat, (onset, anchor, estimate) in enumerate(zip(reference, anchors, predicted, strict=True)):
                error = (int(estimate) - int(onset)) * 1000.0 / float(record.fs) if estimate >= 0 else np.nan
                rows.append(
                    {
                        "dataset": "QT Database 1.0.0",
                        "record_id": stem,
                        "reference_annotator": annotator,
                        "beat_index": beat,
                        "reference_qrs_onset_sample": int(onset),
                        "reference_qrs_anchor_sample": int(anchor),
                        "estimated_qrs_onset_sample": int(estimate),
                        "error_ms": error,
                        "absolute_error_ms": abs(error) if np.isfinite(error) else np.nan,
                        "selected_lead": lead,
                        "fs_hz": float(record.fs),
                    }
                )
        except Exception as exc:  # noqa: BLE001 - retained as validation missingness
            failures.append({"record_id": stem, "annotator": annotator, "error": f"{type(exc).__name__}: {exc}"})
    return rows, failures


def run_qtdb_qrs_onset_validation(config: dict[str, Any]) -> dict[str, object]:
    root = project_path(config, "external_data/qtdb-1.0.0")
    output_root = project_path(config, config["paths"]["output_root"])
    settings = config["algorithmic_validation"]["qtdb_qrs_onset"]
    all_rows: list[dict[str, object]] = []
    all_failures: list[dict[str, str]] = []
    summaries: list[dict[str, object]] = []
    for annotator in (settings["reference_annotator"], settings["sensitivity_annotator"]):
        rows, failures = _run_qtdb_annotator(root, annotator)
        all_rows.extend(rows)
        all_failures.extend(failures)
        frame = pd.DataFrame(rows)
        if frame.empty:
            summaries.append({"reference_annotator": annotator, "status": "no_usable_annotations"})
            continue
        detected = frame["absolute_error_ms"].notna()
        usable = frame.loc[detected]
        median_error, ci_low, ci_high = _bootstrap_median_ci(
            usable,
            "absolute_error_ms",
            "record_id",
            int(settings["bootstrap_repetitions"]),
            int(config["study"]["random_seed"]),
        )
        summaries.append(
            {
                "reference_annotator": annotator,
                "records": int(frame["record_id"].nunique()),
                "reference_beats": len(frame),
                "detection_coverage": float(detected.mean()),
                "median_absolute_error_ms": median_error,
                "median_absolute_error_ci_low_ms": ci_low,
                "median_absolute_error_ci_high_ms": ci_high,
                "mean_signed_error_ms": float(usable["error_ms"].mean()),
                "p95_absolute_error_ms": float(usable["absolute_error_ms"].quantile(0.95)),
                "within_10ms_fraction": float((usable["absolute_error_ms"] <= 10).mean()),
                "within_20ms_fraction": float((usable["absolute_error_ms"] <= 20).mean()),
                "within_30ms_fraction": float((usable["absolute_error_ms"] <= 30).mean()),
            }
        )
    beat_path = write_records(all_rows, output_root / "qtdb_qrs_onset_validation.parquet")
    failure_path = write_records(all_failures, output_root / "qtdb_qrs_onset_failures.parquet")
    summary_path = write_records(summaries, output_root / "qtdb_qrs_onset_summary.parquet")
    primary = next(
        (row for row in summaries if row.get("reference_annotator") == settings["reference_annotator"]),
        {},
    )
    passed = bool(
        primary.get("detection_coverage", 0) >= settings["minimum_detection_coverage"]
        and primary.get("median_absolute_error_ms", np.inf) <= settings["maximum_median_absolute_error_ms"]
        and primary.get("within_30ms_fraction", 0) >= settings["minimum_within_30ms_fraction"]
    )
    manifest = {
        "status": "complete_passed" if passed else "complete_failed",
        "dataset": settings["dataset"],
        "dataset_doi": settings["doi"],
        "primary_reference": settings["reference_annotator"],
        "sensitivity_reference": settings["sensitivity_annotator"],
        "primary_gate_passed": passed,
        "thresholds_were_not_changed_after_results": True,
        "record_level_bootstrap_repetitions": int(settings["bootstrap_repetitions"]),
        "beat_table": str(beat_path),
        "summary_table": str(summary_path),
        "failure_table": str(failure_path),
        "summaries": summaries,
    }
    write_json(manifest, output_root / "qtdb_qrs_onset_manifest.json")
    return manifest


def write_pcg_external_validation_assessment(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    settings = config["algorithmic_validation"]["pcg"]
    sample_root = project_path(config, "external_validation/pcg_2016_adapter_sample")
    wav_path = sample_root / "a0001.wav"
    annotation_path = sample_root / "a0001_StateAns.mat"
    adapter_status = "sample_not_available"
    adapter_observation: dict[str, object] = {}
    if wav_path.exists() and annotation_path.exists():
        sample = read_physionet_2016_hand_corrected_record(wav_path, annotation_path)
        adapter_status = "verified_on_open_sample"
        adapter_observation = {
            "sampling_frequency_hz": sample.sampling_frequency_hz,
            "samples": int(sample.signal.size),
            "s1_boundaries": int(sample.s1_start_samples.size),
            "s2_boundaries": int(sample.s2_start_samples.size),
        }
    payload = {
        "status": "not_run_incompatible_reference",
        "candidate_dataset": settings["candidate_dataset"],
        "candidate_dataset_url": "https://physionet.org/content/challenge-2016/1.0.0/",
        "reference_available": "single-reviewer hand-corrected S1/systole/S2/diastole state intervals",
        "study_detector_requirement": "synchronized ECG R anchors plus PCG envelope peak localization",
        "blocker": settings["blocker"],
        "adapter_status": adapter_status,
        "adapter_observation": adapter_observation,
        "frozen_experiment_specification": str(
            project_path(config, "external_validation/pcg_reference_experiment.md")
        ),
        "domain_shift": [
            "single-site clinical/nonclinical PCG versus synchronized post-exercise chest PCG",
            "mixed healthy/pathological population versus healthy volunteers",
            "2 kHz resampled WAV and state intervals versus 1 kHz synchronized point fiducials",
        ],
        "claim": "No external S1/S2 point-accuracy result is asserted.",
    }
    write_json(payload, output_root / "pcg_external_validation_assessment.json")
    return payload


def run_algorithmic_validation(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    qtdb_path = output_root / "qtdb_qrs_onset_manifest.json"
    ppg_path = output_root / "ppg_method_sensitivity_manifest.json"
    qtdb = (
        json.loads(qtdb_path.read_text(encoding="utf-8"))
        if qtdb_path.exists()
        else run_qtdb_qrs_onset_validation(config)
    )
    ppg = (
        json.loads(ppg_path.read_text(encoding="utf-8"))
        if ppg_path.exists()
        else run_ppg_method_sensitivity(config)
    )
    pcg = write_pcg_external_validation_assessment(config)
    payload = {
        "method_version": config["study"]["method_version"],
        "status": "complete" if ppg["configured_method_matches_rule"] else "configuration_mismatch",
        "human_annotation_required": False,
        "qtdb_qrs_onset": qtdb["status"],
        "ppg_multimethod": ppg["status"],
        "ppg_selected_method": ppg["selected_method_by_frozen_rule"],
        "pcg_external": pcg["status"],
        "scg_reference": "no_external_physiological_reference; proxy-only interpretation",
        "completion_gate_passed": bool(
            ppg["configured_method_matches_rule"]
            and ppg["status"] == "complete"
            and qtdb["status"].startswith("complete_")
        ),
    }
    write_json(payload, output_root / "algorithmic_validation_manifest.json")
    return payload
