from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

import numpy as np

from .config import project_path
from .tables import write_json


def _active_scg_terminology_check(project_root: Path) -> tuple[bool, list[str]]:
    files = [
        project_root / "config/analysis_config.yaml",
        project_root / "src/senssmarttech/extract.py",
        project_root / "src/senssmarttech/fiducials.py",
        project_root / "README.md",
        project_root / "PROJECT_STATUS.md",
        project_root / "protocol/preregistration.md",
        project_root / "manuscript/manuscript.md",
        project_root / "docs/data_dictionary.md",
    ]
    forbidden = ("q_to_avo_ms", "avo_to_avc_ms", '"avo_sample"', '"avc_sample"')
    findings: list[str] = []
    for path in files:
        text = path.read_text(encoding="utf-8")
        for token in forbidden:
            if token in text:
                findings.append(f"{path.name}:{token}")
    return not findings, findings


def _submission_consistency_check(project_root: Path) -> tuple[bool, dict[str, bool]]:
    manuscript = (project_root / "manuscript/manuscript.md").read_text(encoding="utf-8")
    declarations = (project_root / "submission/declarations.md").read_text(encoding="utf-8")
    release = (project_root / "open_science/release_manifest.md").read_text(encoding="utf-8")
    metadata = json.loads(
        (project_root / "open_science/zenodo_metadata.json").read_text(encoding="utf-8")
    )
    checks = {
        "author_order_matches_credits": [item["name"] for item in metadata["creators"]]
        == ["Bozkurt, Ferda", "Bozkurt, Mehmet Recep", "Atasever, Berre"],
        "second_author_is_corresponding": "Corresponding author: Mehmet Recep Bozkurt"
        in manuscript,
        "no_external_funding_declared": "This research received no external funding."
        in declarations,
        "no_competing_interests_declared": "The authors declare no competing interests."
        in declarations,
        "secondary_fiducial_supplement_exists": (
            project_root / "manuscript/supplementary_methods_results.md"
        ).exists(),
        "zenodo_resource_is_software": metadata.get("upload_type") == "software",
        "software_license_is_approved_mit": metadata.get("license") == "MIT"
        and (project_root / "LICENSE").read_text(encoding="utf-8").startswith("MIT License"),
        "all_three_complete_orcids": metadata["creators"][0].get("orcid")
        == "0000-0002-8398-3780"
        and metadata["creators"][1].get("orcid") == "0000-0003-0673-4454"
        and metadata["creators"][2].get("orcid") == "0009-0004-2857-912X",
        "release_is_acceptance_gated": "formal acceptance"
        in metadata.get("publication_policy", ""),
        "source_and_row_level_data_excluded": all(
            token in release for token in ("Dataset/", "external_data/", "full per-beat")
        ),
    }
    return all(checks.values()), checks


def assert_subject_disjoint(train_subjects, test_subjects) -> None:
    overlap = set(train_subjects) & set(test_subjects)
    if overlap:
        raise AssertionError(f"Subject leakage detected: {sorted(overlap)}")


def verify_outputs(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    report_root = project_path(config, config["paths"]["report_root"])
    frozen_config = output_root / "analysis_config.yaml"
    frozen_config.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(config["_config_path"], frozen_config)
    required = [
        output_root / "record_index.parquet",
        output_root / "intervals.parquet",
        output_root / "beat_quality.parquet",
        output_root / "model_predictions.parquet",
        output_root / "results_manifest.json",
        output_root / "algorithmic_validation_manifest.json",
        output_root / "ppg_method_sensitivity_manifest.json",
        output_root / "qtdb_qrs_onset_manifest.json",
        output_root / "mixed_effects_manifest.json",
        report_root / "q2_q3_gate.json",
        report_root / "table_1_coverage.parquet",
        report_root / "table_2_ppg_method_robustness.csv",
        report_root / "table_4_candidate_performance.csv",
        report_root / "table_5_mixed_effects_hr.csv",
        report_root / "table_6_external_pilot.csv",
        report_root / "table_s1_qtdb_validation.csv",
        report_root / "table_s2_csv_wfdb_timing.csv",
        report_root / "table_s3_ppg_point_differences.csv",
        frozen_config,
    ]
    resolved = [path if path.exists() else path.with_suffix(".csv") for path in required]
    missing = [str(path) for path in resolved if not path.exists()]
    manifest_path = output_root / "results_manifest.json"
    confirmatory_complete = False
    if manifest_path.exists():
        confirmatory_complete = bool(json.loads(manifest_path.read_text(encoding="utf-8")).get("confirmatory_complete"))
    algorithmic_path = output_root / "algorithmic_validation_manifest.json"
    algorithmic_manifest = (
        json.loads(algorithmic_path.read_text(encoding="utf-8"))
        if algorithmic_path.exists()
        else {"status": "missing", "completion_gate_passed": False}
    )
    external_path = output_root / "external_replication_manifest.json"
    external_manifest = (
        json.loads(external_path.read_text(encoding="utf-8")) if external_path.exists() else {"status": "missing"}
    )
    csv_path = output_root / "csv_sensitivity_manifest.json"
    csv_manifest = json.loads(csv_path.read_text(encoding="utf-8")) if csv_path.exists() else {"status": "missing"}
    gate_path = report_root / "q2_q3_gate.json"
    q2_gate = json.loads(gate_path.read_text(encoding="utf-8")) if gate_path.exists() else {}
    mixed_path = output_root / "mixed_effects_manifest.json"
    mixed_manifest = (
        json.loads(mixed_path.read_text(encoding="utf-8"))
        if mixed_path.exists()
        else {"status": "missing"}
    )
    ppg_path = output_root / "ppg_method_sensitivity_manifest.json"
    ppg_manifest = json.loads(ppg_path.read_text(encoding="utf-8")) if ppg_path.exists() else {}
    qtdb_path = output_root / "qtdb_qrs_onset_manifest.json"
    qtdb_manifest = json.loads(qtdb_path.read_text(encoding="utf-8")) if qtdb_path.exists() else {}
    completion = bool(
        not missing
        and algorithmic_manifest.get("completion_gate_passed")
        and ppg_manifest.get("configured_method_matches_rule")
        and str(qtdb_manifest.get("status", "")).startswith("complete_")
        and mixed_manifest.get("status") == "complete"
    )
    from .models import aggregate_records
    from .tables import read_records

    intervals = read_records(output_root / "intervals.parquet")
    selections = read_records(output_root / "model_selection.parquet")
    coverage = read_records(report_root / "table_1_coverage.parquet")
    records = aggregate_records(intervals, list(config["outcomes"]["primary"]), minimum_beats=10)
    computed_coverage = {
        outcome: int(records.dropna(subset=[outcome])["record_id"].nunique())
        for outcome in config["outcomes"]["primary"]
    }
    reported_coverage = {
        row["outcome"]: int(row["records_with_10_valid_beats"])
        for _, row in coverage.iterrows()
    }
    project_root = Path(config["_config_path"]).resolve().parent.parent
    scg_ok, scg_findings = _active_scg_terminology_check(project_root)
    submission_ok, submission_checks = _submission_consistency_check(project_root)
    numeric_consistency = {
        "sessions_equal_338": bool(intervals["record_id"].nunique() == 338),
        "beats_equal_18005": bool(len(intervals) == 18005),
        "coverage_table_matches_intervals": bool(computed_coverage == reported_coverage),
        "all_primary_outer_folds_uncorrected": bool(
            len(selections) == 96 and (selections["selected_model"] == "uncorrected").all()
        ),
        "preserved_external_hr_span_0_of_6": bool(
            external_manifest.get("gates", {}).get("subjects_with_30_bpm_span") == 0
        ),
        "preserved_external_ptt_stability": bool(
            abs(
                external_manifest.get("gates", {}).get("stable_ptt_polarity_fraction", np.nan)
                - 0.5864186998805665
            )
            < 1e-12
        ),
    }
    consistency_passed = bool(all(numeric_consistency.values()) and scg_ok)
    completion = bool(completion and consistency_passed and submission_ok)
    payload = {
        "method_version": config["study"]["method_version"],
        "required_outputs_present": not missing,
        "missing": missing,
        "pipeline_complete": completion,
        "confirmatory_complete": confirmatory_complete,
        "human_annotation_required": False,
        "algorithmic_validation_status": algorithmic_manifest.get("status"),
        "algorithmic_validation_gate_passed": algorithmic_manifest.get("completion_gate_passed"),
        "qtdb_qrs_onset_status": qtdb_manifest.get("status"),
        "ppg_method_selection_matches_config": ppg_manifest.get("configured_method_matches_rule"),
        "mixed_effects_status": mixed_manifest.get("status"),
        "scg_proxy_terminology_passed": scg_ok,
        "scg_terminology_findings": scg_findings,
        "numeric_consistency": numeric_consistency,
        "numeric_consistency_passed": consistency_passed,
        "submission_consistency": submission_checks,
        "submission_consistency_passed": submission_ok,
        "csv_timing_sensitivity_status": csv_manifest.get("status"),
        "external_replication_status": external_manifest.get("status"),
        "q2_effect_gate_passed": q2_gate.get("q2_effect_gate_passed"),
    }
    write_json(payload, report_root / "verification_report.json")
    tracked = [
        *sorted(output_root.glob("*.parquet")),
        *sorted(output_root.glob("*.csv")),
        *sorted(output_root.glob("*.json")),
        project_path(config, "config/analysis_config.yaml"),
        project_path(config, "requirements-core.lock"),
        *sorted(project_path(config, "src/senssmarttech").glob("*.py")),
    ]
    file_rows = []
    for path in tracked:
        if not path.exists():
            continue
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        file_rows.append({"path": str(path.relative_to(project_path(config, "."))), "sha256": digest.hexdigest()})
    write_json({"files": file_rows}, report_root / "reproducibility_manifest.json")
    return payload
