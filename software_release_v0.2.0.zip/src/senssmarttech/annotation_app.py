"""DEPRECATED experimental human-annotation UI; not used by protocol v2."""

from __future__ import annotations

import csv
import hashlib
import json
import threading
import webbrowser
from dataclasses import dataclass
from datetime import UTC, datetime
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

import numpy as np

from .annotation_scoring import score_completed_annotations
from .annotations import FIDUCIAL_COLUMNS
from .config import project_path
from .signals import bandpass, read_wfdb_record, robust_scale
from .tables import read_records, write_json

FIDUCIAL_META = {
    "q_ms": {"label": "Q başlangıcı", "row": "ecg", "color": "#8E44AD", "tolerance_ms": 10},
    "r_ms": {"label": "R tepesi", "row": "ecg", "color": "#C0392B", "tolerance_ms": 10},
    "s1_ms": {"label": "S1 merkezi", "row": "pcg", "color": "#D35400", "tolerance_ms": 20},
    "s2_ms": {"label": "S2 merkezi", "row": "pcg", "color": "#F39C12", "tolerance_ms": 20},
    "avo_ms": {"label": "SCG AVO vekili", "row": "scg", "color": "#16A085", "tolerance_ms": 20},
    "avc_ms": {"label": "SCG AVC vekili", "row": "scg", "color": "#117864", "tolerance_ms": 20},
    "carotid_880nm_foot_ms": {
        "label": "Karotis 880 ayak",
        "row": "ppg_880",
        "color": "#C0392B",
        "tolerance_ms": 20,
    },
    "brachial_880nm_foot_ms": {
        "label": "Brakiyal 880 ayak",
        "row": "ppg_880",
        "color": "#1E8449",
        "tolerance_ms": 20,
    },
    "carotid_660nm_foot_ms": {
        "label": "Karotis 660 ayak",
        "row": "ppg_660",
        "color": "#922B21",
        "tolerance_ms": 20,
    },
    "brachial_660nm_foot_ms": {
        "label": "Brakiyal 660 ayak",
        "row": "ppg_660",
        "color": "#196F3D",
        "tolerance_ms": 20,
    },
}
CONFIDENCE = {"high", "moderate", "low", "unmeasurable"}


def _default_annotation() -> dict[str, Any]:
    return {
        "usable": None,
        "notes": "",
        "fiducials": {
            name: {"value_ms": None, "confidence": None} for name in FIDUCIAL_COLUMNS
        },
    }


def _task_id(row: Any) -> str:
    return f"{row.blinded_record_code}:{int(row.beat_slot)}"


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass
class AppPaths:
    annotation_root: Path
    state: Path
    locked: Path
    completed_csv: Path


class AnnotationApplication:
    def __init__(self, config: dict[str, Any], mode: str, rater: int | None):
        self.config = config
        self.mode = mode
        self.rater = rater
        self.annotation_root = project_path(config, config["paths"]["annotation_root"])
        self.wfdb_root = project_path(config, config["paths"]["wfdb_root"])
        self.asset_root = Path(__file__).with_name("annotation_ui")
        key_name = "training_blinding_key.parquet" if mode == "training" else "blinding_key.parquet"
        self.all_tasks = read_records(self.annotation_root / key_name)
        self.paths = self._paths()
        self.state = self._load_state()
        self.rater_states: dict[int, dict[str, Any]] = {}
        if mode == "adjudication":
            self.rater_states = {number: self._load_locked_rater(number) for number in (1, 2)}
            self.task_indices = self._disagreement_task_indices()
        else:
            self.task_indices = list(range(len(self.all_tasks)))
        self._cache: dict[str, dict[str, Any]] = {}
        self._lock = threading.Lock()

    def _paths(self) -> AppPaths:
        root = self.annotation_root / "app_data"
        if self.mode == "training":
            stem = "training_shared"
        elif self.mode == "adjudication":
            stem = "adjudication"
        else:
            if self.rater not in (1, 2):
                raise ValueError("Validation mode requires --rater 1 or --rater 2")
            stem = f"rater_{self.rater}_validation"
        return AppPaths(
            root,
            root / f"{stem}.json",
            root / f"{stem}.locked.json",
            self.annotation_root / "packet" / f"{stem}_completed.csv",
        )

    def _load_state(self) -> dict[str, Any]:
        source = self.paths.locked if self.paths.locked.exists() else self.paths.state
        if source.exists():
            return json.loads(source.read_text(encoding="utf-8"))
        return {
            "metadata": {"mode": self.mode, "rater": self.rater, "created_at": datetime.now(UTC).isoformat()},
            "annotations": {},
        }

    def _load_locked_rater(self, number: int) -> dict[str, Any]:
        path = self.annotation_root / "app_data" / f"rater_{number}_validation.locked.json"
        if not path.exists():
            raise FileNotFoundError(
                f"Adjudication requires both locked rater files. Missing: {path.name}"
            )
        return json.loads(path.read_text(encoding="utf-8"))

    def _annotation_for(self, row: Any) -> dict[str, Any]:
        return self.state["annotations"].get(_task_id(row), _default_annotation())

    def _rater_annotation(self, number: int, row: Any) -> dict[str, Any]:
        return self.rater_states[number]["annotations"].get(_task_id(row), _default_annotation())

    def _disagreements(self, row: Any) -> list[str]:
        first = self._rater_annotation(1, row)
        second = self._rater_annotation(2, row)
        disagreements = []
        if first.get("usable") != second.get("usable"):
            return list(FIDUCIAL_COLUMNS)
        for name in FIDUCIAL_COLUMNS:
            left = first["fiducials"][name]
            right = second["fiducials"][name]
            left_un = left.get("confidence") == "unmeasurable"
            right_un = right.get("confidence") == "unmeasurable"
            if left_un != right_un:
                disagreements.append(name)
                continue
            if left_un and right_un:
                continue
            left_value, right_value = left.get("value_ms"), right.get("value_ms")
            if left_value is None or right_value is None or abs(float(left_value) - float(right_value)) > FIDUCIAL_META[name]["tolerance_ms"]:
                disagreements.append(name)
        return disagreements

    def _disagreement_task_indices(self) -> list[int]:
        return [index for index, row in self.all_tasks.iterrows() if self._disagreements(row)]

    def config_payload(self) -> dict[str, Any]:
        completed = sum(self._task_complete(self._annotation_for(self.all_tasks.iloc[index]), index) for index in self.task_indices)
        return {
            "mode": self.mode,
            "rater": self.rater,
            "task_count": len(self.task_indices),
            "completed": completed,
            "locked": self.paths.locked.exists(),
            "fiducials": [{"name": name, **FIDUCIAL_META[name]} for name in FIDUCIAL_COLUMNS],
            "confidence_options": ["high", "moderate", "low"],
        }

    def _filtered_record(self, record_id: str) -> dict[str, Any]:
        if record_id in self._cache:
            return self._cache[record_id]
        ecg = read_wfdb_record(self.wfdb_root / f"{record_id}_ecg.hea")
        pcg = read_wfdb_record(self.wfdb_root / f"{record_id}_pcg.hea")
        acc = read_wfdb_record(self.wfdb_root / f"{record_id}_acc.hea")
        ppg = read_wfdb_record(self.wfdb_root / f"{record_id}_ppg.hea")
        fs = float(ecg.fs)
        filters = self.config["filters_hz"]
        payload = {
            "fs": fs,
            "ecg": bandpass(ecg.values, fs, *filters["ecg_morphology"]),
            "pcg": bandpass(pcg.values[:, 0], fs, *filters["pcg"]),
            "scg": bandpass(acc.values[:, 0], fs, *filters["scg"]),
            "ppg": bandpass(ppg.values, fs, *filters["ppg"]),
        }
        self._cache.clear()
        self._cache[record_id] = payload
        return payload

    @staticmethod
    def _series(values: np.ndarray) -> list[float]:
        scaled = np.clip(robust_scale(np.asarray(values, dtype=float)), -4.5, 4.5)
        return np.round(scaled, 4).tolist()

    def task_payload(self, display_index: int) -> dict[str, Any]:
        if not 0 <= display_index < len(self.task_indices):
            raise IndexError(display_index)
        source_index = self.task_indices[display_index]
        row = self.all_tasks.iloc[source_index]
        record = self._filtered_record(str(row.record_id))
        start = int(row.window_start_sample)
        stop = min(record["ecg"].shape[0], start + round(0.82 * record["fs"]))
        signals = [
            {"id": "ecg_i", "label": "ECG I", "series": [{"name": "I", "color": "#315A7D", "values": self._series(record["ecg"][start:stop, 0])}]},
            {"id": "ecg_ii", "label": "ECG II", "series": [{"name": "II", "color": "#315A7D", "values": self._series(record["ecg"][start:stop, 1])}]},
            {"id": "ecg_v3", "label": "ECG V3", "series": [{"name": "V3", "color": "#315A7D", "values": self._series(record["ecg"][start:stop, 2])}]},
            {"id": "ecg_v4", "label": "ECG V4", "series": [{"name": "V4", "color": "#315A7D", "values": self._series(record["ecg"][start:stop, 3])}]},
            {"id": "pcg", "label": "PCG", "series": [{"name": "PCG", "color": "#7D3C98", "values": self._series(record["pcg"][start:stop])}]},
            {"id": "scg", "label": "SCG", "series": [{"name": "ACC", "color": "#117864", "values": self._series(record["scg"][start:stop])}]},
            {
                "id": "ppg_880",
                "label": "PPG 880",
                "series": [
                    {"name": "Karotis", "color": "#C0392B", "values": self._series(record["ppg"][start:stop, 0])},
                    {"name": "Brakiyal", "color": "#1E8449", "values": self._series(record["ppg"][start:stop, 2])},
                ],
            },
            {
                "id": "ppg_660",
                "label": "PPG 660",
                "series": [
                    {"name": "Karotis", "color": "#922B21", "values": self._series(record["ppg"][start:stop, 1])},
                    {"name": "Brakiyal", "color": "#196F3D", "values": self._series(record["ppg"][start:stop, 3])},
                ],
            },
        ]
        payload = {
            "index": display_index,
            "task_count": len(self.task_indices),
            "code": str(row.blinded_record_code),
            "beat_slot": int(row.beat_slot),
            "duration_ms": (stop - start) * 1000.0 / record["fs"],
            "signals": signals,
            "annotation": self._annotation_for(row),
        }
        if self.mode == "adjudication":
            payload.update(
                {
                    "disagreements": self._disagreements(row),
                    "rater_1": self._rater_annotation(1, row),
                    "rater_2": self._rater_annotation(2, row),
                }
            )
        return payload

    def _validate_annotation(self, annotation: dict[str, Any], duration_ms: float) -> dict[str, Any]:
        clean = _default_annotation()
        clean["usable"] = annotation.get("usable")
        if clean["usable"] not in (True, False, None):
            raise ValueError("Invalid usable value")
        clean["notes"] = str(annotation.get("notes", ""))[:1000]
        supplied = annotation.get("fiducials", {})
        for name in FIDUCIAL_COLUMNS:
            item = supplied.get(name, {})
            confidence = item.get("confidence")
            value = item.get("value_ms")
            if confidence is not None and confidence not in CONFIDENCE:
                raise ValueError(f"Invalid confidence for {name}")
            if confidence == "unmeasurable":
                value = None
            elif value is not None:
                value = round(float(value), 1)
                if not 0 <= value <= duration_ms:
                    raise ValueError(f"Marker outside window for {name}")
            clean["fiducials"][name] = {"value_ms": value, "confidence": confidence}
        if clean["usable"] is False:
            for name in FIDUCIAL_COLUMNS:
                clean["fiducials"][name] = {"value_ms": None, "confidence": "unmeasurable"}
        return clean

    def save(self, display_index: int, annotation: dict[str, Any]) -> dict[str, Any]:
        if self.paths.locked.exists():
            raise PermissionError("This annotation set is locked")
        source_index = self.task_indices[display_index]
        row = self.all_tasks.iloc[source_index]
        duration = self.task_payload(display_index)["duration_ms"]
        clean = self._validate_annotation(annotation, duration)
        with self._lock:
            self.state["annotations"][_task_id(row)] = clean
            self.state["metadata"]["updated_at"] = datetime.now(UTC).isoformat()
            _atomic_json(self.paths.state, self.state)
        return self.config_payload()

    def _task_complete(self, annotation: dict[str, Any], display_index: int) -> bool:
        if annotation.get("usable") not in (True, False):
            return False
        names = FIDUCIAL_COLUMNS
        if self.mode == "adjudication":
            row = self.all_tasks.iloc[self.task_indices[display_index]]
            names = tuple(self._disagreements(row))
            if not annotation.get("notes", "").strip():
                return False
        for name in names:
            item = annotation.get("fiducials", {}).get(name, {})
            confidence = item.get("confidence")
            if confidence not in CONFIDENCE:
                return False
            if confidence != "unmeasurable" and item.get("value_ms") is None:
                return False
        return True

    def _export_rater_csv(self) -> None:
        rows = []
        for _, task in self.all_tasks.iterrows():
            annotation = self._annotation_for(task)
            row = {
                "blinded_record_code": task.blinded_record_code,
                "beat_slot": int(task.beat_slot),
                "usable": bool(annotation["usable"]),
            }
            for name in FIDUCIAL_COLUMNS:
                row[name] = annotation["fiducials"][name]["value_ms"]
                row[f"{name}_confidence"] = annotation["fiducials"][name]["confidence"]
            row["notes"] = annotation.get("notes", "")
            rows.append(row)
        self.paths.completed_csv.parent.mkdir(parents=True, exist_ok=True)
        with self.paths.completed_csv.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)

    def _consensus_export(self) -> Path:
        target = self.annotation_root / "adjudicated_consensus.csv"
        rows = []
        for _, task in self.all_tasks.iterrows():
            first = self._rater_annotation(1, task)
            second = self._rater_annotation(2, task)
            adjudicated = self.state["annotations"].get(_task_id(task), _default_annotation())
            disagreements = set(self._disagreements(task))
            row = {
                "blinded_record_code": task.blinded_record_code,
                "beat_slot": int(task.beat_slot),
                "usable": adjudicated.get("usable") if disagreements else first.get("usable"),
                "adjudication_notes": adjudicated.get("notes", "") if disagreements else "",
            }
            for name in FIDUCIAL_COLUMNS:
                left, right = first["fiducials"][name], second["fiducials"][name]
                if name in disagreements:
                    final = adjudicated["fiducials"][name]
                    source = "adjudicated"
                elif left.get("confidence") == "unmeasurable" and right.get("confidence") == "unmeasurable":
                    final = {"value_ms": None, "confidence": "unmeasurable"}
                    source = "rater_agreement_unmeasurable"
                else:
                    final = {
                        "value_ms": round((float(left["value_ms"]) + float(right["value_ms"])) / 2.0, 1),
                        "confidence": "consensus",
                    }
                    source = "mean_within_tolerance"
                row[name] = final["value_ms"]
                row[f"{name}_confidence"] = final["confidence"]
                row[f"{name}_source"] = source
            rows.append(row)
        with target.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        return target

    def finalize(self) -> dict[str, Any]:
        if self.paths.locked.exists():
            return {"locked": True, "path": str(self.paths.locked)}
        incomplete = []
        for display_index, source_index in enumerate(self.task_indices):
            row = self.all_tasks.iloc[source_index]
            if not self._task_complete(self._annotation_for(row), display_index):
                incomplete.append(display_index + 1)
        if incomplete:
            raise ValueError(f"Incomplete tasks: {incomplete[:20]}")
        self.state["metadata"]["locked_at"] = datetime.now(UTC).isoformat()
        _atomic_json(self.paths.locked, self.state)
        if self.mode == "validation":
            self._export_rater_csv()
            other = 2 if self.rater == 1 else 1
            other_locked = self.annotation_root / "app_data" / f"rater_{other}_validation.locked.json"
            other_csv = self.annotation_root / "packet" / f"rater_{other}_validation_completed.csv"
            if other_locked.exists() and other_csv.exists():
                first = self.annotation_root / "packet" / "rater_1_validation_completed.csv"
                second = self.annotation_root / "packet" / "rater_2_validation_completed.csv"
                score_completed_annotations(self.config, str(first), str(second))
        elif self.mode == "adjudication":
            consensus = self._consensus_export()
            manifest_path = self.annotation_root / "annotation_manifest.json"
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            manifest.update(
                {
                    "status": "adjudication_complete",
                    "adjudication_complete": True,
                    "adjudicated_consensus": str(consensus),
                    "adjudication_sha256": _sha256(consensus),
                }
            )
            write_json(manifest, manifest_path)
        return {
            "locked": True,
            "path": str(self.paths.locked),
            "sha256": _sha256(self.paths.locked),
            "completed_csv": str(self.paths.completed_csv) if self.mode == "validation" else None,
        }


class AnnotationHandler(BaseHTTPRequestHandler):
    app: AnnotationApplication

    def log_message(self, format: str, *args: Any) -> None:
        return

    def _json(self, payload: Any, status: int = 200) -> None:
        encoded = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def _asset(self, name: str, content_type: str) -> None:
        path = self.app.asset_root / name
        if not path.exists():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                self._asset("index.html", "text/html; charset=utf-8")
            elif parsed.path == "/app.js":
                self._asset("app.js", "text/javascript; charset=utf-8")
            elif parsed.path == "/styles.css":
                self._asset("styles.css", "text/css; charset=utf-8")
            elif parsed.path == "/api/config":
                self._json(self.app.config_payload())
            elif parsed.path == "/api/task":
                index = int(parse_qs(parsed.query).get("index", ["0"])[0])
                self._json(self.app.task_payload(index))
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except (ValueError, IndexError, FileNotFoundError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def do_POST(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            body = json.loads(self.rfile.read(length) or b"{}")
            if self.path == "/api/save":
                self._json(self.app.save(int(body["index"]), body["annotation"]))
            elif self.path == "/api/finalize":
                self._json(self.app.finalize())
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except (ValueError, KeyError, PermissionError, FileNotFoundError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)


def run_annotation_app(
    config: dict[str, Any],
    mode: str,
    rater: int | None,
    host: str = "127.0.0.1",
    port: int = 8765,
    open_browser: bool = True,
) -> None:
    app = AnnotationApplication(config, mode, rater)
    handler = type("ConfiguredAnnotationHandler", (AnnotationHandler,), {"app": app})
    server = ThreadingHTTPServer((host, port), handler)
    url = f"http://{host}:{port}/"
    print(f"Annotation interface: {url}")
    if open_browser:
        threading.Timer(0.7, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
