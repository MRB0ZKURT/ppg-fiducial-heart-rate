"""DEPRECATED experimental annotation-packet code; not used by protocol v2."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .config import project_path
from .metadata import Record, read_demographics
from .quality import robust_snr_db
from .signals import read_wfdb_record
from .tables import read_records, write_json, write_records

FIDUCIAL_COLUMNS = (
    "q_ms",
    "r_ms",
    "s1_ms",
    "s2_ms",
    "avo_ms",
    "avc_ms",
    "carotid_880nm_foot_ms",
    "brachial_880nm_foot_ms",
    "carotid_660nm_foot_ms",
    "brachial_660nm_foot_ms",
)


def _record_quality_proxy(record: Record, wfdb_root: Path) -> float:
    values: list[float] = []
    for modality in ("ecg", "ppg", "pcg", "acc"):
        signal = read_wfdb_record(wfdb_root / f"{record.record_id}_{modality}.hea")
        values.extend(robust_snr_db(signal.values[:, index]) for index in range(signal.values.shape[1]))
    return float(np.median(values))


def _nearest_median(records: list[Record]) -> Record:
    values = np.asarray([record.median_hr_bpm for record in records])
    target = float(np.median(values))
    return min(records, key=lambda record: (abs(record.median_hr_bpm - target), record.file_number))


def select_annotation_records(config: dict[str, Any]) -> dict[str, object]:
    records = read_demographics(project_path(config, config["paths"]["demographics"]))
    wfdb_root = project_path(config, config["paths"]["wfdb_root"])
    annotation_root = project_path(config, config["paths"]["annotation_root"])
    rng = np.random.default_rng(config["study"]["random_seed"])

    by_subject: dict[int, list[Record]] = {}
    for record in records:
        by_subject.setdefault(record.subject, []).append(record)

    selected: dict[str, tuple[Record, str]] = {}
    for subject, subject_records in sorted(by_subject.items()):
        for state in ("B", "A"):
            candidates = [record for record in subject_records if record.activity_state == state]
            if not candidates:
                raise ValueError(f"Subject {subject} has no {state} record")
            chosen = _nearest_median(candidates)
            selected[chosen.record_id] = (chosen, f"subject_{state}_representative")

    remaining = [record for record in records if record.record_id not in selected]
    quality = {record.record_id: _record_quality_proxy(record, wfdb_root) for record in remaining}
    ranked_sets = (
        (sorted(remaining, key=lambda item: (item.median_hr_bpm, item.file_number)), "low_hr"),
        (sorted(remaining, key=lambda item: (-item.median_hr_bpm, item.file_number)), "high_hr"),
        (sorted(remaining, key=lambda item: (quality[item.record_id], item.file_number)), "low_snr"),
        (sorted(remaining, key=lambda item: (-quality[item.record_id], item.file_number)), "high_snr"),
    )
    for ranked, reason in ranked_sets:
        added = 0
        for record in ranked:
            if record.record_id in selected:
                continue
            selected[record.record_id] = (record, reason)
            added += 1
            if added == 4:
                break
    if len(selected) != 80:
        raise AssertionError(f"Expected 80 validation records, selected {len(selected)}")

    validation_rows = []
    for order, (record, reason) in enumerate(selected.values(), start=1):
        validation_rows.append(
            {
                **record.to_dict(),
                "annotation_set": "validation",
                "selection_reason": reason,
                "quality_proxy_db": quality.get(record.record_id, np.nan),
                "blinded_record_code": f"V{order:03d}",
            }
        )

    training_pool = [record for record in remaining if record.record_id not in selected]
    training_indices = rng.choice(len(training_pool), size=10, replace=False)
    training_rows = [
        {
            **training_pool[int(index)].to_dict(),
            "annotation_set": "training",
            "selection_reason": "seeded_training_sample",
            "blinded_record_code": f"T{position:03d}",
        }
        for position, index in enumerate(training_indices, start=1)
    ]
    validation_path = write_records(validation_rows, annotation_root / "validation_records.parquet")
    training_path = write_records(training_rows, annotation_root / "training_records.parquet")
    return {
        "validation_records": len(validation_rows),
        "training_records": len(training_rows),
        "validation_path": str(validation_path),
        "training_path": str(training_path),
    }


def _representative_rows(frame, count: int):
    ordered = frame.sort_values("r_sample").reset_index(drop=True)
    positions = np.linspace(0.2, 0.8, count)
    indices = np.unique(np.round(positions * (len(ordered) - 1)).astype(int))
    if indices.size != count:
        indices = np.linspace(0, len(ordered) - 1, count, dtype=int)
    return ordered.iloc[indices]


def prepare_annotation_packet(config: dict[str, Any]) -> dict[str, object]:
    """Create blinded rater sheets and unmarked multimodal beat panels."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    annotation_root = project_path(config, config["paths"]["annotation_root"])
    wfdb_root = project_path(config, config["paths"]["wfdb_root"])
    output_root = project_path(config, config["paths"]["output_root"])
    packet_root = annotation_root / "packet"
    figure_root = packet_root / "figures"
    figure_root.mkdir(parents=True, exist_ok=True)
    validation = read_records(annotation_root / "validation_records.parquet")
    intervals = read_records(output_root / "intervals.parquet")
    tasks: list[dict[str, object]] = []
    key_rows: list[dict[str, object]] = []
    before_ms, after_ms = 120, 700

    for manifest_row in validation.itertuples(index=False):
        record_id = str(manifest_row.record_id)
        blinded = str(manifest_row.blinded_record_code)
        record_beats = intervals[intervals["record_id"] == record_id]
        chosen = _representative_rows(
            record_beats, int(config["annotation"]["representative_beats_per_record"])
        )
        ecg = read_wfdb_record(wfdb_root / f"{record_id}_ecg.hea")
        pcg = read_wfdb_record(wfdb_root / f"{record_id}_pcg.hea")
        acc = read_wfdb_record(wfdb_root / f"{record_id}_acc.hea")
        ppg = read_wfdb_record(wfdb_root / f"{record_id}_ppg.hea")
        fs = float(ecg.fs)
        fig, axes = plt.subplots(4, len(chosen), figsize=(12, 8), sharex="col")
        for slot, (_, beat) in enumerate(chosen.iterrows(), start=1):
            start = max(0, int(beat["r_sample"] - before_ms * fs / 1000))
            stop = min(ecg.values.shape[0], int(beat["r_sample"] + after_ms * fs / 1000))
            time_ms = np.arange(stop - start) * 1000.0 / fs
            panels = (
                (ecg.values[start:stop, 1], "ECG II"),
                (pcg.values[start:stop, 0], "PCG"),
                (acc.values[start:stop, 0], "SCG/ACC"),
            )
            for row_index, (values, label) in enumerate(panels):
                axes[row_index, slot - 1].plot(time_ms, values, color="#174A7E", lw=0.8)
                if slot == 1:
                    axes[row_index, slot - 1].set_ylabel(label)
            for channel, color, label in ((0, "#B33A3A", "carotid"), (2, "#2C7A4B", "brachial")):
                values = ppg.values[start:stop, channel]
                scaled = (values - np.median(values)) / max(np.ptp(values), np.finfo(float).eps)
                axes[3, slot - 1].plot(time_ms, scaled, color=color, lw=0.9, label=label)
            axes[3, slot - 1].set_xlabel("Window time (ms)")
            axes[0, slot - 1].set_title(f"Beat {slot}")
            tasks.append(
                {
                    "blinded_record_code": blinded,
                    "beat_slot": slot,
                    "figure_file": f"figures/{blinded}.png",
                    "usable": "",
                    **{name: "" for name in FIDUCIAL_COLUMNS},
                    **{f"{name}_confidence": "" for name in FIDUCIAL_COLUMNS},
                    "notes": "",
                }
            )
            key_rows.append(
                {
                    "blinded_record_code": blinded,
                    "beat_slot": slot,
                    "record_id": record_id,
                    "subject": int(manifest_row.subject),
                    "activity_state": str(manifest_row.activity_state),
                    "median_hr_bpm": float(manifest_row.median_hr_bpm),
                    "window_start_sample": start,
                    "fs_hz": fs,
                    "algorithm_beat_index": int(beat["beat_index"]),
                }
            )
        axes[3, 0].set_ylabel("PPG (scaled)")
        axes[3, -1].legend(frameon=False, fontsize=8)
        fig.suptitle(f"Blinded record {blinded}")
        fig.tight_layout()
        fig.savefig(figure_root / f"{blinded}.png", dpi=170)
        plt.close(fig)

    for rater in (1, 2):
        write_records(tasks, packet_root / f"rater_{rater}_template.parquet")
    write_records(key_rows, annotation_root / "blinding_key.parquet")
    training = read_records(annotation_root / "training_records.parquet")
    training_key_rows: list[dict[str, object]] = []
    for manifest_row in training.itertuples(index=False):
        record_beats = intervals[intervals["record_id"] == manifest_row.record_id]
        chosen = _representative_rows(
            record_beats, int(config["annotation"]["representative_beats_per_record"])
        )
        for slot, (_, beat) in enumerate(chosen.iterrows(), start=1):
            fs = float(beat["fs_hz"])
            training_key_rows.append(
                {
                    "blinded_record_code": str(manifest_row.blinded_record_code),
                    "beat_slot": slot,
                    "record_id": str(manifest_row.record_id),
                    "subject": int(manifest_row.subject),
                    "activity_state": str(manifest_row.activity_state),
                    "median_hr_bpm": float(manifest_row.median_hr_bpm),
                    "window_start_sample": max(0, int(beat["r_sample"] - before_ms * fs / 1000)),
                    "fs_hz": fs,
                    "algorithm_beat_index": int(beat["beat_index"]),
                }
            )
    training_key_path = write_records(
        training_key_rows, annotation_root / "training_blinding_key.parquet"
    )
    schema_path = write_records([], output_root / "annotations.parquet")
    manifest = {
        "status": "awaiting_two_independent_raters",
        "records": int(validation.shape[0]),
        "beats": len(tasks),
        "figures": int(validation.shape[0]),
        "activity_and_hr_hidden_from_rater_templates": True,
        "rater_1_template": str(packet_root / "rater_1_template.csv"),
        "rater_2_template": str(packet_root / "rater_2_template.csv"),
        "blinding_key": str(annotation_root / "blinding_key.parquet"),
        "training_blinding_key": str(training_key_path),
        "training_beats": len(training_key_rows),
        "annotations_interface": str(schema_path),
    }
    write_json(manifest, annotation_root / "annotation_manifest.json")
    return manifest
