from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .signals import bandpass, robust_scale


@dataclass(frozen=True)
class RDetection:
    samples: np.ndarray
    votes: np.ndarray
    confidence: np.ndarray


@dataclass(frozen=True)
class PPGFootDetection:
    """PPG foot candidates with explicit failure and signal-quality metadata."""

    samples: np.ndarray
    confidence: np.ndarray
    failure_reason: tuple[str, ...]


def _single_lead_r(ecg: np.ndarray, fs: float) -> tuple[np.ndarray, np.ndarray]:
    integrated_window = max(1, round(0.08 * fs))
    energy = np.convolve(robust_scale(ecg) ** 2, np.ones(integrated_window) / integrated_window, mode="same")
    threshold = np.median(energy) + 3.0 * np.median(np.abs(energy - np.median(energy)))
    candidates = np.flatnonzero(
        (energy[1:-1] > energy[:-2]) & (energy[1:-1] >= energy[2:]) & (energy[1:-1] >= threshold)
    ) + 1
    distance = round(0.25 * fs)
    retained: list[int] = []
    for candidate in candidates[np.argsort(energy[candidates])[::-1]]:
        if all(abs(int(candidate) - previous) >= distance for previous in retained):
            retained.append(int(candidate))
    peaks = np.asarray(sorted(retained), dtype=int)
    refined: list[int] = []
    confidence: list[float] = []
    radius = max(1, round(0.05 * fs))
    for peak, height in zip(peaks, energy[peaks], strict=True):
        left, right = max(0, peak - radius), min(ecg.size, peak + radius + 1)
        local = np.abs(ecg[left:right] - np.median(ecg[left:right]))
        refined.append(left + int(np.argmax(local)))
        confidence.append(float(height / max(threshold, np.finfo(float).eps)))
    return np.asarray(refined, dtype=int), np.asarray(confidence, dtype=float)


def detect_r_multilead(ecg: np.ndarray, fs: float, tolerance_ms: float = 50.0) -> RDetection:
    """Quality-weighted majority R detection across all available ECG leads."""
    if ecg.ndim == 1:
        ecg = ecg[:, None]
    filtered = bandpass(ecg, fs, 8.0, 23.0)
    events: list[tuple[int, int, float]] = []
    for lead in range(filtered.shape[1]):
        peaks, confidence = _single_lead_r(filtered[:, lead], fs)
        events.extend((int(sample), lead, float(score)) for sample, score in zip(peaks, confidence, strict=True))
    events.sort()
    tolerance = round(tolerance_ms * fs / 1000.0)
    clusters: list[list[tuple[int, int, float]]] = []
    for event in events:
        if not clusters or event[0] - int(np.median([item[0] for item in clusters[-1]])) > tolerance:
            clusters.append([event])
        else:
            clusters[-1].append(event)

    samples: list[int] = []
    votes: list[int] = []
    scores: list[float] = []
    required_votes = min(2, ecg.shape[1])
    for cluster in clusters:
        best_per_lead: dict[int, tuple[int, int, float]] = {}
        for item in cluster:
            if item[1] not in best_per_lead or item[2] > best_per_lead[item[1]][2]:
                best_per_lead[item[1]] = item
        retained = list(best_per_lead.values())
        if len(retained) < required_votes:
            continue
        weights = np.asarray([item[2] for item in retained])
        positions = np.asarray([item[0] for item in retained])
        samples.append(round(np.average(positions, weights=weights)))
        votes.append(len(retained))
        scores.append(float(np.mean(weights)))
    return RDetection(np.asarray(samples), np.asarray(votes), np.asarray(scores))


def detect_q_onsets_wavelet(ecg_lead: np.ndarray, r_samples: np.ndarray, fs: float) -> np.ndarray:
    """Candidate Q-onset delineation using multiscale wavelet energy and backtracking."""
    import pywt

    morphology = bandpass(ecg_lead, fs, 0.5, 40.0)
    scales = np.asarray([2, 3, 4, 5, 6], dtype=float)
    coefficients, _ = pywt.cwt(morphology, scales, "mexh", sampling_period=1.0 / fs)
    energy = np.sqrt(np.mean(coefficients**2, axis=0))
    derivative = np.abs(np.gradient(morphology))
    combined = robust_scale(energy) + robust_scale(derivative)
    onsets: list[int] = []
    for r in r_samples:
        left = max(0, r - round(0.09 * fs))
        right = max(left + 1, r - round(0.015 * fs))
        segment = combined[left:right]
        if segment.size < 3:
            onsets.append(-1)
            continue
        peak = left + int(np.argmax(segment))
        baseline = np.median(combined[left : max(left + 1, peak)])
        threshold = baseline + 0.25 * max(combined[peak] - baseline, 0)
        candidates = np.flatnonzero(combined[left : peak + 1] <= threshold)
        onsets.append(left + int(candidates[-1]) if candidates.size else left)
    return np.asarray(onsets, dtype=int)


def analytic_envelope(signal: np.ndarray) -> np.ndarray:
    values = np.asarray(signal, dtype=float)
    n = values.size
    spectrum = np.fft.fft(values)
    multiplier = np.zeros(n)
    multiplier[0] = 1.0
    if n % 2 == 0:
        multiplier[n // 2] = 1.0
        multiplier[1 : n // 2] = 2.0
    else:
        multiplier[1 : (n + 1) // 2] = 2.0
    return np.abs(np.fft.ifft(spectrum * multiplier))


def detect_s1_s2(pcg: np.ndarray, r_samples: np.ndarray, fs: float) -> tuple[np.ndarray, np.ndarray]:
    filtered = bandpass(pcg, fs, 20.0, min(150.0, fs / 2 - 1.0))
    envelope = analytic_envelope(filtered)
    s1: list[int] = []
    s2: list[int] = []
    for index, r in enumerate(r_samples):
        beat_end = (
            int(r_samples[index + 1] - 0.02 * fs)
            if index + 1 < r_samples.size
            else min(pcg.size, r + int(0.70 * fs))
        )
        s1_left, s1_right = r + int(0.01 * fs), min(pcg.size, r + int(0.18 * fs))
        s2_left, s2_right = r + int(0.18 * fs), min(pcg.size, r + int(0.65 * fs), beat_end)
        s1.append(s1_left + int(np.argmax(envelope[s1_left:s1_right])) if s1_right > s1_left else -1)
        s2.append(s2_left + int(np.argmax(envelope[s2_left:s2_right])) if s2_right > s2_left else -1)
    return np.asarray(s1), np.asarray(s2)


def detect_scg_systolic_proxies(
    scg: np.ndarray,
    r_samples: np.ndarray,
    fs: float,
    s2_samples: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Jerk-derived early/late systolic SCG proxy points.

    These landmarks are not validated aortic-valve opening or closing times.  They
    may only be interpreted as repeatable morphology proxies without an external
    echocardiographic or invasive-pressure reference.
    """
    filtered = bandpass(scg, fs, 0.8, 40.0)
    jerk = robust_scale(np.gradient(filtered))
    early_systolic: list[int] = []
    late_systolic: list[int] = []
    for index, r in enumerate(r_samples):
        beat_end = (
            int(r_samples[index + 1] - 0.02 * fs)
            if index + 1 < r_samples.size
            else min(scg.size, r + int(0.70 * fs))
        )
        ao_left, ao_right = r + int(0.04 * fs), min(scg.size, r + int(0.22 * fs))
        ac_left, ac_right = r + int(0.18 * fs), min(scg.size, r + int(0.65 * fs), beat_end)
        ao = ao_left + int(np.argmax(jerk[ao_left:ao_right])) if ao_right > ao_left else -1
        if s2_samples is not None and index < s2_samples.size and s2_samples[index] >= 0:
            center = int(s2_samples[index])
            ac_left = max(ac_left, center - int(0.08 * fs))
            ac_right = min(ac_right, center + int(0.08 * fs))
        ac = ac_left + int(np.argmax(np.abs(jerk[ac_left:ac_right]))) if ac_right > ac_left else -1
        early_systolic.append(ao)
        late_systolic.append(ac)
    return np.asarray(early_systolic), np.asarray(late_systolic)


def intersecting_tangent_foot(ppg: np.ndarray, left: int, right: int) -> int:
    segment = ppg[left:right]
    if segment.size < 8:
        return -1
    derivative = np.gradient(segment)
    if abs(float(np.min(derivative))) > abs(float(np.max(derivative))):
        segment = -segment
        derivative = -derivative
    slope_index = int(np.argmax(derivative))
    slope = float(derivative[slope_index])
    if slope <= np.finfo(float).eps:
        return -1
    baseline_end = max(2, slope_index // 2)
    baseline = float(np.median(segment[:baseline_end]))
    intercept = slope_index - (float(segment[slope_index]) - baseline) / slope
    foot = round(np.clip(intercept, 0, segment.size - 1))
    return left + foot


PPG_FOOT_METHODS = ("intersecting_tangent", "max_first_derivative", "max_second_derivative", "local_minimum")


def _oriented_ppg_segment(ppg: np.ndarray, left: int, right: int) -> np.ndarray:
    segment = np.asarray(ppg[left:right], dtype=float)
    if segment.size < 8 or not np.all(np.isfinite(segment)):
        return np.asarray([], dtype=float)
    derivative = np.gradient(segment)
    if abs(float(np.min(derivative))) > abs(float(np.max(derivative))):
        segment = -segment
    return segment


def _ppg_foot_candidate(segment: np.ndarray, method: str) -> tuple[int, float, str]:
    """Return a local foot index, morphology confidence and failure reason.

    Confidence is a deterministic morphology score, not a probability.  A point is
    withheld when the upstroke is indistinguishable from derivative noise or when a
    method-specific landmark cannot be found before the dominant upstroke.
    """
    if method not in PPG_FOOT_METHODS:
        raise ValueError(f"Unknown PPG foot method: {method}")
    if segment.size < 8:
        return -1, 0.0, "short_or_nonfinite_window"
    first = np.gradient(segment)
    second = np.gradient(first)
    slope_index = int(np.argmax(first))
    slope = float(first[slope_index])
    derivative_noise = 1.4826 * float(np.median(np.abs(first - np.median(first))))
    confidence = slope / max(derivative_noise, np.finfo(float).eps)
    if slope_index < 2 or slope_index >= segment.size - 2:
        return -1, confidence, "dominant_upstroke_at_window_edge"
    if slope <= 0 or confidence < 1.5:
        return -1, confidence, "low_upstroke_contrast"

    if method == "max_first_derivative":
        return slope_index, confidence, ""
    if method == "max_second_derivative":
        search = second[: slope_index + 1]
        if search.size < 3:
            return -1, confidence, "no_pre_upstroke_acceleration"
        candidate = int(np.argmax(search))
        if candidate >= slope_index:
            return -1, confidence, "no_pre_upstroke_acceleration"
        return candidate, confidence, ""
    if method == "local_minimum":
        pre = segment[: slope_index + 1]
        minima = np.flatnonzero((pre[1:-1] < pre[:-2]) & (pre[1:-1] <= pre[2:])) + 1
        if minima.size == 0:
            return -1, confidence, "no_local_minimum_before_upstroke"
        return int(minima[-1]), confidence, ""

    baseline_end = max(2, slope_index // 2)
    baseline = float(np.median(segment[:baseline_end]))
    intercept = slope_index - (float(segment[slope_index]) - baseline) / slope
    candidate = round(intercept)
    if candidate < 0 or candidate >= slope_index:
        return -1, confidence, "tangent_intersection_outside_pre_upstroke"
    return candidate, confidence, ""


def detect_ppg_feet_with_quality(
    ppg: np.ndarray,
    r_samples: np.ndarray,
    fs: float,
    site: str,
    method: str = "intersecting_tangent",
) -> PPGFootDetection:
    filtered = bandpass(ppg, fs, 0.5, min(8.0, fs / 2 - 1.0))
    window = (0.08, 0.50) if site == "carotid" else (0.10, 0.65)
    feet: list[int] = []
    confidences: list[float] = []
    reasons: list[str] = []
    for index, r in enumerate(r_samples):
        left = r + int(window[0] * fs)
        beat_end = (
            int(r_samples[index + 1] - 0.03 * fs)
            if index + 1 < r_samples.size
            else min(filtered.size, r + int(window[1] * fs))
        )
        right = min(filtered.size, r + int(window[1] * fs), beat_end)
        segment = _oriented_ppg_segment(filtered, left, right)
        candidate, confidence, reason = _ppg_foot_candidate(segment, method)
        feet.append(left + candidate if candidate >= 0 else -1)
        confidences.append(confidence)
        reasons.append(reason)
    return PPGFootDetection(
        np.asarray(feet, dtype=int),
        np.asarray(confidences, dtype=float),
        tuple(reasons),
    )


def detect_ppg_feet_all_methods(
    ppg: np.ndarray, r_samples: np.ndarray, fs: float, site: str
) -> dict[str, PPGFootDetection]:
    """Evaluate every prespecified foot definition on an identical filtered signal."""
    return {
        method: detect_ppg_feet_with_quality(ppg, r_samples, fs, site, method)
        for method in PPG_FOOT_METHODS
    }


def detect_ppg_feet(
    ppg: np.ndarray,
    r_samples: np.ndarray,
    fs: float,
    site: str,
    method: str = "intersecting_tangent",
) -> np.ndarray:
    return detect_ppg_feet_with_quality(ppg, r_samples, fs, site, method).samples


def detect_ppg_peak_notch(
    ppg: np.ndarray, feet: np.ndarray, fs: float
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Detect systolic peaks, candidate notches, and end-of-pulse half-height crossings."""
    filtered = bandpass(ppg, fs, 0.5, min(8.0, fs / 2 - 1.0))
    peaks: list[int] = []
    notches: list[int] = []
    half_crossings: list[int] = []
    for foot in feet:
        if foot < 0:
            peaks.append(-1)
            notches.append(-1)
            half_crossings.append(-1)
            continue
        peak_right = min(filtered.size, foot + int(0.35 * fs))
        if peak_right <= foot + 2:
            peaks.append(-1)
            notches.append(-1)
            half_crossings.append(-1)
            continue
        segment = filtered[foot:peak_right]
        if abs(float(np.min(segment) - segment[0])) > abs(float(np.max(segment) - segment[0])):
            oriented = -filtered
        else:
            oriented = filtered
        peak = foot + int(np.argmax(oriented[foot:peak_right]))
        notch_right = min(oriented.size, peak + int(0.45 * fs))
        post_peak = oriented[peak:notch_right]
        valleys = np.flatnonzero(
            (post_peak[1:-1] < post_peak[:-2]) & (post_peak[1:-1] <= post_peak[2:])
        ) + 1
        minimum_delay = max(1, int(0.04 * fs))
        valleys = valleys[valleys >= minimum_delay]
        notch = peak + int(valleys[0]) if valleys.size else -1
        half_level = float(oriented[foot] + 0.5 * (oriented[peak] - oriented[foot]))
        falling = np.flatnonzero(oriented[peak:notch_right] <= half_level)
        half = peak + int(falling[0]) if falling.size else -1
        peaks.append(peak)
        notches.append(notch)
        half_crossings.append(half)
    return np.asarray(peaks), np.asarray(notches), np.asarray(half_crossings)
