from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib
import numpy as np
import pandas as pd

from .config import project_path
from .models import aggregate_records
from .tables import read_records, write_json, write_records

matplotlib.use("Agg")
import matplotlib.pyplot as plt

PRIMARY = (
    "r_to_carotid_880nm_foot_ms",
    "r_to_brachial_880nm_foot_ms",
    "carotid_to_brachial_880nm_foot_ms",
)

OUTCOME_LABELS = {
    "r_to_carotid_880nm_foot_ms": "Carotid PAT",
    "r_to_brachial_880nm_foot_ms": "Brachial PAT",
    "carotid_to_brachial_880nm_foot_ms": "Regional PTT",
}


def _publication_tables(
    output_root: Path,
    report_root: Path,
    ppg_summary: pd.DataFrame,
    performance: pd.DataFrame,
    qtdb_summary: pd.DataFrame,
    external_manifest: dict[str, Any],
) -> list[Path]:
    table_2 = ppg_summary.copy()
    table_2["selected_by_frozen_rule"] = table_2["fiducial_method"].eq("intersecting_tangent")
    table_2 = table_2[
        [
            "fiducial_method",
            "primary_complete_beat_fraction",
            "records_with_all_primary_outcomes",
            "record_coverage",
            "subjects_with_all_primary_outcomes",
            "composite_within_record_mad_ms",
            "composite_mad_ci_low_ms",
            "composite_mad_ci_high_ms",
            "selected_by_frozen_rule",
        ]
    ].round(4)
    table_2_path = write_records(
        table_2.to_dict("records"), report_root / "table_2_ppg_method_robustness.parquet"
    )

    table_4 = performance.copy()
    table_4["outcome"] = table_4["outcome"].map(OUTCOME_LABELS)
    table_4 = table_4[
        [
            "outcome",
            "candidate_model",
            "records",
            "subjects",
            "mae_ms",
            "rmse_ms",
            "mae_improvement_vs_uncorrected_pct",
            "improvement_ci_low_pct",
            "improvement_ci_high_pct",
            "raw_interval_hr_correlation",
            "corrected_interval_hr_correlation",
        ]
    ].round(3)
    table_4_path = write_records(
        table_4.to_dict("records"), report_root / "table_4_candidate_performance.parquet"
    )

    mixed = read_records(output_root / "mixed_effects_coefficients.parquet")
    table_5 = mixed[mixed["term"].eq("hr10_centered")].copy()
    table_5["outcome"] = table_5["outcome"].map(OUTCOME_LABELS)
    table_5 = table_5[
        [
            "outcome",
            "estimate",
            "standard_error",
            "ci_low",
            "ci_high",
            "p_value",
            "holm_adjusted_p",
            "model_converged",
        ]
    ].round(4)
    table_5_path = write_records(
        table_5.to_dict("records"), report_root / "table_5_mixed_effects_hr.parquet"
    )

    gates = external_manifest.get("gates", {})
    external_rows = [
        {
            "criterion": "Record coverage",
            "observed": gates.get("record_pass_fraction"),
            "threshold": 0.80,
            "passed": bool(gates.get("record_pass_fraction", 0) >= 0.80),
        },
        {
            "criterion": "Participants with at least 30-bpm HR span",
            "observed": gates.get("subjects_with_30_bpm_span"),
            "threshold": 4,
            "passed": bool(gates.get("subjects_with_30_bpm_span", 0) >= 4),
        },
        {
            "criterion": "R-annotation agreement",
            "observed": gates.get("r_annotation_agreement"),
            "threshold": 0.90,
            "passed": bool(gates.get("r_annotation_agreement", 0) >= 0.90),
        },
        {
            "criterion": "Stable PTT polarity",
            "observed": gates.get("stable_ptt_polarity_fraction"),
            "threshold": 0.80,
            "passed": bool(gates.get("stable_ptt_polarity_fraction", 0) >= 0.80),
        },
    ]
    table_6_path = write_records(external_rows, report_root / "table_6_external_pilot.parquet")

    table_s1 = qtdb_summary[qtdb_summary["reference_beats"].notna()].copy()
    table_s1["gate_passed"] = (
        table_s1["detection_coverage"].ge(0.90)
        & table_s1["median_absolute_error_ms"].le(20)
        & table_s1["within_30ms_fraction"].ge(0.90)
    )
    table_s1 = table_s1[
        [
            "reference_annotator",
            "records",
            "reference_beats",
            "detection_coverage",
            "median_absolute_error_ms",
            "median_absolute_error_ci_low_ms",
            "median_absolute_error_ci_high_ms",
            "mean_signed_error_ms",
            "within_30ms_fraction",
            "gate_passed",
        ]
    ].round(4)
    table_s1_path = write_records(
        table_s1.to_dict("records"), report_root / "table_s1_qtdb_validation.parquet"
    )

    csv_comparison = read_records(output_root / "csv_wfdb_comparison.parquet").round(4)
    table_s2_path = write_records(
        csv_comparison.to_dict("records"), report_root / "table_s2_csv_wfdb_timing.parquet"
    )

    comparison = read_records(output_root / "ppg_method_comparison.parquet")
    quantities = {
        "r_to_carotid_880nm_foot_ms": "Carotid PAT",
        "r_to_brachial_880nm_foot_ms": "Brachial PAT",
        "carotid_to_brachial_880nm_foot_ms": "Regional PTT",
    }
    table_s3 = comparison[
        comparison["quantity"].isin(quantities)
        & comparison["fiducial_method"].ne("intersecting_tangent")
    ].copy()
    table_s3["quantity"] = table_s3["quantity"].map(quantities)
    table_s3 = table_s3[
        [
            "fiducial_method",
            "quantity",
            "matched_beats",
            "matched_fraction",
            "median_signed_difference_ms",
            "median_absolute_difference_ms",
            "p95_absolute_difference_ms",
        ]
    ].round(3)
    table_s3_path = write_records(
        table_s3.to_dict("records"), report_root / "table_s3_ppg_point_differences.parquet"
    )
    return [
        table_2_path,
        table_4_path,
        table_5_path,
        table_6_path,
        table_s1_path,
        table_s2_path,
        table_s3_path,
    ]


def _flow_figure(report_root: Path) -> Path:
    steps = (
        ("338 sessions\n32 participants", "#DCEAF7"),
        ("18,005 beats\nautomatic fiducials", "#DDEFD8"),
        ("External QRS-onset +\nPPG method validation", "#FFF2CC"),
        ("Nested grouped CV\n32 LOSO tests", "#E8DEF8"),
        ("Preserved six-person\nexternal pilot", "#FCE4D6"),
    )
    fig, ax = plt.subplots(figsize=(13, 2.8))
    ax.axis("off")
    for index, (label, color) in enumerate(steps):
        x = 0.02 + index * 0.195
        ax.add_patch(
            plt.Rectangle((x, 0.28), 0.16, 0.42, facecolor=color, edgecolor="#284B63", lw=1.2)
        )
        ax.text(x + 0.08, 0.49, label, ha="center", va="center", fontsize=10)
        if index < len(steps) - 1:
            ax.annotate("", xy=(x + 0.19, 0.49), xytext=(x + 0.16, 0.49), arrowprops={"arrowstyle": "->"})
    path = report_root / "figure_1_analysis_flow.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def _ppg_method_figure(summary: pd.DataFrame, report_root: Path) -> Path:
    order = ["intersecting_tangent", "max_first_derivative", "max_second_derivative", "local_minimum"]
    part = summary.set_index("fiducial_method").loc[order]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].bar(np.arange(len(order)), part["record_coverage"], color="#2E6F9E")
    axes[0].axhline(0.70, color="#B33A3A", ls="--", lw=1)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_ylabel("Record coverage")
    axes[0].set_title("All three primary outcomes")
    axes[1].errorbar(
        np.arange(len(order)),
        part["composite_within_record_mad_ms"],
        yerr=np.vstack([
            part["composite_within_record_mad_ms"] - part["composite_mad_ci_low_ms"],
            part["composite_mad_ci_high_ms"] - part["composite_within_record_mad_ms"],
        ]),
        fmt="o",
        capsize=3,
        color="#2E6F9E",
    )
    axes[1].set_ylabel("Composite within-record MAD (ms)")
    axes[1].set_title("Participant-bootstrap 95% CI")
    labels = ["Tangent", "Max d1", "Max d2", "Local min"]
    for ax in axes:
        ax.set_xticks(np.arange(len(order)), labels, rotation=25)
        ax.grid(axis="y", alpha=0.2)
    path = report_root / "figure_3_ppg_method_robustness.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def _qtdb_figure(summary: pd.DataFrame, report_root: Path) -> Path:
    usable = summary[summary["reference_beats"].notna()].copy()
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    ax = axes[0]
    positions = np.arange(len(usable))
    low = usable["median_absolute_error_ms"] - usable["median_absolute_error_ci_low_ms"]
    high = usable["median_absolute_error_ci_high_ms"] - usable["median_absolute_error_ms"]
    ax.errorbar(
        positions,
        usable["median_absolute_error_ms"],
        yerr=np.vstack([low, high]),
        fmt="o",
        capsize=4,
        color="#174A7E",
    )
    ax.axhline(20, color="#B33A3A", ls="--", lw=1, label="Frozen 20-ms median gate")
    ax.set_xticks(positions, usable["reference_annotator"])
    ax.set_ylabel("Median absolute QRS-onset error (ms)")
    ax.set_title("Central timing error")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.2)
    tail_ax = axes[1]
    tail_ax.bar(positions, usable["within_30ms_fraction"], color="#174A7E", width=0.58)
    tail_ax.axhline(0.90, color="#B33A3A", ls="--", lw=1, label="Frozen 90% gate")
    tail_ax.set_xticks(positions, usable["reference_annotator"])
    tail_ax.set_ylim(0, 1.02)
    tail_ax.set_ylabel("Fraction within ±30 ms")
    tail_ax.set_title("Tail-accuracy gate")
    tail_ax.legend(frameon=False)
    tail_ax.grid(axis="y", alpha=0.2)
    fig.suptitle("QT Database external validation")
    path = report_root / "figure_2_qtdb_qrs_onset_validation.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def _raw_hr_figure(records: pd.DataFrame, report_root: Path) -> Path:
    labels = ("Carotid PAT", "Brachial PAT", "Regional PTT")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.3))
    for ax, outcome, label in zip(axes, PRIMARY, labels, strict=True):
        usable = records.dropna(subset=[outcome])
        ax.scatter(usable["median_hr_bpm"], usable[outcome], s=13, alpha=0.28, color="#174A7E")
        bins = pd.qcut(usable["median_hr_bpm"], 10, duplicates="drop")
        summary = usable.groupby(bins, observed=True).agg(
            hr=("median_hr_bpm", "median"), interval=(outcome, "median")
        )
        ax.plot(summary["hr"], summary["interval"], color="#B33A3A", marker="o", lw=2)
        ax.set_title(label)
        ax.set_xlabel("Heart rate (bpm)")
        ax.set_ylabel("Interval (ms)")
        ax.grid(alpha=0.2)
    path = report_root / "figure_4_raw_intervals_vs_hr.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def _candidate_figure(performance: pd.DataFrame, report_root: Path) -> Path:
    model_order = ["uncorrected", "linear", "quadratic", "restricted_cubic_spline", "gam"]
    labels = ("Carotid PAT", "Brachial PAT", "Regional PTT")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), sharey=True)
    for ax, outcome, label in zip(axes, PRIMARY, labels, strict=True):
        part = performance[performance["outcome"] == outcome].set_index("candidate_model").loc[model_order]
        low = part["mae_improvement_vs_uncorrected_pct"] - part["improvement_ci_low_pct"]
        high = part["improvement_ci_high_pct"] - part["mae_improvement_vs_uncorrected_pct"]
        ax.errorbar(
            np.arange(len(model_order)),
            part["mae_improvement_vs_uncorrected_pct"],
            yerr=np.vstack([low, high]),
            fmt="o",
            color="#174A7E",
            capsize=3,
        )
        ax.axhline(0, color="#555555", lw=1)
        ax.axhline(10, color="#B33A3A", lw=1, ls="--")
        ax.set_xticks(np.arange(len(model_order)), ["None", "Linear", "Quad.", "RCS", "GAM"], rotation=35)
        ax.set_title(label)
        ax.set_ylabel("LOSO MAE improvement (%)")
        ax.grid(axis="y", alpha=0.2)
    path = report_root / "figure_5_candidate_hr_correction.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def _external_gate_figure(manifest: dict[str, Any], report_root: Path) -> Path:
    gates = manifest["gates"]
    labels = ("Record\ncoverage", "HR-span\nsubjects", "R-peak\nagreement", "PTT polarity\nstability")
    observed = (
        gates["record_pass_fraction"],
        gates["subjects_with_30_bpm_span"] / 6.0,
        gates["r_annotation_agreement"],
        gates["stable_ptt_polarity_fraction"],
    )
    thresholds = (0.80, 4 / 6, 0.90, 0.80)
    passed = [value >= threshold for value, threshold in zip(observed, thresholds, strict=True)]
    colors = ["#2C7A4B" if status else "#B33A3A" for status in passed]
    fig, ax = plt.subplots(figsize=(8.5, 4.5))
    positions = np.arange(4)
    ax.bar(positions, observed, color=colors, width=0.62)
    ax.scatter(positions, thresholds, marker="_", s=700, linewidths=3, color="#17365D", label="Gate")
    for position, value in zip(positions, observed, strict=True):
        ax.text(position, value + 0.025, f"{value:.1%}", ha="center", fontweight="bold")
    ax.set_xticks(positions, labels)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Observed fraction")
    ax.set_title("Fixed-seed external replication pilot")
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.2)
    path = report_root / "figure_6_external_replication_gate.png"
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)
    return path


def generate_preliminary_reports(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    report_root = project_path(config, config["paths"]["report_root"])
    report_root.mkdir(parents=True, exist_ok=True)
    intervals = read_records(output_root / "intervals.parquet")
    quality = read_records(output_root / "beat_quality.parquet")
    performance = read_records(output_root / "candidate_performance.parquet")
    selections = read_records(output_root / "model_selection.parquet")
    ppg_summary = read_records(output_root / "ppg_method_summary.parquet")
    qtdb_summary = read_records(output_root / "qtdb_qrs_onset_summary.parquet")
    records = aggregate_records(intervals, list(PRIMARY), minimum_beats=10)

    coverage_rows = []
    for outcome in PRIMARY:
        usable = records.dropna(subset=[outcome])
        coverage_rows.append(
            {
                "outcome": outcome,
                "records_with_10_valid_beats": int(usable["record_id"].nunique()),
                "record_fraction": float(usable["record_id"].nunique() / records["record_id"].nunique()),
                "subjects": int(usable["subject"].nunique()),
                "median_ms": float(usable[outcome].median()),
                "iqr_ms": float(usable[outcome].quantile(0.75) - usable[outcome].quantile(0.25)),
            }
        )
    coverage_path = write_records(coverage_rows, report_root / "table_1_coverage.parquet")
    selection_rows = (
        selections.groupby(["outcome", "selected_model"]).size().rename("outer_folds").reset_index()
    )
    selection_path = write_records(selection_rows.to_dict("records"), report_root / "table_3_model_selection.parquet")

    q2_effects = performance[
        (performance["candidate_model"] != "uncorrected")
        & (performance["mae_improvement_vs_uncorrected_pct"] >= 10)
        & (performance["improvement_ci_low_pct"] > 0)
    ]
    external_manifest_path = output_root / "external_replication_manifest.json"
    external_manifest = (
        json.loads(external_manifest_path.read_text(encoding="utf-8"))
        if external_manifest_path.exists()
        else {"status": "not_run"}
    )
    publication_tables = _publication_tables(
        output_root,
        report_root,
        ppg_summary,
        performance,
        qtdb_summary,
        external_manifest,
    )
    validation_manifest = json.loads(
        (output_root / "algorithmic_validation_manifest.json").read_text(encoding="utf-8")
    )
    ppg_manifest = json.loads(
        (output_root / "ppg_method_sensitivity_manifest.json").read_text(encoding="utf-8")
    )
    qtdb_manifest = json.loads(
        (output_root / "qtdb_qrs_onset_manifest.json").read_text(encoding="utf-8")
    )
    gate = {
        "status": "algorithmic_analysis_complete",
        "method_version": config["study"]["method_version"],
        "all_338_records_processed": bool(records["record_id"].nunique() == 338),
        "primary_outcomes_with_30_subjects": int(sum(row["subjects"] >= 30 for row in coverage_rows)),
        "primary_outcomes_meeting_10pct_error_gate": int(q2_effects["outcome"].nunique()),
        "q2_effect_gate_passed": bool(q2_effects["outcome"].nunique() >= 2),
        "external_replication_status": external_manifest["status"],
        "algorithmic_validation_gate_passed": validation_manifest["completion_gate_passed"],
        "qtdb_qrs_onset_gate_passed": qtdb_manifest["primary_gate_passed"],
        "ppg_selected_method": ppg_manifest["selected_method_by_frozen_rule"],
        "selected_model_counts": selection_rows.to_dict("records"),
        "beat_primary_core_valid_fraction": float(quality["valid_primary_core"].mean()),
        "interpretation": "The prespecified 10% error-improvement criterion remains unmet; algorithmic validation does not convert a negative HR-correction result into a positive one.",
    }
    write_json(gate, report_root / "q2_q3_gate.json")
    figures = [
        str(_flow_figure(report_root)),
        str(_qtdb_figure(qtdb_summary, report_root)),
        str(_ppg_method_figure(ppg_summary, report_root)),
        str(_raw_hr_figure(records, report_root)),
        str(_candidate_figure(performance, report_root)),
    ]
    if external_manifest["status"] != "not_run":
        figures.append(str(_external_gate_figure(external_manifest, report_root)))
    lines = [
        "# Algorithmic analysis report",
        "",
        f"Method version: `{config['study']['method_version']}`.",
        "",
        f"- Sessions processed: {records['record_id'].nunique()}/338",
        f"- Participants represented: {records['subject'].nunique()}/32",
        f"- Extracted beats: {len(intervals):,}",
        f"- Beats passing the joint PAT/PTT core rule: {quality['valid_primary_core'].mean():.1%}",
        f"- Outcomes meeting the prespecified 10% error-improvement criterion: {q2_effects['outcome'].nunique()}/3",
        "- One-standard-error selection: uncorrected model in all current outer folds.",
        f"- External replication pilot: {external_manifest['status']}.",
        f"- QTDB QRS-onset validation: {qtdb_manifest['status']}.",
        f"- PPG foot method selected by the frozen quality/repeatability rule: {ppg_manifest['selected_method_by_frozen_rule']}.",
        "- PCG external point validation was not run because the accessible hand-corrected reference contains PCG state intervals but no synchronized ECG anchors required by this detector.",
        "- SCG landmarks are early/late systolic morphology proxies; no valve-event accuracy is claimed.",
        "",
        "Interpretation: algorithmic validation supports the extraction pipeline, but HR correction does not meet the prespecified improvement criterion in unseen participants. The result supports a methods/robustness contribution rather than a universal correction equation.",
    ]
    (report_root / "analysis_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "coverage_table": str(coverage_path),
        "model_selection_table": str(selection_path),
        "publication_tables": [str(path) for path in publication_tables],
        "figures": figures,
        "q2_effect_gate_passed": gate["q2_effect_gate_passed"],
        "algorithmic_validation_gate_passed": validation_manifest["completion_gate_passed"],
        "confirmatory": False,
    }
