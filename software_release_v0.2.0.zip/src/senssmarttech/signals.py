from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from pathlib import Path

import numpy as np

FORMAT_RE = re.compile(r"^(?P<format>\d+)(?:x(?P<samples_per_frame>\d+))?")
GAIN_RE = re.compile(r"^(?P<gain>[-+0-9.eE]+)(?:\((?P<baseline>[-+0-9]+)\))?/(?P<unit>.+)$")


@dataclass(frozen=True)
class SignalRecord:
    values: np.ndarray
    fs: float
    channel_names: tuple[str, ...]
    units: tuple[str, ...]
    source: Path


def read_wfdb_record(header_path: str | Path) -> SignalRecord:
    """Read the format-32 WFDB records shipped with SensSmartTech.

    A small local reader keeps the core pipeline independent of wfdb internals while
    respecting gain and baseline metadata in each header.
    """
    header = Path(header_path)
    lines = [line.strip() for line in header.read_text(encoding="utf-8").splitlines() if line.strip()]
    first = lines[0].split()
    if len(first) < 4:
        raise ValueError(f"Invalid WFDB header: {header}")
    n_signals = int(first[1])
    fs = float(first[2])
    n_samples = int(first[3])
    if len(lines) != n_signals + 1:
        raise ValueError(f"Header signal count mismatch: {header}")

    gains: list[float] = []
    baselines: list[int] = []
    units: list[str] = []
    names: list[str] = []
    data_file: str | None = None
    for line in lines[1:]:
        fields = line.split()
        data_file = data_file or fields[0]
        if fields[0] != data_file:
            raise ValueError("Multi-file WFDB records are not supported")
        fmt_match = FORMAT_RE.match(fields[1])
        if not fmt_match or int(fmt_match.group("format")) != 32:
            raise ValueError(f"Expected WFDB format 32 in {header}, got {fields[1]}")
        gain_match = GAIN_RE.match(fields[2])
        if not gain_match:
            raise ValueError(f"Cannot parse gain field {fields[2]} in {header}")
        gains.append(float(gain_match.group("gain")))
        baselines.append(int(gain_match.group("baseline") or 0))
        units.append(gain_match.group("unit"))
        names.append(fields[-1])

    raw = np.fromfile(header.parent / str(data_file), dtype="<i4")
    expected = n_samples * n_signals
    if raw.size != expected:
        raise ValueError(f"Expected {expected} samples in {data_file}, found {raw.size}")
    digital = raw.reshape(n_samples, n_signals).astype(np.float64)
    values = (digital - np.asarray(baselines)) / np.asarray(gains)
    return SignalRecord(values, fs, tuple(names), tuple(units), header)


def read_native_csv(path: str | Path) -> SignalRecord:
    source = Path(path)
    with source.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader)
        rows = [[float(cell) for cell in row] for row in reader if row]
    array = np.asarray(rows, dtype=float)
    time = array[:, 0]
    median_step = float(np.median(np.diff(time)))
    # SensSmartTech native CSV timestamps are expressed in milliseconds.
    fs = 1000.0 / median_step if median_step > 0.1 else 1.0 / median_step
    return SignalRecord(array[:, 1:], fs, tuple(header[1:]), tuple("a.u." for _ in header[1:]), source)


def _fft_convolve_same(values: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    n = values.shape[0]
    full_length = n + kernel.size - 1
    fft_length = 1 << (full_length - 1).bit_length()
    spectrum = np.fft.rfft(values, n=fft_length, axis=0)
    kernel_spectrum = np.fft.rfft(kernel, n=fft_length)
    convolved = np.fft.irfft(spectrum * kernel_spectrum[:, None], n=fft_length, axis=0)[:full_length]
    start = (kernel.size - 1) // 2
    return convolved[start : start + n]


def _fir_bandpass_kernel(fs: float, low_hz: float, high_hz: float) -> np.ndarray:
    taps = int(max(101, min(4001, round(2.0 * fs / low_hz))))
    taps += 1 - taps % 2
    index = np.arange(taps, dtype=float) - (taps - 1) / 2.0
    high = 2.0 * high_hz / fs * np.sinc(2.0 * high_hz * index / fs)
    low = 2.0 * low_hz / fs * np.sinc(2.0 * low_hz * index / fs)
    kernel = (high - low) * np.hamming(taps)
    centre_hz = (low_hz + high_hz) / 2.0
    response = abs(np.sum(kernel * np.exp(-2j * np.pi * centre_hz * index / fs)))
    return kernel / max(response, np.finfo(float).eps)


def bandpass(values: np.ndarray, fs: float, low_hz: float, high_hz: float, order: int = 4) -> np.ndarray:
    """Zero-phase windowed-sinc FIR filtering implemented with NumPy FFTs.

    ``order`` is accepted for configuration compatibility; the transition width is
    determined by the data-driven tap count. Forward and reverse application removes
    phase delay and mirrors the intended filtfilt behavior.
    """
    if not 0 < low_hz < high_hz < fs / 2:
        raise ValueError(f"Invalid passband {low_hz}-{high_hz} Hz for fs={fs}")
    array = np.asarray(values, dtype=float)
    one_dimensional = array.ndim == 1
    if one_dimensional:
        array = array[:, None]
    kernel = _fir_bandpass_kernel(fs, low_hz, high_hz)
    pad = min(array.shape[0] - 1, kernel.size)
    padded = np.pad(array, ((pad, pad), (0, 0)), mode="reflect")
    forward = _fft_convolve_same(padded, kernel)
    backward = _fft_convolve_same(forward[::-1], kernel)[::-1]
    result = backward[pad : pad + array.shape[0]]
    return result[:, 0] if one_dimensional else result


def robust_scale(values: np.ndarray) -> np.ndarray:
    median = np.nanmedian(values, axis=0)
    mad = np.nanmedian(np.abs(values - median), axis=0)
    scale = np.where(mad > 0, 1.4826 * mad, 1.0)
    return (values - median) / scale
