from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from .config import project_path
from .fiducials import detect_ppg_feet, detect_r_multilead
from .metadata import read_demographics
from .tables import read_records, write_json, write_records


def _valid_median(values: np.ndarray, low: float, high: float, minimum: int) -> tuple[float, int]:
    valid = values[np.isfinite(values) & (values >= low) & (values <= high)]
    return (float(np.median(valid)), int(valid.size)) if valid.size >= minimum else (float("nan"), int(valid.size))


def run_csv_timing_sensitivity(config: dict[str, Any]) -> dict[str, object]:
    csv_root = project_path(config, config["paths"]["csv_root"])
    output_root = project_path(config, config["paths"]["output_root"])
    records = read_demographics(project_path(config, config["paths"]["demographics"]))
    minimum = int(config["quality"]["minimum_valid_beats_per_record"])
    rows: list[dict[str, object]] = []
    failures: list[dict[str, str]] = []
    for record in records:
        try:
            ecg = pd.read_csv(csv_root / f"{record.record_id}_ecg.csv")
            ppg = pd.read_csv(csv_root / f"{record.record_id}_ppg.csv")
            ecg_time = ecg.iloc[:, 0].to_numpy(float)
            ppg_time = ppg.iloc[:, 0].to_numpy(float)
            ecg_fs = 1000.0 / float(np.median(np.diff(ecg_time)))
            ppg_fs = 1000.0 / float(np.median(np.diff(ppg_time)))
            r_detection = detect_r_multilead(ecg.iloc[:, 1:].to_numpy(float), ecg_fs)
            r_time = ecg_time[r_detection.samples]
            ppg_r = np.searchsorted(ppg_time, r_time)
            usable = (ppg_r > 0) & (ppg_r < len(ppg_time) - 1)
            ppg_r = ppg_r[usable]
            r_time = r_time[usable]
            carotid = detect_ppg_feet(ppg["carotid_880nm"].to_numpy(float), ppg_r, ppg_fs, "carotid")
            brachial = detect_ppg_feet(ppg["brachial_880nm"].to_numpy(float), ppg_r, ppg_fs, "brachial")
            carotid_pat = ppg_time[carotid] - r_time
            brachial_pat = ppg_time[brachial] - r_time
            ptt = ppg_time[brachial] - ppg_time[carotid]
            carotid_value, carotid_count = _valid_median(carotid_pat, 50, 500, minimum)
            brachial_value, brachial_count = _valid_median(brachial_pat, 50, 500, minimum)
            ptt_value, ptt_count = _valid_median(ptt, 10, 250, minimum)
            rows.append(
                {
                    "subject": record.subject,
                    "record_id": record.record_id,
                    "activity_state": record.activity_state,
                    "median_hr_bpm": record.median_hr_bpm,
                    "ecg_native_fs_hz": ecg_fs,
                    "ppg_native_fs_hz": ppg_fs,
                    "csv_r_to_carotid_880nm_foot_ms": carotid_value,
                    "csv_r_to_carotid_valid_beats": carotid_count,
                    "csv_r_to_brachial_880nm_foot_ms": brachial_value,
                    "csv_r_to_brachial_valid_beats": brachial_count,
                    "csv_carotid_to_brachial_880nm_foot_ms": ptt_value,
                    "csv_ptt_valid_beats": ptt_count,
                }
            )
        except (KeyError, OSError, ValueError, IndexError) as exc:
            failures.append({"record_id": record.record_id, "error": f"{type(exc).__name__}: {exc}"})
    csv_path = write_records(rows, output_root / "csv_timing_sensitivity.parquet")
    failure_path = write_records(failures, output_root / "csv_timing_failures.parquet")

    wfdb_beats = read_records(output_root / "intervals.parquet")
    wfdb = (
        wfdb_beats.groupby(["subject", "record_id"], as_index=False)[
            [
                "r_to_carotid_880nm_foot_ms",
                "r_to_brachial_880nm_foot_ms",
                "carotid_to_brachial_880nm_foot_ms",
            ]
        ]
        .median()
    )
    comparison = pd.DataFrame(rows).merge(wfdb, on=["subject", "record_id"], how="left")
    summary_rows: list[dict[str, object]] = []
    pairs = (
        ("carotid_pat", "csv_r_to_carotid_880nm_foot_ms", "r_to_carotid_880nm_foot_ms"),
        ("brachial_pat", "csv_r_to_brachial_880nm_foot_ms", "r_to_brachial_880nm_foot_ms"),
        ("regional_ptt", "csv_carotid_to_brachial_880nm_foot_ms", "carotid_to_brachial_880nm_foot_ms"),
    )
    for label, csv_column, wfdb_column in pairs:
        usable = comparison.dropna(subset=[csv_column, wfdb_column])
        difference = usable[csv_column] - usable[wfdb_column]
        summary_rows.append(
            {
                "outcome": label,
                "paired_records": len(usable),
                "median_csv_minus_wfdb_ms": float(difference.median()),
                "median_absolute_difference_ms": float(difference.abs().median()),
                "pearson_correlation": float(usable[[csv_column, wfdb_column]].corr().iloc[0, 1]),
            }
        )
    summary_path = write_records(summary_rows, output_root / "csv_wfdb_comparison.parquet")
    manifest = {
        "status": "complete",
        "records_processed": len(rows),
        "records_failed": len(failures),
        "native_timing_table": str(csv_path),
        "comparison_table": str(summary_path),
        "failures": str(failure_path),
        "claim_limit": "Native PPG resolution is approximately 10 ms; no sub-millisecond claim.",
    }
    write_json(manifest, output_root / "csv_sensitivity_manifest.json")
    return manifest
