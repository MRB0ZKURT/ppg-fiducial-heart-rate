from __future__ import annotations

import warnings
from typing import Any

import numpy as np

from .config import project_path
from .models import aggregate_records
from .statistics import holm_adjust
from .tables import read_records, write_json, write_records


def run_mixed_effects(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    validation_path = output_root / "algorithmic_validation_manifest.json"
    validation = (
        __import__("json").loads(validation_path.read_text(encoding="utf-8"))
        if validation_path.exists()
        else {}
    )
    if not validation.get("completion_gate_passed", False):
        manifest = {
            "status": "locked_pending_algorithmic_validation",
            "reason": "Mixed models require the algorithmic-validation completion gate.",
        }
        write_json(manifest, output_root / "mixed_effects_manifest.json")
        return manifest
    try:
        import statsmodels.formula.api as smf
    except (ImportError, OSError) as exc:
        manifest = {"status": "environment_blocked", "reason": f"{type(exc).__name__}: {exc}"}
        write_json(manifest, output_root / "mixed_effects_manifest.json")
        return manifest

    intervals = read_records(output_root / "intervals.parquet")
    outcomes = list(config["outcomes"]["primary"])
    frame = aggregate_records(intervals, outcomes, minimum_beats=10)
    frame["hr10_centered"] = (frame["median_hr_bpm"] - 70.0) / 10.0
    frame["elapsed_recording_time_surrogate_min"] = frame["elapsed_recording_time_surrogate_s"] / 60.0
    rows: list[dict[str, object]] = []
    primary_p_values: list[float] = []
    primary_indices: list[int] = []
    outcome_status: dict[str, dict[str, object]] = {}
    for outcome in outcomes:
        usable = frame.dropna(subset=[outcome]).copy()
        formula = (
            f"{outcome} ~ hr10_centered * C(activity_state) + "
            "elapsed_recording_time_surrogate_min"
        )
        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            fit = smf.mixedlm(
                formula, usable, groups=usable["subject"], re_formula="~hr10_centered"
            ).fit(reml=False, method=["lbfgs", "powell", "cg"], maxiter=2000)
        converged = bool(getattr(fit, "converged", False))
        outcome_status[outcome] = {
            "records": len(usable),
            "subjects": int(usable["subject"].nunique()),
            "converged": converged,
            "warnings": sorted({str(item.message) for item in captured}),
        }
        for term in fit.params.index:
            row = {
                "outcome": outcome,
                "term": term,
                "estimate": float(fit.params[term]),
                "standard_error": float(fit.bse[term]),
                "p_value": float(fit.pvalues[term]),
                "ci_low": float(fit.conf_int().loc[term, 0]),
                "ci_high": float(fit.conf_int().loc[term, 1]),
                "holm_adjusted_p": np.nan,
                "model_converged": converged,
            }
            if term == "hr10_centered" and converged:
                primary_indices.append(len(rows))
                primary_p_values.append(row["p_value"])
            rows.append(row)
    for index, adjusted in zip(primary_indices, holm_adjust(primary_p_values), strict=True):
        rows[index]["holm_adjusted_p"] = adjusted
    coefficient_path = write_records(rows, output_root / "mixed_effects_coefficients.parquet")
    all_converged = bool(outcome_status) and all(item["converged"] for item in outcome_status.values())
    manifest = {
        "status": "complete" if all_converged else "incomplete_nonconvergence",
        "method_version": config["study"]["method_version"],
        "coefficients": str(coefficient_path),
        "holm_adjustment": True,
        "human_annotation_required": False,
        "scaling": {"heart_rate": "per 10 bpm above 70", "elapsed_time": "minutes"},
        "outcomes": outcome_status,
    }
    write_json(manifest, output_root / "mixed_effects_manifest.json")
    return manifest
