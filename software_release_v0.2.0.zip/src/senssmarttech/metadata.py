from __future__ import annotations

import csv
import re
from dataclasses import asdict, dataclass
from pathlib import Path

RECORD_ID = re.compile(r"^(?P<subject>\d+)_(?P<hh>\d{2})-(?P<mm>\d{2})-(?P<ss>\d{2})$")


@dataclass(frozen=True)
class Record:
    file_number: int
    subject: int
    recording_time: str
    sex: str
    age_years: float
    height_cm: float
    weight_kg: float
    bmi: float
    activity_state: str
    median_hr_bpm: float
    record_id: str
    elapsed_recording_time_surrogate_s: float = 0.0
    recovery_segment: int = 0

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def read_demographics(path: str | Path) -> list[Record]:
    """Read the unusual two-header-row demographics table without altering source data."""
    rows: list[dict[str, str]] = []
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        next(reader)
        header = next(reader)[:14]
        for values in reader:
            if not values or not values[0].strip():
                continue
            rows.append(dict(zip(header, values[:14], strict=True)))

    records: list[Record] = []
    for row in rows:
        ecg_stem = row["ECG"].strip()
        record_id = ecg_stem.removesuffix("_ecg")
        match = RECORD_ID.fullmatch(record_id)
        if not match:
            raise ValueError(f"Unexpected record identifier: {record_id}")
        if int(match.group("subject")) != int(row["Subject number"]):
            raise ValueError(f"Subject mismatch in {record_id}")
        records.append(
            Record(
                file_number=int(row["File number"]),
                subject=int(row["Subject number"]),
                recording_time=row["Recording time (hh:mm:ss)"].strip(),
                sex=row["Gender"].strip(),
                age_years=float(row["Age (year)"]),
                height_cm=float(row["Height (cm)"]),
                weight_kg=float(row["Weight (kg)"]),
                bmi=float(row["Body-mass index"]),
                activity_state=row["Before (B)  / after (A) activity"].strip(),
                median_hr_bpm=float(row["Median heart rate (bpm)"]),
                record_id=record_id,
            )
        )
    return add_elapsed_time_surrogate(records)


def _seconds(time_text: str) -> int:
    hours, minutes, seconds = (int(value) for value in time_text.split(":"))
    return hours * 3600 + minutes * 60 + seconds


def add_elapsed_time_surrogate(records: list[Record]) -> list[Record]:
    """Add within-subject recording time and split subject 2 at a second HR rise."""
    by_subject: dict[int, list[Record]] = {}
    for record in records:
        by_subject.setdefault(record.subject, []).append(record)

    enriched: list[Record] = []
    for subject, subject_records in by_subject.items():
        ordered = sorted(subject_records, key=lambda item: (_seconds(item.recording_time), item.file_number))
        start = _seconds(ordered[0].recording_time)
        previous_hr: float | None = None
        segment = 0
        for record in ordered:
            if (
                subject == 2
                and record.activity_state == "A"
                and previous_hr is not None
                and record.median_hr_bpm - previous_hr >= 15
            ):
                segment += 1
            previous_hr = record.median_hr_bpm
            enriched.append(
                Record(
                    **{
                        **record.to_dict(),
                        "elapsed_recording_time_surrogate_s": float(_seconds(record.recording_time) - start),
                        "recovery_segment": segment,
                    }
                )
            )
    return sorted(enriched, key=lambda item: item.file_number)
