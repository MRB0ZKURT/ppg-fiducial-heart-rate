from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


def load_config(path: str | Path = "config/analysis_config.yaml") -> dict[str, Any]:
    config_path = Path(path)
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    config["_config_path"] = str(config_path.resolve())
    return config


def project_path(config: dict[str, Any], configured_path: str) -> Path:
    config_dir = Path(config["_config_path"]).parent
    project_root = config_dir.parent
    return (project_root / configured_path).resolve()
