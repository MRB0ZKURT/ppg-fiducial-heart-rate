from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from .config import project_path
from .tables import read_records, write_json, write_records

COMPLEXITY = {
    "uncorrected": 0,
    "linear": 1,
    "quadratic": 2,
    "restricted_cubic_spline": 3,
    "gam": 4,
}


@dataclass
class CandidateModel:
    name: str
    coefficients: np.ndarray | None = None
    knots: np.ndarray | None = None
    ridge_alpha: float = 0.0

    def _spline_basis(self, x: np.ndarray, fit: bool) -> np.ndarray:
        knot_count = 4 if self.name == "restricted_cubic_spline" else 8
        if fit or self.knots is None:
            quantiles = np.linspace(0.05, 0.95, knot_count)
            self.knots = np.unique(np.quantile(x[:, 0], quantiles))
        knots = np.asarray(self.knots, dtype=float)
        if knots.size < 3:
            return x
        first, penultimate, last = knots[0], knots[-2], knots[-1]
        scale = max((last - first) ** 2, np.finfo(float).eps)
        columns = [x[:, 0]]
        for knot in knots[:-2]:
            positive = lambda value: np.maximum(x[:, 0] - value, 0.0) ** 3
            basis = (
                positive(knot)
                - positive(penultimate) * (last - knot) / (last - penultimate)
                + positive(last) * (penultimate - knot) / (last - penultimate)
            ) / scale
            columns.append(basis)
        return np.column_stack(columns)

    def _matrix(self, frame, fit: bool = False, reference_hr: float | None = None) -> np.ndarray:
        hr = np.asarray(frame["median_hr_bpm"], dtype=float)
        if reference_hr is not None:
            hr = np.full_like(hr, reference_hr)
        x = (hr - 70.0)[:, None]
        activity = (np.asarray(frame["activity_state"]) == "A").astype(float)[:, None]
        elapsed = (np.asarray(frame["elapsed_recording_time_surrogate_s"], dtype=float) / 60.0)[:, None]
        if self.name == "uncorrected":
            return np.column_stack([activity, elapsed])
        if self.name == "linear":
            return np.column_stack([x, activity, elapsed, x * activity])
        if self.name == "quadratic":
            return np.column_stack([x, x**2, activity, elapsed, x * activity, x**2 * activity])
        spline_values = self._spline_basis(x, fit)
        return np.column_stack([spline_values, activity, elapsed, spline_values * activity])

    def fit(self, frame, y: np.ndarray) -> CandidateModel:
        design = self._matrix(frame, fit=True)
        design = np.column_stack([np.ones(design.shape[0]), design])
        if self.name == "gam":
            alphas = np.logspace(-4, 4, 25)
            best_score = np.inf
            best_coefficients = None
            for alpha in alphas:
                penalty = np.eye(design.shape[1]) * alpha
                penalty[0, 0] = 0.0
                coefficients = np.linalg.pinv(design.T @ design + penalty) @ design.T @ y
                residual = y - design @ coefficients
                hat_trace = float(
                    np.trace(design @ np.linalg.pinv(design.T @ design + penalty) @ design.T)
                )
                denominator = max((design.shape[0] - hat_trace) ** 2, 1.0)
                gcv = float(np.sum(residual**2) * design.shape[0] / denominator)
                if gcv < best_score:
                    best_score = gcv
                    self.ridge_alpha = float(alpha)
                    best_coefficients = coefficients
            self.coefficients = best_coefficients
        else:
            self.coefficients = np.linalg.pinv(design) @ y
        return self

    def predict(self, frame, reference_hr: float | None = None) -> np.ndarray:
        design = self._matrix(frame, reference_hr=reference_hr)
        design = np.column_stack([np.ones(design.shape[0]), design])
        return np.asarray(design @ self.coefficients)


def aggregate_records(intervals, outcomes: list[str], minimum_beats: int = 10):
    identifiers = [
        "subject",
        "record_id",
        "activity_state",
        "median_hr_bpm",
        "elapsed_recording_time_surrogate_s",
        "recovery_segment",
        "age_years",
        "biological_sex",
        "bmi",
    ]
    existing = [outcome for outcome in outcomes if outcome in intervals.columns]
    grouped = intervals[identifiers + existing].groupby(identifiers, as_index=False, dropna=False)
    medians = grouped.median(numeric_only=True)
    counts = grouped[existing].count()
    for outcome in existing:
        medians.loc[counts[outcome] < minimum_beats, outcome] = np.nan
        medians[f"{outcome}_valid_beats"] = counts[outcome]
    return medians


def _inner_scores(frame, outcome: str, candidates: list[str], folds: int) -> dict[str, list[float]]:
    groups = np.asarray(frame["subject"])
    unique_groups = np.unique(groups)
    n_splits = min(folds, unique_groups.size)
    fold_by_group = {group: index % n_splits for index, group in enumerate(unique_groups)}
    scores = {candidate: [] for candidate in candidates}
    for fold in range(n_splits):
        validation = np.flatnonzero([fold_by_group[group] == fold for group in groups])
        train = np.flatnonzero([fold_by_group[group] != fold for group in groups])
        train_frame = frame.iloc[train]
        validation_frame = frame.iloc[validation]
        y_train = np.asarray(train_frame[outcome], dtype=float)
        y_validation = np.asarray(validation_frame[outcome], dtype=float)
        for candidate in candidates:
            model = CandidateModel(candidate).fit(train_frame, y_train)
            error = model.predict(validation_frame) - y_validation
            scores[candidate].append(float(np.sqrt(np.mean(error**2))))
    return scores


def _one_se_choice(scores: dict[str, list[float]]) -> str:
    means = {name: float(np.mean(values)) for name, values in scores.items()}
    best = min(means, key=means.get)
    best_values = np.asarray(scores[best])
    standard_error = float(np.std(best_values, ddof=1) / np.sqrt(best_values.size)) if best_values.size > 1 else 0.0
    eligible = [name for name, mean in means.items() if mean <= means[best] + standard_error]
    return min(eligible, key=lambda name: COMPLEXITY[name])


def nested_loso(frame, outcome: str, config: dict[str, Any]) -> tuple[list[dict], list[dict], list[dict]]:
    candidates = list(config["models"]["candidates"])
    inner_folds = int(config["models"]["inner_folds"])
    predictions: list[dict] = []
    selections: list[dict] = []
    candidate_predictions: list[dict] = []
    for held_out in sorted(frame["subject"].unique()):
        train = frame[frame["subject"] != held_out].reset_index(drop=True)
        test = frame[frame["subject"] == held_out].reset_index(drop=True)
        scores = _inner_scores(train, outcome, candidates, inner_folds)
        chosen = _one_se_choice(scores)
        fitted: dict[str, tuple[np.ndarray, np.ndarray]] = {}
        for candidate in candidates:
            candidate_model = CandidateModel(candidate).fit(train, np.asarray(train[outcome], dtype=float))
            candidate_predicted = candidate_model.predict(test)
            candidate_reference = candidate_model.predict(test, reference_hr=70.0)
            candidate_corrected = np.asarray(test[outcome], dtype=float) - (
                candidate_predicted - candidate_reference
            )
            fitted[candidate] = (candidate_predicted, candidate_corrected)
            for index, row in test.iterrows():
                candidate_predictions.append(
                    {
                        "subject": int(row["subject"]),
                        "record_id": row["record_id"],
                        "activity_state": row["activity_state"],
                        "heart_rate_bpm": float(row["median_hr_bpm"]),
                        "outcome": outcome,
                        "candidate_model": candidate,
                        "observed_ms": float(row[outcome]),
                        "predicted_ms": float(candidate_predicted[index]),
                        "prediction_error_ms": float(candidate_predicted[index] - row[outcome]),
                        "corrected_to_70_bpm_ms": float(candidate_corrected[index]),
                        "outer_fold_subject": int(held_out),
                    }
                )
        predicted, corrected = fitted[chosen]
        for index, row in test.iterrows():
            predictions.append(
                {
                    "subject": int(row["subject"]),
                    "record_id": row["record_id"],
                    "activity_state": row["activity_state"],
                    "heart_rate_bpm": float(row["median_hr_bpm"]),
                    "outcome": outcome,
                    "observed_ms": float(row[outcome]),
                    "predicted_ms": float(predicted[index]),
                    "prediction_error_ms": float(predicted[index] - row[outcome]),
                    "corrected_to_70_bpm_ms": float(corrected[index]),
                    "selected_model": chosen,
                    "outer_fold_subject": int(held_out),
                }
            )
        selections.append(
            {
                "outcome": outcome,
                "outer_fold_subject": int(held_out),
                "selected_model": chosen,
                **{f"inner_rmse_{name}": float(np.mean(values)) for name, values in scores.items()},
            }
        )
    return predictions, selections, candidate_predictions


def _correlation(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def summarize_candidate_performance(candidate_frame, repetitions: int, seed: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    rows: list[dict[str, object]] = []
    for outcome, outcome_frame in candidate_frame.groupby("outcome"):
        uncorrected = outcome_frame[outcome_frame["candidate_model"] == "uncorrected"].set_index(
            ["subject", "record_id"]
        )
        for candidate, candidate_frame_part in outcome_frame.groupby("candidate_model"):
            current = candidate_frame_part.set_index(["subject", "record_id"])
            common = uncorrected.index.intersection(current.index)
            raw_error = np.abs(
                np.asarray(uncorrected.loc[common, "prediction_error_ms"], dtype=float)
            )
            corrected_error = np.abs(
                np.asarray(current.loc[common, "prediction_error_ms"], dtype=float)
            )
            subjects = np.asarray([index[0] for index in common])
            unique_subjects = np.unique(subjects)
            improvements = np.empty(repetitions, dtype=float)
            for iteration in range(repetitions):
                sampled = rng.choice(unique_subjects, size=unique_subjects.size, replace=True)
                indices = np.concatenate([np.flatnonzero(subjects == subject) for subject in sampled])
                raw_mae = float(np.mean(raw_error[indices]))
                corrected_mae = float(np.mean(corrected_error[indices]))
                improvements[iteration] = 100.0 * (raw_mae - corrected_mae) / max(raw_mae, 1e-12)
            hr = np.asarray(current.loc[common, "heart_rate_bpm"], dtype=float)
            observed = np.asarray(current.loc[common, "observed_ms"], dtype=float)
            corrected_values = np.asarray(current.loc[common, "corrected_to_70_bpm_ms"], dtype=float)
            rows.append(
                {
                    "outcome": outcome,
                    "candidate_model": candidate,
                    "records": int(common.size),
                    "subjects": int(unique_subjects.size),
                    "mae_ms": float(np.mean(corrected_error)),
                    "rmse_ms": float(np.sqrt(np.mean(corrected_error**2))),
                    "mae_improvement_vs_uncorrected_pct": float(np.mean(improvements)),
                    "improvement_ci_low_pct": float(np.quantile(improvements, 0.025)),
                    "improvement_ci_high_pct": float(np.quantile(improvements, 0.975)),
                    "raw_interval_hr_correlation": _correlation(observed, hr),
                    "corrected_interval_hr_correlation": _correlation(corrected_values, hr),
                }
            )
    return rows


def run_analysis(config: dict[str, Any]) -> dict[str, object]:
    output_root = project_path(config, config["paths"]["output_root"])
    intervals = read_records(output_root / "intervals.parquet")
    outcomes = list(config["outcomes"]["primary"])
    record_frame = aggregate_records(
        intervals, outcomes, minimum_beats=int(config["quality"]["minimum_valid_beats_per_record"])
    )
    all_predictions: list[dict] = []
    all_selections: list[dict] = []
    all_candidate_predictions: list[dict] = []
    outcome_status: dict[str, dict[str, object]] = {}
    for outcome in outcomes:
        if outcome not in record_frame:
            outcome_status[outcome] = {"status": "missing"}
            continue
        usable = record_frame.dropna(subset=[outcome]).reset_index(drop=True)
        subject_count = int(usable["subject"].nunique())
        record_fraction = float(usable["record_id"].nunique() / record_frame["record_id"].nunique())
        eligible = (
            subject_count >= config["quality"]["minimum_subjects_primary"]
            and record_fraction >= config["quality"]["minimum_valid_record_fraction"]
        )
        outcome_status[outcome] = {
            "status": "eligible" if eligible else "demoted",
            "subjects": subject_count,
            "record_fraction": record_fraction,
        }
        if not eligible:
            continue
        predictions, selections, candidate_predictions = nested_loso(usable, outcome, config)
        all_predictions.extend(predictions)
        all_selections.extend(selections)
        all_candidate_predictions.extend(candidate_predictions)
    prediction_path = write_records(all_predictions, output_root / "model_predictions.parquet")
    selection_path = write_records(all_selections, output_root / "model_selection.parquet")
    candidate_path = write_records(all_candidate_predictions, output_root / "candidate_predictions.parquet")
    import pandas as pd

    performance_rows = summarize_candidate_performance(
        pd.DataFrame(all_candidate_predictions),
        int(config["models"]["bootstrap_repetitions"]),
        int(config["study"]["random_seed"]),
    )
    performance_path = write_records(performance_rows, output_root / "candidate_performance.parquet")
    validation_path = output_root / "algorithmic_validation_manifest.json"
    validation_manifest = (
        __import__("json").loads(validation_path.read_text(encoding="utf-8"))
        if validation_path.exists()
        else {"completion_gate_passed": False, "status": "not_run"}
    )
    manifest = {
        "method_version": config["study"]["method_version"],
        "analysis_status": "post_method_revision",
        "analysis_unit": "record-level median",
        "outer_validation": "leave-one-subject-out",
        "reference_heart_rate_bpm": 70,
        "outcomes": outcome_status,
        "predictions": str(prediction_path),
        "model_selection": str(selection_path),
        "candidate_predictions": str(candidate_path),
        "candidate_performance": str(performance_path),
        "bootstrap_repetitions_completed": int(config["models"]["bootstrap_repetitions"]),
        "algorithmic_validation_status": validation_manifest.get("status"),
        "algorithmic_validation_gate_passed": bool(validation_manifest.get("completion_gate_passed")),
        "confirmatory_complete": False,
        "completion_requires": [
            "algorithmic_validation_gate_passed",
            "ppg_method_selection_rule_satisfied",
            "holm_adjustment_complete",
        ],
    }
    write_json(manifest, output_root / "results_manifest.json")
    return manifest
