from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.io import loadmat
from scipy.io.wavfile import read as read_wav


@dataclass(frozen=True)
class PCGReferenceRecord:
    """Parsed PhysioNet/CinC 2016 PCG plus hand-corrected state boundaries.

    The state onsets are reference annotations in the external PCG recording.
    They are not synchronized ECG anchors and therefore cannot, by themselves,
    validate the ECG-anchored SensSmartTech S1/S2 detector.
    """

    sampling_frequency_hz: float
    signal: np.ndarray
    state_start_samples: np.ndarray
    state_labels: tuple[str, ...]

    @property
    def s1_start_samples(self) -> np.ndarray:
        return self.state_start_samples[np.asarray(self.state_labels) == "S1"]

    @property
    def s2_start_samples(self) -> np.ndarray:
        return self.state_start_samples[np.asarray(self.state_labels) == "S2"]


def read_physionet_2016_hand_corrected_record(
    wav_path: str | Path,
    state_annotation_path: str | Path,
) -> PCGReferenceRecord:
    """Read one Challenge 2016 WAV/state pair and validate its structure.

    MATLAB annotation indices are converted from one-based to zero-based sample
    indices. No performance metric is calculated here because the external file
    lacks the synchronized ECG R annotations required by the active detector.
    """

    sampling_frequency_hz, signal = read_wav(Path(wav_path))
    annotation = loadmat(Path(state_annotation_path), squeeze_me=True)
    if "state_ans" not in annotation:
        raise ValueError("Expected MATLAB variable 'state_ans' was not found")

    state_ans = np.asarray(annotation["state_ans"], dtype=object)
    if state_ans.ndim != 2 or state_ans.shape[1] != 2:
        raise ValueError("state_ans must be an N x 2 array of sample and state label")

    starts = np.asarray(state_ans[:, 0], dtype=int) - 1
    labels = tuple(str(label) for label in state_ans[:, 1])
    allowed = {"S1", "systole", "S2", "diastole"}
    unexpected = sorted(set(labels) - allowed)
    if unexpected:
        raise ValueError(f"Unexpected PCG state labels: {unexpected}")
    if starts.size == 0 or starts[0] < 0 or np.any(np.diff(starts) <= 0):
        raise ValueError("Reference state starts must be non-empty and strictly increasing")
    if starts[-1] >= len(signal):
        raise ValueError("Reference state start lies outside the WAV signal")

    return PCGReferenceRecord(
        sampling_frequency_hz=float(sampling_frequency_hz),
        signal=np.asarray(signal, dtype=float),
        state_start_samples=starts,
        state_labels=labels,
    )
