from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from .config import project_path
from .fiducials import (
    detect_ppg_feet_with_quality,
    detect_ppg_peak_notch,
    detect_q_onsets_wavelet,
    detect_r_multilead,
    detect_s1_s2,
    detect_scg_systolic_proxies,
)
from .metadata import Record, read_demographics
from .quality import robust_snr_db, temporal_order_mask, valid_rr_mask
from .signals import read_wfdb_record
from .tables import write_records

PPG_CHANNELS = (
    ("carotid", "880nm", "carotid_880nm"),
    ("carotid", "660nm", "carotid_660nm"),
    ("brachial", "880nm", "brachial_880nm"),
    ("brachial", "660nm", "brachial_660nm"),
)


def _ms(delta_samples: np.ndarray, fs: float) -> np.ndarray:
    values = delta_samples.astype(float) * 1000.0 / fs
    values[delta_samples < 0] = np.nan
    return values


def _ms_signed(delta_samples: np.ndarray, fs: float) -> np.ndarray:
    return delta_samples.astype(float) * 1000.0 / fs


def _channel_index(names: tuple[str, ...], expected: str) -> int:
    normalized = {name.lower().replace("-", "_"): index for index, name in enumerate(names)}
    key = expected.lower().replace("-", "_")
    if key not in normalized:
        raise KeyError(f"Channel {expected} not found in {names}")
    return normalized[key]


def extract_record(record: Record, wfdb_root: Path, config: dict[str, Any]) -> tuple[list[dict], list[dict]]:
    ecg = read_wfdb_record(wfdb_root / f"{record.record_id}_ecg.hea")
    ppg = read_wfdb_record(wfdb_root / f"{record.record_id}_ppg.hea")
    pcg = read_wfdb_record(wfdb_root / f"{record.record_id}_pcg.hea")
    acc = read_wfdb_record(wfdb_root / f"{record.record_id}_acc.hea")
    if len({ecg.fs, ppg.fs, pcg.fs, acc.fs}) != 1:
        raise ValueError(f"WFDB modalities do not share a sampling rate for {record.record_id}")
    fs = ecg.fs

    r_detection = detect_r_multilead(ecg.values, fs)
    r = r_detection.samples
    lead_snr = np.asarray([robust_snr_db(ecg.values[:, index]) for index in range(ecg.values.shape[1])])
    q = detect_q_onsets_wavelet(ecg.values[:, int(np.argmax(lead_snr))], r, fs)
    s1, s2 = detect_s1_s2(pcg.values[:, 0], r, fs)
    early_scg, late_scg = detect_scg_systolic_proxies(acc.values[:, 0], r, fs, s2)
    selected_ppg_method = config["algorithmic_validation"]["ppg"]["selected_method"]

    feet: dict[tuple[str, str], np.ndarray] = {}
    peaks: dict[tuple[str, str], np.ndarray] = {}
    notches: dict[tuple[str, str], np.ndarray] = {}
    half_crossings: dict[tuple[str, str], np.ndarray] = {}
    foot_confidence: dict[tuple[str, str], np.ndarray] = {}
    foot_failure: dict[tuple[str, str], tuple[str, ...]] = {}
    for site, wavelength, channel in PPG_CHANNELS:
        index = _channel_index(ppg.channel_names, channel)
        detection = detect_ppg_feet_with_quality(
            ppg.values[:, index], r, fs, site, selected_ppg_method
        )
        channel_feet = detection.samples
        channel_peaks, channel_notches, channel_half = detect_ppg_peak_notch(
            ppg.values[:, index], channel_feet, fs
        )
        feet[(site, wavelength)] = channel_feet
        peaks[(site, wavelength)] = channel_peaks
        notches[(site, wavelength)] = channel_notches
        half_crossings[(site, wavelength)] = channel_half
        foot_confidence[(site, wavelength)] = detection.confidence
        foot_failure[(site, wavelength)] = detection.failure_reason

    rr_valid = valid_rr_mask(
        r,
        fs,
        config["quality"]["rr_min_ms"],
        config["quality"]["rr_max_ms"],
    )
    q_early_scg_valid = temporal_order_mask(q, early_scg)
    early_late_scg_valid = temporal_order_mask(early_scg, late_scg)
    base = {
        "subject": record.subject,
        "record_id": record.record_id,
        "activity_state": record.activity_state,
        "median_hr_bpm": record.median_hr_bpm,
        "elapsed_recording_time_surrogate_s": record.elapsed_recording_time_surrogate_s,
        "recovery_segment": record.recovery_segment,
        "age_years": record.age_years,
        "biological_sex": record.sex,
        "bmi": record.bmi,
        "source": "WFDB",
        "fs_hz": fs,
    }
    intervals: list[dict] = []
    quality_rows: list[dict] = []
    for beat in range(r.size):
        q_to_early_scg = float(_ms(np.asarray([early_scg[beat] - q[beat]]), fs)[0])
        early_to_late_scg = float(_ms(np.asarray([late_scg[beat] - early_scg[beat]]), fs)[0])
        row = {
            **base,
            "beat_index": beat,
            "r_sample": int(r[beat]),
            "q_sample": int(q[beat]),
            "s1_sample": int(s1[beat]),
            "s2_sample": int(s2[beat]),
            "early_systolic_scg_proxy_sample": int(early_scg[beat]),
            "late_systolic_scg_proxy_sample": int(late_scg[beat]),
            "q_to_early_systolic_scg_proxy_ms": (
                q_to_early_scg if q_early_scg_valid[beat] and 20 <= q_to_early_scg <= 300 else np.nan
            ),
            "early_to_late_systolic_scg_proxy_ms": (
                early_to_late_scg
                if early_late_scg_valid[beat] and 80 <= early_to_late_scg <= 500
                else np.nan
            ),
            "q_to_s1_ms": float(_ms(np.asarray([s1[beat] - q[beat]]), fs)[0]),
            "s1_to_s2_ms": float(_ms(np.asarray([s2[beat] - s1[beat]]), fs)[0]),
        }
        for site, wavelength, _ in PPG_CHANNELS:
            label = f"{site}_{wavelength}"
            foot = feet[(site, wavelength)][beat]
            peak = peaks[(site, wavelength)][beat]
            notch = notches[(site, wavelength)][beat]
            half = half_crossings[(site, wavelength)][beat]
            row[f"{label}_foot_sample"] = int(foot)
            row[f"{label}_foot_confidence"] = float(foot_confidence[(site, wavelength)][beat])
            row[f"{label}_foot_failure_reason"] = foot_failure[(site, wavelength)][beat]
            pat = float(_ms(np.asarray([foot - r[beat]]), fs)[0])
            row[f"r_to_{label}_foot_ms"] = pat if 50 <= pat <= 500 else np.nan
            row[f"{label}_rise_time_ms"] = float(_ms(np.asarray([peak - foot]), fs)[0])
            row[f"{label}_peak_to_notch_ms"] = float(_ms(np.asarray([notch - peak]), fs)[0])
            row[f"{label}_normalized_pulse_width"] = (
                float((half - foot) / max(1, r[min(beat + 1, r.size - 1)] - r[beat]))
                if half >= 0 and beat + 1 < r.size
                else np.nan
            )
        for wavelength in ("880nm", "660nm"):
            delta = feet[("brachial", wavelength)][beat] - feet[("carotid", wavelength)][beat]
            signed_ptt = float(_ms_signed(np.asarray([delta]), fs)[0])
            row[f"carotid_to_brachial_{wavelength}_signed_ms"] = signed_ptt
            row[f"carotid_to_brachial_{wavelength}_foot_ms"] = (
                signed_ptt if 10 <= signed_ptt <= 250 else np.nan
            )
        intervals.append(row)

        ppg_order = {
            wavelength: bool(
                temporal_order_mask(
                    feet[("carotid", wavelength)][beat : beat + 1],
                    feet[("brachial", wavelength)][beat : beat + 1],
                )[0]
            )
            for wavelength in ("880nm", "660nm")
        }
        carotid_pat = row["r_to_carotid_880nm_foot_ms"]
        brachial_pat = row["r_to_brachial_880nm_foot_ms"]
        regional_ptt = row["carotid_to_brachial_880nm_foot_ms"]
        valid_primary = bool(
            rr_valid[beat]
            and np.isfinite(carotid_pat)
            and np.isfinite(brachial_pat)
            and np.isfinite(regional_ptt)
        )
        quality_rows.append(
            {
                **base,
                "beat_index": beat,
                "r_votes": int(r_detection.votes[beat]),
                "r_confidence": float(r_detection.confidence[beat]),
                "rr_valid": bool(rr_valid[beat]),
                "q_to_early_scg_proxy_order_valid": bool(q_early_scg_valid[beat]),
                "early_to_late_scg_proxy_order_valid": bool(early_late_scg_valid[beat]),
                "ppg_foot_method": selected_ppg_method,
                "carotid_before_brachial_880nm": ppg_order["880nm"],
                "carotid_before_brachial_660nm": ppg_order["660nm"],
                "carotid_pat_880nm_valid": bool(rr_valid[beat] and np.isfinite(carotid_pat)),
                "brachial_pat_880nm_valid": bool(rr_valid[beat] and np.isfinite(brachial_pat)),
                "regional_ptt_880nm_valid": bool(rr_valid[beat] and np.isfinite(regional_ptt)),
                "valid_primary_core": valid_primary,
                "exclusion_reason": "" if valid_primary else "failed_rr_pat_or_ptt_rule",
            }
        )
    return intervals, quality_rows


def run_extraction(config: dict[str, Any], limit: int | None = None) -> dict[str, object]:
    demographics = project_path(config, config["paths"]["demographics"])
    wfdb_root = project_path(config, config["paths"]["wfdb_root"])
    output_root = project_path(config, config["paths"]["output_root"])
    records = read_demographics(demographics)
    if limit is not None:
        records = records[:limit]
    all_intervals: list[dict] = []
    all_quality: list[dict] = []
    failures: list[dict[str, str]] = []
    for record in records:
        try:
            intervals, quality = extract_record(record, wfdb_root, config)
            all_intervals.extend(intervals)
            all_quality.extend(quality)
        except Exception as exc:  # noqa: BLE001 - every record failure is retained in the audit table
            failures.append({"record_id": record.record_id, "error": f"{type(exc).__name__}: {exc}"})
    interval_path = write_records(all_intervals, output_root / "intervals.parquet")
    quality_path = write_records(all_quality, output_root / "beat_quality.parquet")
    failure_path = write_records(failures, output_root / "extraction_failures.parquet")
    return {
        "records_requested": len(records),
        "records_failed": len(failures),
        "beats_extracted": len(all_intervals),
        "intervals": str(interval_path),
        "beat_quality": str(quality_path),
        "failures": str(failure_path),
    }
