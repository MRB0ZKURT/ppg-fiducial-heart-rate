from __future__ import annotations

import csv
import json
from collections.abc import Iterable, Mapping
from pathlib import Path


def write_records(rows: Iterable[Mapping[str, object]], parquet_path: str | Path) -> Path:
    """Write Parquet when pyarrow is available and always provide a CSV companion."""
    materialized = list(rows)
    target = Path(parquet_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    csv_path = target.with_suffix(".csv")
    if materialized:
        with csv_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(materialized[0].keys()))
            writer.writeheader()
            writer.writerows(materialized)
    try:
        import pandas as pd

        pd.DataFrame(materialized).to_parquet(target, index=False)
        return target
    except (ImportError, ModuleNotFoundError):
        return csv_path


def write_json(payload: Mapping[str, object], path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    return target


def read_records(path: str | Path):
    import pandas as pd

    source = Path(path)
    if source.exists() and source.suffix == ".parquet":
        return pd.read_parquet(source)
    csv_path = source.with_suffix(".csv") if source.suffix == ".parquet" else source
    return pd.read_csv(csv_path)
