from __future__ import annotations

import numpy as np


def icc_2_1(values: np.ndarray) -> float:
    """Two-way random-effects, absolute-agreement, single-measure ICC."""
    array = np.asarray(values, dtype=float)
    array = array[np.all(np.isfinite(array), axis=1)]
    n, k = array.shape
    if n < 2 or k < 2:
        return float("nan")
    grand = float(np.mean(array))
    row_means = np.mean(array, axis=1)
    column_means = np.mean(array, axis=0)
    ms_rows = k * float(np.sum((row_means - grand) ** 2)) / (n - 1)
    ms_columns = n * float(np.sum((column_means - grand) ** 2)) / (k - 1)
    residual = array - row_means[:, None] - column_means[None, :] + grand
    ms_error = float(np.sum(residual**2)) / ((n - 1) * (k - 1))
    denominator = ms_rows + (k - 1) * ms_error + k * (ms_columns - ms_error) / n
    return float((ms_rows - ms_error) / denominator) if denominator else float("nan")


def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    count = values.size
    for rank, index in enumerate(order):
        running = max(running, (count - rank) * values[index])
        adjusted[index] = min(running, 1.0)
    return adjusted.tolist()
