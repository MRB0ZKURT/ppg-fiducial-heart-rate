"""DEPRECATED experimental rater-scoring code; not used by protocol v2."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .annotations import FIDUCIAL_COLUMNS
from .config import project_path
from .statistics import icc_2_1
from .tables import read_records, write_json, write_records

AUTO_COLUMNS = {
    "q_ms": "q_sample",
    "r_ms": "r_sample",
    "s1_ms": "s1_sample",
    "s2_ms": "s2_sample",
    "avo_ms": "avo_sample",
    "avc_ms": "avc_sample",
    "carotid_880nm_foot_ms": "carotid_880nm_foot_sample",
    "brachial_880nm_foot_ms": "brachial_880nm_foot_sample",
    "carotid_660nm_foot_ms": "carotid_660nm_foot_sample",
    "brachial_660nm_foot_ms": "brachial_660nm_foot_sample",
}


def _load_completed(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    required = {"blinded_record_code", "beat_slot", "usable", *FIDUCIAL_COLUMNS}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing annotation columns in {path}: {sorted(missing)}")
    usable = frame["usable"].astype(str).str.lower().isin({"1", "true", "yes", "y"})
    if not usable.any():
        raise ValueError(f"No usable rows marked in {path}")
    return frame


def score_completed_annotations(config: dict[str, Any], rater_1: str, rater_2: str) -> dict[str, object]:
    annotation_root = project_path(config, config["paths"]["annotation_root"])
    output_root = project_path(config, config["paths"]["output_root"])
    first = _load_completed(project_path(config, rater_1))
    second = _load_completed(project_path(config, rater_2))
    keys = ["blinded_record_code", "beat_slot"]
    merged = first.merge(second, on=keys, suffixes=("_rater1", "_rater2"), validate="one_to_one")
    blinding = read_records(annotation_root / "blinding_key.parquet")
    intervals = read_records(output_root / "intervals.parquet")
    merged = merged.merge(blinding, on=keys, validate="one_to_one")
    merged = merged.merge(
        intervals,
        left_on=["record_id", "algorithm_beat_index"],
        right_on=["record_id", "beat_index"],
        validate="one_to_one",
        suffixes=("", "_auto"),
    )
    results: list[dict[str, object]] = []
    for fiducial in FIDUCIAL_COLUMNS:
        r1 = pd.to_numeric(merged[f"{fiducial}_rater1"], errors="coerce").to_numpy(float)
        r2 = pd.to_numeric(merged[f"{fiducial}_rater2"], errors="coerce").to_numpy(float)
        usable = np.isfinite(r1) & np.isfinite(r2)
        difference = np.abs(r1[usable] - r2[usable])
        threshold = 10.0 if fiducial in {"q_ms", "r_ms"} else 20.0
        auto_ms = (
            np.asarray(merged[AUTO_COLUMNS[fiducial]], dtype=float)
            - np.asarray(merged["window_start_sample"], dtype=float)
        ) * 1000.0 / np.asarray(merged["fs_hz"], dtype=float)
        manual_consensus = np.nanmean(np.column_stack([r1, r2]), axis=1)
        comparable = np.isfinite(manual_consensus) & np.isfinite(auto_ms)
        matches = np.abs(manual_consensus[comparable] - auto_ms[comparable]) <= threshold
        sensitivity = float(np.mean(matches)) if matches.size else float("nan")
        ppv = float(np.sum(matches) / max(np.isfinite(auto_ms).sum(), 1))
        icc = icc_2_1(np.column_stack([r1, r2]))
        median_difference = float(np.median(difference)) if difference.size else float("nan")
        results.append(
            {
                "fiducial": fiducial,
                "paired_beats": int(usable.sum()),
                "icc_2_1": icc,
                "median_absolute_rater_difference_ms": median_difference,
                "automatic_sensitivity": sensitivity,
                "automatic_ppv": ppv,
                "agreement_pass": bool(
                    icc >= config["annotation"]["thresholds"]["icc_2_1"]
                    and median_difference <= threshold
                    and sensitivity >= config["annotation"]["thresholds"]["automatic_sensitivity"]
                    and ppv >= config["annotation"]["thresholds"]["automatic_ppv"]
                ),
            }
        )
    result_path = write_records(results, annotation_root / "agreement_results.parquet")
    combined = pd.concat(
        [first.assign(rater="rater_1"), second.assign(rater="rater_2")], ignore_index=True
    )
    annotation_path = write_records(combined.to_dict("records"), output_root / "annotations.parquet")
    manifest = {
        "status": "scored_awaiting_adjudication",
        "agreement_results": str(result_path),
        "annotations": str(annotation_path),
        "all_fiducials_pass": bool(all(row["agreement_pass"] for row in results)),
        "adjudication_complete": False,
    }
    write_json(manifest, annotation_root / "annotation_manifest.json")
    return manifest
