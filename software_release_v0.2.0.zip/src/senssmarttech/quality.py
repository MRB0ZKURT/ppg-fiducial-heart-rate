from __future__ import annotations

import numpy as np


def valid_rr_mask(r_samples: np.ndarray, fs: float, minimum_ms: float, maximum_ms: float) -> np.ndarray:
    if r_samples.size == 0:
        return np.zeros(0, dtype=bool)
    rr_ms = np.full(r_samples.size, np.nan)
    if r_samples.size > 1:
        rr_ms[1:] = np.diff(r_samples) * 1000.0 / fs
        rr_ms[0] = rr_ms[1]
    return (rr_ms >= minimum_ms) & (rr_ms <= maximum_ms)


def temporal_order_mask(*fiducials: np.ndarray) -> np.ndarray:
    if not fiducials:
        return np.zeros(0, dtype=bool)
    stacked = np.column_stack(fiducials)
    return np.all(stacked >= 0, axis=1) & np.all(np.diff(stacked, axis=1) > 0, axis=1)


def robust_snr_db(signal: np.ndarray) -> float:
    """Deterministic quality proxy, not a calibrated physical SNR estimate."""
    centered = signal - np.median(signal)
    smooth = np.convolve(centered, np.ones(11) / 11.0, mode="same")
    noise = centered - smooth
    signal_power = float(np.median(smooth**2))
    noise_power = float(np.median(noise**2))
    return 10.0 * np.log10((signal_power + 1e-12) / (noise_power + 1e-12))
