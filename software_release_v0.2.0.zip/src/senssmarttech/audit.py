from __future__ import annotations

import hashlib
import re
from collections import Counter
from pathlib import Path
from typing import Any

from .config import project_path
from .metadata import Record, read_demographics
from .tables import write_json, write_records

MODALITIES = ("ecg", "ppg", "pcg", "acc")


def _sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def _parse_hash_manifest(path: Path) -> dict[str, str]:
    entries: dict[str, str] = {}
    if not path.exists():
        return entries
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^([0-9a-fA-F]{64})\s+\*?(.+)$", line.strip())
        if match:
            entries[match.group(2).replace("/", "\\")] = match.group(1).lower()
    return entries


def _record_row(record: Record, csv_root: Path, wfdb_root: Path) -> dict[str, object]:
    row = record.to_dict()
    for modality in MODALITIES:
        row[f"csv_{modality}"] = str(csv_root / f"{record.record_id}_{modality}.csv")
        row[f"wfdb_{modality}_header"] = str(wfdb_root / f"{record.record_id}_{modality}.hea")
        row[f"wfdb_{modality}_data"] = str(wfdb_root / f"{record.record_id}_{modality}.dat")
    return row


def run_audit(config: dict[str, Any], verify_checksums: bool = False) -> dict[str, object]:
    dataset_root = project_path(config, config["paths"]["dataset_root"])
    demographics = project_path(config, config["paths"]["demographics"])
    csv_root = project_path(config, config["paths"]["csv_root"])
    wfdb_root = project_path(config, config["paths"]["wfdb_root"])
    report_root = project_path(config, config["paths"]["report_root"])
    output_root = project_path(config, config["paths"]["output_root"])
    expected = config["expected_inventory"]

    records = read_demographics(demographics)
    activity_counts = Counter(record.activity_state for record in records)
    subject_counts = Counter(record.subject for record in records)
    missing: list[str] = []
    for record in records:
        for modality in MODALITIES:
            for path in (
                csv_root / f"{record.record_id}_{modality}.csv",
                wfdb_root / f"{record.record_id}_{modality}.hea",
                wfdb_root / f"{record.record_id}_{modality}.dat",
            ):
                if not path.exists():
                    missing.append(str(path))

    counts = {
        "subjects": len(subject_counts),
        "sessions": len(records),
        "before_sessions": activity_counts.get("B", 0),
        "after_sessions": activity_counts.get("A", 0),
        "csv_files": len(list(csv_root.glob("*.csv"))),
        "wfdb_headers": len(list(wfdb_root.glob("*.hea"))),
        "wfdb_data_files": len(list(wfdb_root.glob("*.dat"))),
    }
    expected_counts = {key: expected[key] for key in counts}
    count_checks = {key: counts[key] == expected_counts[key] for key in counts}

    checksum_report: dict[str, object] = {"requested": verify_checksums, "checked": 0, "failures": []}
    if verify_checksums:
        manifest = _parse_hash_manifest(dataset_root / "SHA256SUMS.txt")
        failures: list[str] = []
        for relative, expected_hash in manifest.items():
            local = dataset_root / relative
            if local.exists() and _sha256(local).lower() != expected_hash:
                failures.append(relative)
        checksum_report = {
            "requested": True,
            "checked": sum((dataset_root / relative).exists() for relative in manifest),
            "manifest_entries": len(manifest),
            "failures": failures,
        }

    index_rows = [_record_row(record, csv_root, wfdb_root) for record in records]
    index_path = write_records(index_rows, output_root / "record_index.parquet")
    result: dict[str, object] = {
        "dataset_root": str(dataset_root),
        "counts": counts,
        "expected_counts": expected_counts,
        "count_checks": count_checks,
        "all_count_checks_pass": all(count_checks.values()),
        "missing_core_files": missing,
        "all_core_files_present": not missing,
        "heart_rate_bpm": {
            "minimum": min(record.median_hr_bpm for record in records),
            "maximum": max(record.median_hr_bpm for record in records),
        },
        "records_per_subject": dict(sorted(subject_counts.items())),
        "subject_2_post_activity_recovery_segments": max(
            record.recovery_segment
            for record in records
            if record.subject == 2 and record.activity_state == "A"
        ),
        "checksum": checksum_report,
        "record_index": str(index_path),
    }
    write_json(result, report_root / "data_audit.json")
    return result
