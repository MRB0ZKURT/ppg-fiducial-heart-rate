from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Any

import numpy as np

from .config import project_path
from .fiducials import detect_ppg_feet, detect_r_multilead
from .tables import write_json, write_records

COMMENT_VALUE = re.compile(r"<(?P<key>[^>]+)>:\s*(?P<value>[^<]+)")


def restore_frozen_external_pilot(config: dict[str, Any]) -> dict[str, object]:
    """Copy the immutable external pilot instead of re-estimating it.

    The active PPG detector changed after this pilot was completed. Re-running
    the pilot with the revised detector is a separate sensitivity experiment;
    it must not replace or retrospectively redefine the locked pilot result.
    """

    source_root = project_path(config, "archive/pre_method_revision_2026-09-06/outputs")
    output_root = project_path(config, config["paths"]["output_root"])
    output_root.mkdir(parents=True, exist_ok=True)
    for name in (
        "external_pilot_beats.parquet",
        "external_pilot_beats.csv",
        "external_pilot_records.parquet",
        "external_pilot_records.csv",
    ):
        source = source_root / name
        if source.exists():
            shutil.copy2(source, output_root / name)
    manifest_path = source_root / "external_replication_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["provenance"] = "frozen_pre_method_revision_pilot"
    manifest["source_manifest"] = str(manifest_path)
    manifest["beat_table"] = str(output_root / "external_pilot_beats.parquet")
    manifest["record_table"] = str(output_root / "external_pilot_records.parquet")
    write_json(manifest, output_root / "external_replication_manifest.json")
    return manifest


def _decode_format_212(path: Path, expected_values: int) -> np.ndarray:
    packed = np.fromfile(path, dtype=np.uint8)
    triples = packed[: packed.size - packed.size % 3].reshape(-1, 3).astype(np.int32)
    first = triples[:, 0] | ((triples[:, 1] & 0x0F) << 8)
    second = triples[:, 2] | ((triples[:, 1] & 0xF0) << 4)
    first[first >= 2048] -= 4096
    second[second >= 2048] -= 4096
    digital = np.column_stack([first, second]).ravel()
    if digital.size < expected_values:
        raise ValueError(f"Format-212 payload is short: {digital.size} < {expected_values}")
    return digital[:expected_values]


def read_external_record(header_path: Path) -> tuple[np.ndarray, float, list[str], dict[str, str]]:
    lines = header_path.read_text(encoding="utf-8").splitlines()
    first = lines[0].split()
    signals, fs, samples = int(first[1]), float(first[2]), int(first[3])
    signal_lines = [line for line in lines[1:] if line and not line.startswith("#")]
    if len(signal_lines) != signals:
        raise ValueError(f"Header signal count mismatch in {header_path}")
    gains, baselines, names = [], [], []
    for line in signal_lines:
        fields = line.split()
        if fields[1] != "212":
            raise ValueError(f"Expected format 212, found {fields[1]}")
        gain_text = fields[2]
        gain = float(gain_text.split("(", 1)[0])
        baseline = int(gain_text.split("(", 1)[1].split(")", 1)[0])
        gains.append(gain)
        baselines.append(baseline)
        names.append(fields[-1])
    digital = _decode_format_212(header_path.with_suffix(".dat"), samples * signals)
    values = (digital.reshape(samples, signals) - np.asarray(baselines)) / np.asarray(gains)
    metadata: dict[str, str] = {}
    for line in lines:
        if line.startswith("#"):
            metadata.update({match.group("key"): match.group("value").strip() for match in COMMENT_VALUE.finditer(line)})
    return values, fs, names, metadata


def read_wfdb_annotations(path: Path) -> np.ndarray:
    """Read ordinary beat locations and the standard WFDB SKIP/AUX controls."""
    payload = path.read_bytes()
    offset = 0
    sample = 0
    locations: list[int] = []
    while offset + 1 < len(payload):
        low, high = payload[offset], payload[offset + 1]
        offset += 2
        annotation_type = high >> 2
        interval = ((high & 0x03) << 8) | low
        if annotation_type == 0:
            break
        if annotation_type == 59:  # SKIP
            if offset + 4 > len(payload):
                break
            sample += int.from_bytes(payload[offset : offset + 4], "little", signed=True)
            offset += 4
            continue
        if annotation_type in (60, 61, 62):
            continue
        if annotation_type == 63:  # AUX: interval is byte count
            offset += interval + interval % 2
            continue
        sample += interval
        locations.append(sample)
    return np.asarray(locations, dtype=int)


def _match_fraction(reference: np.ndarray, candidate: np.ndarray, tolerance: int) -> tuple[float, float]:
    used: set[int] = set()
    matched = 0
    for value in reference:
        choices = np.flatnonzero(np.abs(candidate - value) <= tolerance)
        choices = [int(index) for index in choices if int(index) not in used]
        if choices:
            best = min(choices, key=lambda index: abs(int(candidate[index]) - int(value)))
            used.add(best)
            matched += 1
    sensitivity = matched / max(reference.size, 1)
    ppv = matched / max(candidate.size, 1)
    return float(sensitivity), float(ppv)


def _physiological_refractory(samples: np.ndarray, confidence: np.ndarray, fs: float) -> np.ndarray:
    """Suppress double detections closer than 400 ms, retaining the stronger event."""
    minimum_distance = round(0.4 * fs)
    retained: list[tuple[int, float]] = []
    for sample, score in zip(samples, confidence, strict=True):
        current = (int(sample), float(score))
        if not retained or current[0] - retained[-1][0] >= minimum_distance:
            retained.append(current)
        elif current[1] > retained[-1][1]:
            retained[-1] = current
    return np.asarray([sample for sample, _ in retained], dtype=int)


def run_external_pilot(config: dict[str, Any]) -> dict[str, object]:
    root = project_path(config, "external_data/pulse-transit-time-ppg-1.1.0")
    output_root = project_path(config, config["paths"]["output_root"])
    subjects = (8, 12, 14, 16, 17, 20)
    rows: list[dict[str, object]] = []
    record_rows: list[dict[str, object]] = []
    for subject in subjects:
        for activity in ("sit", "walk", "run"):
            stem = f"s{subject}_{activity}"
            values, fs, names, metadata = read_external_record(root / f"{stem}.hea")
            r_reference = read_wfdb_annotations(root / f"{stem}.atr")
            r_detection = detect_r_multilead(values[:, [names.index("ecg")]], fs)
            r_detected = _physiological_refractory(r_detection.samples, r_detection.confidence, fs)
            sensitivity, ppv = _match_fraction(r_reference, r_detected, round(0.05 * fs))
            distal_red = detect_ppg_feet(values[:, names.index("pleth_1")], r_reference, fs, "carotid")
            proximal_red = detect_ppg_feet(values[:, names.index("pleth_4")], r_reference, fs, "carotid")
            distal_ir = detect_ppg_feet(values[:, names.index("pleth_2")], r_reference, fs, "carotid")
            proximal_ir = detect_ppg_feet(values[:, names.index("pleth_5")], r_reference, fs, "carotid")
            hr = 60.0 * fs / np.median(np.diff(r_reference))
            valid_record_beats = 0
            for beat, r_value in enumerate(r_reference):
                red_ptt = (distal_red[beat] - proximal_red[beat]) * 1000.0 / fs
                ir_ptt = (distal_ir[beat] - proximal_ir[beat]) * 1000.0 / fs
                distal_pat = (distal_ir[beat] - r_value) * 1000.0 / fs
                proximal_pat = (proximal_ir[beat] - r_value) * 1000.0 / fs
                valid = 2 <= red_ptt <= 150 or 2 <= ir_ptt <= 150
                valid_record_beats += int(valid)
                rows.append(
                    {
                        "dataset": "pulse-transit-time-ppg-1.1.0",
                        "subject": subject,
                        "record_id": stem,
                        "activity_state": activity,
                        "heart_rate_bpm": float(hr),
                        "beat_index": beat,
                        "r_sample": int(r_value),
                        "r_to_distal_ir_foot_ms": float(distal_pat),
                        "r_to_proximal_ir_foot_ms": float(proximal_pat),
                        "proximal_to_distal_red_foot_ms": float(red_ptt),
                        "proximal_to_distal_ir_foot_ms": float(ir_ptt),
                        "valid_ptt": bool(valid),
                    }
                )
            record_rows.append(
                {
                    "subject": subject,
                    "record_id": stem,
                    "activity_state": activity,
                    "heart_rate_bpm": float(hr),
                    "annotated_r_beats": int(r_reference.size),
                    "valid_ppg_beats": int(valid_record_beats),
                    "r_sensitivity": sensitivity,
                    "r_ppv": ppv,
                    "metadata_hr_start": metadata.get("hr_1_start", ""),
                    "metadata_hr_end": metadata.get("hr_1_end", ""),
                }
            )
    beat_path = write_records(rows, output_root / "external_pilot_beats.parquet")
    record_path = write_records(record_rows, output_root / "external_pilot_records.parquet")
    passed_records = [row for row in record_rows if row["annotated_r_beats"] >= 20 and row["valid_ppg_beats"] >= 20]
    subject_hr_spans = {
        subject: max(row["heart_rate_bpm"] for row in record_rows if row["subject"] == subject)
        - min(row["heart_rate_bpm"] for row in record_rows if row["subject"] == subject)
        for subject in subjects
    }
    r_agreement = min(
        float(np.mean([row["r_sensitivity"] for row in record_rows])),
        float(np.mean([row["r_ppv"] for row in record_rows])),
    )
    beat_array = [row for row in rows if row["valid_ptt"]]
    positive_fraction = float(np.mean([row["proximal_to_distal_ir_foot_ms"] > 0 for row in rows]))
    stable_polarity = max(positive_fraction, 1.0 - positive_fraction)
    gates = {
        "record_pass_fraction": len(passed_records) / len(record_rows),
        "subjects_with_30_bpm_span": sum(span >= 30 for span in subject_hr_spans.values()),
        "r_annotation_agreement": r_agreement,
        "positive_ptt_fraction": positive_fraction,
        "stable_ptt_polarity_fraction": stable_polarity,
        "valid_ptt_beats": len(beat_array),
    }
    passed = (
        gates["record_pass_fraction"] >= config["replication"]["minimum_record_pass_fraction"]
        and gates["subjects_with_30_bpm_span"] >= config["replication"]["minimum_subjects_with_30_bpm_span"]
        and gates["r_annotation_agreement"] >= config["replication"]["r_annotation_agreement"]
        and gates["stable_ptt_polarity_fraction"] >= 0.80
    )
    manifest = {
        "status": "pilot_passed" if passed else "pilot_failed",
        "subjects": list(subjects),
        "records": len(record_rows),
        "gates": gates,
        "subject_hr_spans_bpm": subject_hr_spans,
        "beat_table": str(beat_path),
        "record_table": str(record_path),
        "full_dataset_download_authorized_by_gate": passed,
    }
    write_json(manifest, output_root / "external_replication_manifest.json")
    return manifest
