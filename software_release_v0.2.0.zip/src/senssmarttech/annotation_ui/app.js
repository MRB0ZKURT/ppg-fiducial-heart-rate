const svgNS = "http://www.w3.org/2000/svg";
const plot = document.getElementById("signalPlot");
const plotScroller = document.getElementById("plotScroller");
let config;
let task;
let currentIndex = 0;
let selectedFiducial = null;
let selectedConfidence = "high";
let saveTimer = null;

function svgElement(name, attributes = {}) {
  const element = document.createElementNS(svgNS, name);
  Object.entries(attributes).forEach(([key, value]) => element.setAttribute(key, value));
  return element;
}

function showToast(message, isError = false) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.toggle("error", isError);
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 3500);
}

async function request(url, options = {}) {
  const response = await fetch(url, options);
  const payload = await response.json();
  if (!response.ok) throw new Error(payload.error || "İşlem başarısız.");
  return payload;
}

function modeLabel() {
  if (config.mode === "training") return "Ortak eğitim";
  if (config.mode === "adjudication") return "Uyuşmazlık çözümü";
  return `Bağımsız değerlendirici ${config.rater}`;
}

function buildFiducialButtons() {
  const container = document.getElementById("fiducialButtons");
  container.innerHTML = "";
  config.fiducials.forEach((fiducial) => {
    const button = document.createElement("button");
    button.className = "fiducial-button";
    button.dataset.name = fiducial.name;
    button.style.setProperty("--marker", fiducial.color);
    button.innerHTML = `<span>${fiducial.label}</span><span class="fiducial-value">—</span>`;
    button.onclick = () => {
      selectedFiducial = fiducial.name;
      document.querySelectorAll(".fiducial-button").forEach((item) => item.classList.toggle("active", item === button));
      document.getElementById("selectionHint").textContent = `${fiducial.label}: ${rowInstruction(fiducial.row)}`;
    };
    container.appendChild(button);
  });
}

function rowInstruction(row) {
  if (row === "ecg") return "ECG satırlarından birine tıklayın.";
  const names = { pcg: "PCG", scg: "SCG", ppg_880: "PPG 880", ppg_660: "PPG 660" };
  return `${names[row]} satırına tıklayın.`;
}

function annotation() {
  return task.annotation;
}

function updateControls() {
  document.getElementById("modeBadge").textContent = modeLabel();
  document.getElementById("progressText").textContent = `${config.completed}/${config.task_count} tamamlandı`;
  document.getElementById("taskCode").textContent = `${task.code} · Atım ${task.beat_slot}`;
  document.getElementById("taskPosition").textContent = `${currentIndex + 1} / ${config.task_count}`;
  document.getElementById("previousButton").disabled = currentIndex === 0;
  document.getElementById("nextButton").disabled = currentIndex >= config.task_count - 1;
  document.getElementById("usableSelect").value = annotation().usable == null ? "" : String(annotation().usable);
  document.getElementById("notes").value = annotation().notes || "";
  document.getElementById("finalizeButton").disabled = config.locked;
  document.getElementById("finalizeButton").textContent = config.locked ? "Kilitlendi" : "Tamamla ve kilitle";
  config.fiducials.forEach((fiducial) => {
    const button = document.querySelector(`[data-name="${fiducial.name}"]`);
    const item = annotation().fiducials[fiducial.name];
    const value = item.confidence === "unmeasurable" ? "Ölçülemez" : item.value_ms == null ? "—" : `${item.value_ms.toFixed(1)} ms`;
    button.querySelector(".fiducial-value").textContent = value;
    button.classList.toggle("disagreement", (task.disagreements || []).includes(fiducial.name));
  });
  renderComparison();
}

function renderComparison() {
  const box = document.getElementById("raterComparison");
  if (config.mode !== "adjudication") { box.classList.add("hidden"); return; }
  box.classList.remove("hidden");
  box.innerHTML = "<strong>Bağımsız işaretler</strong>";
  (task.disagreements || []).forEach((name) => {
    const meta = config.fiducials.find((item) => item.name === name);
    const first = task.rater_1.fiducials[name];
    const second = task.rater_2.fiducials[name];
    const format = (item) => item.confidence === "unmeasurable" ? "ölçülemez" : `${Number(item.value_ms).toFixed(1)} ms (${item.confidence})`;
    const row = document.createElement("div");
    row.className = "comparison-row";
    row.textContent = `${meta.label}: D1 ${format(first)} · D2 ${format(second)}`;
    box.appendChild(row);
  });
}

function pathFor(values, x0, x1, top, height) {
  if (!values.length) return "";
  return values.map((value, index) => {
    const x = x0 + (index / Math.max(values.length - 1, 1)) * (x1 - x0);
    const y = top + height / 2 - (value / 9) * height;
    return `${index ? "L" : "M"}${x.toFixed(2)},${y.toFixed(2)}`;
  }).join(" ");
}

function markerRows(meta) {
  if (meta.row === "ecg") return [0, 1, 2, 3];
  const map = { pcg: 4, scg: 5, ppg_880: 6, ppg_660: 7 };
  return [map[meta.row]];
}

function renderPlot() {
  plot.innerHTML = "";
  const x0 = 82, x1 = 1215, rowHeight = 102, topMargin = 18;
  task.signals.forEach((signal, rowIndex) => {
    const top = topMargin + rowIndex * rowHeight;
    plot.appendChild(svgElement("rect", { x: x0, y: top, width: x1 - x0, height: 82, fill: rowIndex % 2 ? "#f8fbfd" : "#ffffff", stroke: "#d7e0e8" }));
    const label = svgElement("text", { x: 72, y: top + 45, "text-anchor": "end", fill: "#33485a", "font-size": 14, "font-weight": 600 });
    label.textContent = signal.label;
    plot.appendChild(label);
    signal.series.forEach((series) => plot.appendChild(svgElement("path", {
      d: pathFor(series.values, x0, x1, top + 5, 72), fill: "none", stroke: series.color, "stroke-width": 1.4,
    })));
  });
  for (let tick = 0; tick <= task.duration_ms; tick += 100) {
    const x = x0 + tick / task.duration_ms * (x1 - x0);
    plot.appendChild(svgElement("line", { x1: x, x2: x, y1: topMargin, y2: topMargin + 8 * rowHeight - 20, stroke: "#cfd9e1", "stroke-width": .7, "stroke-dasharray": "3 5" }));
    const label = svgElement("text", { x, y: 848, "text-anchor": "middle", fill: "#617181", "font-size": 12 });
    label.textContent = `${tick}`;
    plot.appendChild(label);
  }
  const axisLabel = svgElement("text", { x: (x0 + x1) / 2, y: 880, "text-anchor": "middle", fill: "#33485a", "font-size": 14 });
  axisLabel.textContent = "Pencere zamanı (ms)";
  plot.appendChild(axisLabel);

  config.fiducials.forEach((meta) => {
    const item = annotation().fiducials[meta.name];
    if (item.value_ms == null) return;
    const x = x0 + item.value_ms / task.duration_ms * (x1 - x0);
    markerRows(meta).forEach((rowIndex) => {
      const top = topMargin + rowIndex * rowHeight;
      plot.appendChild(svgElement("line", { x1: x, x2: x, y1: top, y2: top + 82, stroke: meta.color, "stroke-width": 2.3 }));
    });
  });

  if (config.mode === "adjudication") {
    [task.rater_1, task.rater_2].forEach((rater, raterIndex) => {
      config.fiducials.forEach((meta) => {
        if (!(task.disagreements || []).includes(meta.name)) return;
        const item = rater.fiducials[meta.name];
        if (item.value_ms == null) return;
        const x = x0 + item.value_ms / task.duration_ms * (x1 - x0);
        markerRows(meta).forEach((rowIndex) => {
          const top = topMargin + rowIndex * rowHeight;
          plot.appendChild(svgElement("line", { x1: x, x2: x, y1: top, y2: top + 82, stroke: raterIndex ? "#e67e22" : "#2471a3", "stroke-width": 1.5, "stroke-dasharray": raterIndex ? "3 3" : "7 3" }));
        });
      });
    });
  }
}

function rowFromY(y) {
  const index = Math.floor((y - 18) / 102);
  if (index >= 0 && index <= 3) return "ecg";
  return { 4: "pcg", 5: "scg", 6: "ppg_880", 7: "ppg_660" }[index];
}

plot.addEventListener("click", (event) => {
  if (!selectedFiducial || config.locked) { showToast("Önce soldan bir fidüsiyel seçin.", true); return; }
  if (config.mode === "adjudication" && !(task.disagreements || []).includes(selectedFiducial)) {
    showToast("Bu nokta için uyuşmazlık yok; değiştirilmesine gerek yok.", true); return;
  }
  const point = plot.createSVGPoint(); point.x = event.clientX; point.y = event.clientY;
  const local = point.matrixTransform(plot.getScreenCTM().inverse());
  const meta = config.fiducials.find((item) => item.name === selectedFiducial);
  if (rowFromY(local.y) !== meta.row) { showToast(rowInstruction(meta.row), true); return; }
  const x0 = 82, x1 = 1215;
  const value = Math.max(0, Math.min(task.duration_ms, (local.x - x0) / (x1 - x0) * task.duration_ms));
  annotation().usable = true;
  annotation().fiducials[selectedFiducial] = { value_ms: Math.round(value * 10) / 10, confidence: selectedConfidence };
  updateControls(); renderPlot(); scheduleSave();
});

function scheduleSave() {
  document.getElementById("saveStatus").textContent = "Kaydediliyor…";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveCurrent, 350);
}

async function saveCurrent() {
  try {
    config = await request("/api/save", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ index: currentIndex, annotation: annotation() }) });
    document.getElementById("saveStatus").textContent = "Kaydedildi";
    updateControls();
  } catch (error) { document.getElementById("saveStatus").textContent = "Kayıt hatası"; showToast(error.message, true); }
}

async function loadTask(index) {
  currentIndex = index;
  task = await request(`/api/task?index=${index}`);
  updateControls(); renderPlot();
  document.getElementById("saveStatus").textContent = config.locked ? "Kilitli" : "Hazır";
}

document.getElementById("previousButton").onclick = async () => { await saveCurrent(); await loadTask(currentIndex - 1); };
document.getElementById("nextButton").onclick = async () => { await saveCurrent(); await loadTask(currentIndex + 1); };
document.getElementById("notes").oninput = (event) => { annotation().notes = event.target.value; scheduleSave(); };
document.getElementById("usableSelect").onchange = (event) => {
  annotation().usable = event.target.value === "" ? null : event.target.value === "true";
  if (annotation().usable === false) Object.keys(annotation().fiducials).forEach((name) => annotation().fiducials[name] = { value_ms: null, confidence: "unmeasurable" });
  updateControls(); renderPlot(); scheduleSave();
};
document.querySelectorAll(".confidence").forEach((button) => button.onclick = () => {
  selectedConfidence = button.dataset.confidence;
  document.querySelectorAll(".confidence").forEach((item) => item.classList.toggle("active", item === button));
});
document.getElementById("unmeasurableButton").onclick = () => {
  if (!selectedFiducial) { showToast("Önce bir fidüsiyel seçin.", true); return; }
  annotation().usable = true;
  annotation().fiducials[selectedFiducial] = { value_ms: null, confidence: "unmeasurable" };
  updateControls(); renderPlot(); scheduleSave();
};
document.getElementById("clearButton").onclick = () => {
  if (!selectedFiducial) return;
  annotation().fiducials[selectedFiducial] = { value_ms: null, confidence: null };
  updateControls(); renderPlot(); scheduleSave();
};
document.getElementById("zoomButton").onclick = () => plotScroller.classList.toggle("zoomed");
document.getElementById("finalizeButton").onclick = async () => {
  try {
    await saveCurrent();
    const result = await request("/api/finalize", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    config.locked = true; updateControls(); showToast(`Dosya kilitlendi. SHA-256: ${result.sha256 || "oluşturuldu"}`);
  } catch (error) { showToast(error.message, true); }
};

async function start() {
  try {
    config = await request("/api/config");
    buildFiducialButtons();
    if (!config.task_count) { showToast("Çözülecek uyuşmazlık bulunmuyor."); return; }
    await loadTask(0);
  } catch (error) { showToast(error.message, true); }
}
start();
